
# Ćwiczenie 2
**Autorzy**: Janusz Kubiak, Krzysztof Jóskowiak

## Zadanie
Należy napisać program, dzięki któremu Velma otworzy drzwiczki od szafki o minimum 90 stopni, bez naruszania limitów sił z jakimi robot może oddziaływać na otoczenie

## Schemat działania
1. Obrót korpusu w stronę środka układu współrzędnych szafki
2. Wybór ręki do otworzenia szafki, dokonany na podstawie rotacji szafki.
3. Podniesienie ręki do pozycji początkowej w trybie sterowania w przestrzeni złączy.
4. Przejście w tryb sterowania w przestrzeni kartezjańskiej
5. Przysunięcie narzędzia do szafki i obrócenie go odpowiednio
6. Włączenie trybu niskiej impedancji
7. Poruszenie narzędzia w stronę szafki, aż do wyczucia kontaktu z drzwiami szafki
8. Przesunięcie narzędzia wzdłuż drzwi, aż do wyczucia zawiasu.
9. Pociągnięcie klamki po ścieżce złożonej z kilku punktów na okręgu o środku w zawiasie i promieniu zawias-klamka.
10. Wyjęcie ręki z klamki
11. Poprawienie otwarcia drzwi, poprzez ich popchnięcie narzędziem.
12. Powrót do pozycji początkowej

## Zdefiniowane klasy i ich funkcje
### Klasa MoveRobot
Interfejs do ruchu robotem. Jego funkcje to:

```python
def return_to_starting_position(self)
```
Porusza robota do pozycji początkowej.

```python
def rotate_base_in_starting_position(self, rot_angle)
```
Obraca bazę robota o zadany kąt, i zadaje pozycję początkową złączy. Użycie tej funkcji ma sens na początku działania programu, kiedy robot znajduje się w pozycji początkowej.

```python
def initialize_robot(self)
```
Inicjalizuje robota.

```python
def move(self, q_map, duration=3, position_tol=15.0/180.0*math.pi, start_time=0.5)
```
Porusza robotem do zadanej pozycji `q_map` w przestrzeni stawów.

```python
def enter_cimp(self)
```
Wprowadza robota w stan sterowania w przestrzeni kartezjańskiej.

```python
def enter_jimp(self)
```
Wprowadza robota w stan sterowania w przestrzeni stawów.

```python
def move_to_target(self, side, frame, time=3.0)
```
Porusza narzędziem robota po stronie zdefiniowanej przez zmienną wyliczeniową `side` do zadanej pozycji `frame` w trybie kartezjańskim.

```python
def prepare_hand(self, side)
```
Zgina palce narzędzia po stronie zdefiniowanej przez zmienną wyliczeniową `side` w sposób optymalny do uchwycenia klamki.

```python
def change_impedance(self,side,imp_list,imp_change_tlist)
```
Zmienia impedancję sterowania po stronie zdefiniowanej przez zmienną wyliczeniową `side`.

```python
def enter_low_impedance(self,side)
```
Ustawia impedancję sterowania narzędzia po stronie zdefiniowanej przez zmienną wyliczeniową `side` na 125 N/cm w płaszczyźnie xy.

```python
def exit_low_impedance(self,side)
```
Ustawia impedancję sterowania po stronie zdefiniowanej przez zmienną wyliczeniową `side` na bazową (1000 N/cm)

### Klasa OpenDoorTask
Klasa obsługująca wykonanie zadania.

```python
def rotate_towards_cabinet(self)
```
Obraca robota w stronę środka układu współrzędnych szafki.

```python
def choose_opening_arm(self)
```
Wybiera rękę, którą będzie otwierana szafka na podstawie obrotu szafki wokół osi `Z` jej układu współrzędnych w układzie współrzędnych robota.

```python
def prepare_hand(self)
```
Ustawia palce narzędzia w konfigurację do optymalną do otwierania szafki.

```python
def reset_hand(self)
```
Ustawia palce narzędzia w konfigurację początkową.

```python
def reset_hands(self)
```
Ustawia palce obu narzędzi w konfigurację początkową.

```python
def move_to_opening_position(self)
```
Porusza ręką otwierającą szafkę do pozycji przed szafką.

```python
def move_tool(self)
```
Przesuwa układ współrzędnych narzędzia z nadgarstka do dłoni.

```python
def bump_the_door(self)
```
Przysuwa rękę w stronę drzwi aż do wykrycia kontaktu.

```python
def grab_handle(self)
```
Przesuwa narządzie równolegle do drzwi aż do wykrycia kontaktu z klamką.

```python
def return_to_starting_position(self)
```
Zadaje ruch do pozycji początkowej.

```python
def moveto_point(self, tf, yaw, x, y, z=0.04, time=1)
```
Porusza narzędziem do zadanej pozycji `tf` z offsetem `x,y,z`.

```python
def open_door(self)
```
Porusza ręką po łuku w celu otwarcia drzwi.


## Ładne obrazki
### Pozycja początkowa
![Pozycja wyjściowa](/docs/img/1ustawienie_poczatkowe.png)
### Pozycja wyjściowa
![Pozycja początkowa](/docs/img/2pozycja_jimp.png)
### Ruch w stronę drzwi
![Ruch w stronę drzwi](/docs/img/3reka_podjezdza_pod_drzwi.png)
### Chwycenie klamki
![Chwycenie klamki](/docs/img/4zlapanie_klamki.png)
### Otwieranie drzwi
![Otwieranie drzwi](/docs/img/5otwieranie_drzwi.png)
### Koniec ruchu po łuku
![Koniec ruchu po łuku](/docs/img/6koncowka_otwierania.png)
### Otwieranie z wewnętrznej strony
![Otwieranie z wewnętrznej strony](/docs/img/7dopychanie.png)
### Pozycja końcowa
![Pozycja końcowa](/docs/img/8pozycja_koncowa.png)
