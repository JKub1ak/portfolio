#!/usr/bin/env python

## Runs test for jnt_imp mode motion.
# @ingroup integration_tests
# @file test_jimp.py
# @namespace scripts.test_jimp Integration test

# Copyright (c) 2017, Robot Control and Pattern Recognition Group,
# Institute of Control and Computation Engineering
# Warsaw University of Technology
#
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#     * Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the Warsaw University of Technology nor the
#       names of its contributors may be used to endorse or promote products
#       derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL <COPYright HOLDER> BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# Author: Dawid Seredynski
#

import roslib; roslib.load_manifest('velma_task_cs_ros_interface')

import rospy
import math
import PyKDL
import tf
import copy

from velma_common import *
from control_msgs.msg import FollowJointTrajectoryResult
from survey_area import *
from rcprg_planner import *


def exitError(code):
    if code == 0:
        print "OK"
        exit(0)
    print "ERROR:", code
    exit(code)

def move(q_map, duration):
    print "Moving to position"
    velma.moveJoint(q_map, duration, start_time=0.5, position_tol=15.0/180.0*math.pi)
    velma.waitForJoint()

    rospy.sleep(0.5)
    js = velma.getLastJointState()
    if not isConfigurationClose(q_map, js[1], tolerance=0.1):
        exitError(10)
    rospy.sleep(1.0)

def planned_move(q_map):
    print "Planning motion to the goal position using set of all joints..."
    print "Moving to valid position, using planned trajectory."
    goal_constraint_1 = qMapToConstraints(q_map, 0.01, group=velma.getJointGroup("impedance_joints"))
    for i in range(15):
        rospy.sleep(0.5)
        js = velma.getLastJointState()
        print "Planning (try", i, ")..."
        traj = planner.plan(js[1], [goal_constraint_1], "impedance_joints", num_planning_attempts=10, max_velocity_scaling_factor=0.15, planner_id="RRTConnect")
        if traj == None:
            continue
        print "Executing trajectory..."
        if not velma.moveJointTraj(traj, start_time=0.5, position_tol=10.0/180.0 * math.pi, velocity_tol=10.0/180.0*math.pi):
            exitError(5)
        if velma.waitForJoint() == 0:
            break
        else:
            print "The trajectory could not be completed, retrying..."
            continue

    rospy.sleep(0.5)
    js = velma.getLastJointState()
    if not isConfigurationClose(q_map, js[1]):
        exitError(6)

    rospy.sleep(1.0)

#x = 0.20
def move_to_target(target_tool_rot, world_to_move_target_trans, offset_xyz=(0.0, 0.0, 0.0)):
    print "Moving left wrist to pose defined in world frame..."
    # Add offset bc no gripper tf

    for i in range(3):
        world_to_move_target_trans[i] += offset_xyz[i]

    world_to_move_target_tf_kdl = PyKDL.Frame(target_tool_rot, PyKDL.Vector(*world_to_move_target_trans))
    if not velma.moveCartImpLeft([world_to_move_target_tf_kdl], [3.0], None, None, None, None, PyKDL.Wrench(PyKDL.Vector(5,5,5), PyKDL.Vector(5,5,5)), start_time=0.5):
        exitError(13)
    if velma.waitForEffectorLeft() != 0:
        exitError(14)
    rospy.sleep(0.5)
    print "Calculating difference between desired and reached pose..."
    # B - Base, Tl - Tool left
    world_to_move_target_diff = PyKDL.diff(world_to_move_target_tf_kdl, velma.getTf("B", "Tl"), 1.0)
    print(world_to_move_target_diff.vel.Norm(), world_to_move_target_diff.rot.Norm())
    if world_to_move_target_diff.vel.Norm() > 0.10 or world_to_move_target_diff.rot.Norm() > 0.3:
        exitError(15)


class Transform(object):
    """docstring for Transform"""
    def __init__(self, trans=[], rot=[]):
        self.trans = trans
        self.rot = rot


def makeWrench(lx,ly,lz,rx,ry,rz):
    return PyKDL.Wrench(PyKDL.Vector(lx,ly,lz), PyKDL.Vector(rx,ry,rz))


if __name__ == "__main__":
    # define some configurations

    # starting position
    q_map_starting = {'torso_0_joint':0,
        'right_arm_0_joint':-0.3,   'left_arm_0_joint':0.3,
        'right_arm_1_joint':-1.8,   'left_arm_1_joint':1.8,
        'right_arm_2_joint':1.25,   'left_arm_2_joint':-1.25,
        'right_arm_3_joint':0.85,   'left_arm_3_joint':-0.85,
        'right_arm_4_joint':0,      'left_arm_4_joint':0,
        'right_arm_5_joint':-0.5,   'left_arm_5_joint':0.5,
        'right_arm_6_joint':0,      'left_arm_6_joint':0 }

    q_map_entry_pick_pose = {'torso_0_joint':0.0,
        'right_arm_0_joint':-0.3,   'left_arm_0_joint':0.3,
        'right_arm_1_joint':-1.8,  'left_arm_1_joint':1.8,
        'right_arm_2_joint':1.25,   'left_arm_2_joint':-1.57,
        'right_arm_3_joint':0.85,   'left_arm_3_joint':-1.7,
        'right_arm_4_joint':0.0,    'left_arm_4_joint':0.0,
        'right_arm_5_joint':-0.5,  'left_arm_5_joint':1.57,
        'right_arm_6_joint':0.0,    'left_arm_6_joint':0.0 }

    q_map_entry_place_pose = {'torso_0_joint':-0.689,
        'right_arm_0_joint':0.46,   'left_arm_0_joint':-0.15,
        'right_arm_1_joint':-1.84,  'left_arm_1_joint':1.889,
        'right_arm_2_joint':0.128,   'left_arm_2_joint':-1.232,
        'right_arm_3_joint':0.4319,   'left_arm_3_joint':-1.5,
        'right_arm_4_joint':0.755,    'left_arm_4_joint':-0.320,
        'right_arm_5_joint':-0.566,  'left_arm_5_joint': 1.6227,
        'right_arm_6_joint':-0.0339,    'left_arm_6_joint':0.441 }

    rospy.init_node('pick_and_place')

    rospy.sleep(0.5)

    print "This test/tutorial executes simple motions"\
        " in joint impedance mode. Planning is not used"\
        " in this example.\n"

    print "Running python interface for Velma..."
    velma = VelmaInterface()
    print "Waiting for VelmaInterface initialization..."
    if not velma.waitForInit(timeout_s=10.0):
        print "Could not initialize VelmaInterface\n"
        exitError(1)
    print "Initialization ok!\n"

    print "Motors must be enabled every time after the robot enters safe state."
    print "If the motors are already enabled, enabling them has no effect."
    print "Enabling motors..."
    if velma.enableMotors() != 0:
        exitError(2)

    rospy.sleep(0.5)

    diag = velma.getCoreCsDiag()
    if not diag.motorsReady():
        print "Motors must be homed and ready to use for this test."
        exitError(1)

    print "reset left"
    #rospy.sleep(2)
    velma.resetHandLeft()
    if velma.waitForHandLeft() != 0:
      exitError(2)

    print "Switch to jnt_imp mode (no trajectory)..."
    velma.moveJointImpToCurrentPos(start_time=0.5)
    error = velma.waitForJoint()
    if error != 0:
        print "The action should have ended without error, but the error code is", error
        exitError(3)

    # survey_area()

    planner = Planner(velma.maxJointTrajLen())
    planner.waitForInit()
    octomap_listener = OctomapListener("/octomap_binary")
    rospy.sleep(1.0)
    octomap = octomap_listener.getOctomap(timeout_s=5.0)
    planner.processWorld(octomap)


    print "Checking if the starting configuration is as expected..."
    rospy.sleep(0.5)
    js = velma.getLastJointState()
    if not isConfigurationClose(q_map_starting, js[1], tolerance=0.2):
        print("Moving to the starting position")
        planned_move(q_map_starting)

    # planned_move(q_map_entry_place_pose)
    planned_move(q_map_entry_pick_pose)

    print "Switch to cart_imp mode (no trajectory)..."
    if not velma.moveCartImpLeftCurrentPos(start_time=0.2):
        exitError(10)
    if velma.waitForEffectorLeft() != 0:
        exitError(11)

    rospy.sleep(0.5)

    # ====================================================
    # ====================================================

    diagnostic = velma.getCoreCsDiag()
    if not diagnostic.inStateCartImp():
        print "The core_cs should be in cart_imp state, but it is not"
        exitError(12)

    tf_listener = tf.TransformListener()
    tf_world_to_jar = Transform()

    #TODO give timeout
    while not rospy.is_shutdown():
        try:
            tf_world_to_jar.trans, tf_world_to_jar.rot = tf_listener.lookupTransform('/world','/jar',rospy.Time(0))
            break
        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException) as e:
            continue

    print tf_world_to_jar.trans

    target_tool_rot = PyKDL.Rotation.EulerZYX(-math.pi, 0.0, 0.0)

    # move to pick position
    move_to_target(target_tool_rot=target_tool_rot, world_to_move_target_trans=tf_world_to_jar.trans, offset_xyz=(-0.23, 0.0, 0.08))

    # close gripper
    dest_q = [math.radians(83), math.radians(83), math.radians(83), math.radians(0)]
    velma.moveHandLeft(dest_q, [1, 1, 1, 1], [8000, 8000, 8000, 8000], 100000000, hold=False)
    if velma.waitForHandLeft() != 0:
        exitError(2)

    # lift object
    move_to_target(target_tool_rot=target_tool_rot, world_to_move_target_trans=tf_world_to_jar.trans, offset_xyz=(-0.2, 0.0, 0.15))

    print "Switch to jnt_imp mode (no trajectory)..."
    velma.moveJointImpToCurrentPos(start_time=0.5)
    error = velma.waitForJoint()
    if error != 0:
        print "The action should have ended without error, but the error code is", error
        exitError(3)

    # move to place
    move(q_map_entry_place_pose, duration=6.0)
    # print "Set impedance to (1000,1000,125,150,150,150) in tool frame."
    # imp_list = [makeWrench(1000,1000,1000,150,150,150),
    #             makeWrench(1000,1000,500,150,150,150),
    #             makeWrench(1000,1000,250,150,150,150),
    #             makeWrench(1000,1000,125,150,150,150)]
    # if not velma.moveCartImpLeft(None, None, None, None, imp_list, [0.5,1.0,1.5,2.0], PyKDL.Wrench(PyKDL.Vector(5,5,5), PyKDL.Vector(5,5,5)), start_time=0.5):
    #     exitError(16)
    # if velma.waitForEffectorLeft() != 0:
    #     exitError(17)

    rospy.sleep(1.0)

    tf_world_to_table = Transform()
    #TODO give timeout
    while not rospy.is_shutdown():
        try:
            tf_world_to_table.trans, tf_world_to_table.rot = tf_listener.lookupTransform('/world','/table',rospy.Time(0))
            break
        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException) as e:
            continue

    world_to_table_tf_kdl = PyKDL.Frame(PyKDL.Rotation.Quaternion(*tf_world_to_table.rot),
                                        PyKDL.Vector(*tf_world_to_table.trans))

    print "Switch to cart_imp mode (no trajectory)..."
    if not velma.moveCartImpLeftCurrentPos(start_time=0.2):
        exitError(10)
    if velma.waitForEffectorLeft() != 0:
        exitError(11)

    TABLE_HEIGHT = 0.75
    potential_place_points = []
    # going through quadrants
    offset_x = [-0.4, 0.4, 0.4, -0.4]
    offset_y = [-0.4, -0.4, 0.4, 0.4]
    offset_z = TABLE_HEIGHT + 0.1

    # calculate potential place points
    for i in range(4):
        potential_place_points.append(PyKDL.Frame(PyKDL.Vector(offset_x[i],
                                                               offset_y[i],
                                                               offset_z)))

        potential_place_points[i] = world_to_table_tf_kdl * potential_place_points[i]

    broadcaster = tf.TransformBroadcaster()
    point_names = ["alpha", "bravo", "charlie", "delta"]

    i = 10000
    while i:
        i -= 1
        for p, n in zip(potential_place_points, point_names):
            broadcaster.sendTransform((p.p.x(), p.p.y(), p.p.z()),
                     p.M.GetQuaternion(),
                     rospy.Time.now(),
                     "place_point_" + n,
                     "world")

    min_distance = 100000.0
    place_point_name = "alpha"
    tf_left_tool_to_place_point = Transform()

    for pn in point_names:
        tf_left_tool_to_place_point_temp = Transform()
        while not rospy.is_shutdown():
            try:
                print "looking for left tool to place point " + pn + " tf"
                tf_left_tool_to_place_point_temp.trans, tf_left_tool_to_place_point_temp.rot = tf_listener.lookupTransform('/place_point_' + pn,'/left_arm_7_link',rospy.Time())
                break
            except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException) as e:
                continue
        distance = sum([a**2 for a in tf_left_tool_to_place_point_temp.trans])
        if distance < min_distance:
            place_point_name = pn
            min_distance = distance
            tf_left_tool_to_place_point = copy.copy(tf_left_tool_to_place_point_temp)

    point_names_tf_map = dict(zip(point_names, potential_place_points))

    tf_left_tool_to_world = Transform()
    while not rospy.is_shutdown():
        try:
            tf_left_tool_to_world.trans, tf_left_tool_to_world.rot = tf_listener.lookupTransform('/world','/left_arm_7_link',rospy.Time())
            break
        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException) as e:
            continue

    move_to_target(target_tool_rot=PyKDL.Rotation.Quaternion(*tf_left_tool_to_world.rot),
                   world_to_move_target_trans=[point_names_tf_map[place_point_name].p.x(),
                                               point_names_tf_map[place_point_name].p.y(),
                                               point_names_tf_map[place_point_name].p.z()],
                   offset_xyz=(0.0, 0.0, 0.1))

    # open gripper
    dest_q = [math.radians(0), math.radians(0), math.radians(0), math.radians(0)]
    velma.moveHandLeft(dest_q, [1, 1, 1, 1], [8000, 8000, 8000, 8000], 100000000, hold=False)
    if velma.waitForHandLeft() != 0:
        exitError(2)

    print "Switch to jnt_imp mode (no trajectory)..."
    velma.moveJointImpToCurrentPos(start_time=0.5)
    error = velma.waitForJoint()
    if error != 0:
        print "The action should have ended without error, but the error code is", error
        exitError(3)

    # back away after placing
    print "moving back to starting position"
    move(q_map_entry_place_pose, duration=1.5)
    move(q_map_entry_pick_pose, duration=3)
    planned_move(q_map_starting)

    # print "Checking if the starting configuration is as expected..."
    # rospy.sleep(0.5)
    # js = velma.getLastJointState()
    # if not isConfigurationClose(q_map_starting, js[1], tolerance=0.3):
    #     print "This test requires starting pose:"
    #     print q_map_starting
    #     exitError(10)

    exitError(0)
