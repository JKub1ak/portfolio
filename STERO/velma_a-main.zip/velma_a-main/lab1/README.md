# Ćwiczenie 1
**Autorzy**: Janusz Kubiak, Krzysztof Jóskowiak

## Zadanie
Należy napisać program, dzięki któremu Velma:
  * chwyci obiekt object1 stojący na pierwszym stoliku table1,
  * przeniesie go na drugi stolik table2,
  * odłoży go na drugim stoliku, tj. zwolni chwyt i wycofa ramię w pozycję początkową.

## Schemat działania
1. Rozejrzenie się wokół w celu wygenerowania octomapy.
2. Upewnienie się, że robot jest w pozycji startowej i ewentualney ruch do niej.
3. Ruch planowany w przestrzeni stawów do pozycji blisko stolika ze słoikiem.
4. Ruch w przestrzeni kartezjańskiej do słoika.
5. Złapanie słoika.
6. Podniesienie słoika.
7. Ruch w przestrzeni stawów do pozycji blisko stolika docelowego.
8. Wyliczenie potencjalnych punktów odstawienia słoika.
9. Ruch w przestrzeni kartezjańskiej do najbliższego aktualnej pozycji punktu.
10. Postawienie słoika.
11. Wykonanie ruchów 7-3-1 w celu powrotu do pozycji początkowej.

## Zdefiniowane funkcje
```python
def move(q_map,duration)
```
Wykonuje ruch bez planowania w przestrzeni stawów do pozycji *q_map* w czasie *duration*.

```python
def planned_move(q_map)
```
Wykonuje ruch z planowaniem uwzględniającym octomapę w przestrzeni stawów do pozycji *q_map*.

```python
def move_to_target(target_tool_rot, world_to_move_target_trans, offset_xyz=(0.0, 0.0, 0.0))
```
Wykonuje ruch w przestrzeni kartezjańskiej do pozycji wskazanej przez wektor *world_to_move_target_trans* (list) z rotacją *target_tool_rot* (PyKDL.Quaternion) i dodatkowym przesunięciem *offset_xyz*.


## Ładne obrazki
![Ładny obrazek 1](/docs/img/pretty_picture_1.png "Hehe słoik go ziuuu XDDD")
![Ładny obrazek 3](/docs/img/pretty_picture_3.png "Widok z potencjalnymi punktami odłożenia słoika")

^Widok z potencjalnymi punktami odłożenia słoika^
