# Dokumentacja projektów

**Autorzy:** Janusz Kubiak, Krzysztof Jóskowiak

[Lab 1](https://github.com/PW-EITI-STERO-20Z/velma_a/blob/main/lab1/README.md)

[Lab 2](https://github.com/PW-EITI-STERO-20Z/velma_a/blob/main/lab2/README.md)
