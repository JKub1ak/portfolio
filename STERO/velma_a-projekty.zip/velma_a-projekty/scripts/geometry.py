#!/usr/bin/env python

import PyKDL

class Transform(object):
    """docstring for Transform"""
    def __init__(self, trans=[], rot=[]):
        self.trans = trans
        self.rot = rot

def make_wrench(lx,ly,lz,rx,ry,rz):
    return PyKDL.Wrench(PyKDL.Vector(lx,ly,lz), PyKDL.Vector(rx,ry,rz))
