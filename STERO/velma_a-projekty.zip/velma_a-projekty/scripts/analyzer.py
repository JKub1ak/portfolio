#!/usr/bin/env python

import rospy
import math
import PyKDL
import tf
import copy
import sys

from geometry_msgs.msg import Pose
from std_msgs.msg import Int8, Float64
from nav_msgs.msg import Odometry
from gazebo_msgs.msg import ModelStates
from geometry import Transform, make_wrench
import rosservice
from gazebo_msgs.srv import GetModelState

class Analyzer(object):
	def __init__(self, odom_topic, dest_topic, ref_pose_topic, squareside_topic, sqlen, velma_model_number, rate=100):
		self._odom_msg = None
		self._dest_pose_msg = None
		self._ref_pose_msg = None
		self._prev_ref_pose_msg = None # for path error calculation

		# analyzer variables
		self._pose_error = 0
		self._path_error = 0
		self._total_path_error = 0
		self._side = 0
		self._rate = rospy.Rate(rate)
		self._sqlen = sqlen
		self._model_number = velma_model_number
		self._points = ((0,0),
						(self._sqlen,0),
						(self._sqlen,self._sqlen),
						(0,self._sqlen))

		self._odom_sub = rospy.Subscriber(odom_topic, Odometry, self._odom_callback)
		self._dest_pose_sub = rospy.Subscriber(dest_topic, Pose, self._dest_pose_callback)
		self._ref_pose_sub = rospy.Subscriber(ref_pose_topic, ModelStates, self._ref_pose_callback)
		self._squareside_sub = rospy.Subscriber(squareside_topic, Int8, self._squareside_callback)
		self._path_error_pub = rospy.Publisher("/analyzer/path_error", Float64,queue_size=1)
		self._pose_error_pub = rospy.Publisher("analyzer/pose_error", Float64,queue_size=1)


	def _odom_callback(self, odom_msg):
		self._odom_msg = odom_msg

	def _dest_pose_callback(self, pose_msg):
		self._dest_pose_msg = pose_msg

	def _ref_pose_callback(self, pose_msg):
		self._prev_ref_pose_msg = copy.copy(self._ref_pose_msg)
		self._ref_pose_msg = pose_msg.pose[self._model_number]
		if self._side == 1 :
			self._path_error = abs(self._ref_pose_msg.position.y)
		elif self._side == 2:
			self._path_error = abs(self._sqlen - self._ref_pose_msg.position.x)
		elif self._side == 3:
			self._path_error = abs(self._sqlen - self._ref_pose_msg.position.y)
		elif self._side == 4:
			self._path_error = abs(self._ref_pose_msg.position.x)

		if self._side == 1 or self._side == 3:
			self._total_path_error += self._path_error*abs(self._prev_ref_pose_msg.position.x-self._ref_pose_msg.position.x)
		elif self._side == 2 or self._side ==4:
			self._total_path_error += self._path_error*abs(self._prev_ref_pose_msg.position.y-self._ref_pose_msg.position.y)


	def _squareside_callback(self, side):
		self._side = side.data

	# def get_path_offset(self):

	def spin(self):
		while not rospy.is_shutdown():
			print 'err:{}, total_err:{}'.format(self._path_error,self._total_path_error)
			# print 'curr pose'
			# print self._ref_pose_msg
			# print 'prev pose'
			# print self._prev_ref_pose_msg
			self._rate.sleep()


if __name__ == "__main__":
	if sys.argv[1] != None:
		sqlen = float(sys.argv[1])
	else:
		print 'square length required'
		exit(1)

	if sys.argv[2] != None:
		velma_model_number = int(sys.argv[2])
	else:
		print 'gazebo model number required (use \'rostopic echo /gazebo/model_states/name\' to locate your model)'
		exit(1)

	rospy.init_node('analyzer')
	rospy.sleep(0.5)

	analyzer = Analyzer(odom_topic="/odom",
						dest_topic="/velma_dest_pose",
						ref_pose_topic="/gazebo/model_states",
						squareside_topic="/velma_squareside",
						velma_model_number=velma_model_number,
						sqlen=sqlen,
						rate=2)
	analyzer.spin()