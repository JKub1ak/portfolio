#include <ros/ros.h>
#include <base_local_planner/trajectory_planner_ros.h>
#include <global_planner/planner_core.h>
#include <costmap_2d/costmap_2d_ros.h>
#include <tf2_ros/transform_listener.h>
#include <geometry_msgs/TransformStamped.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Twist.h>
#include <gazebo_msgs/ModelStates.h>
#include <vector>
#include <string>
#include <iostream>

geometry_msgs::PoseStamped nav_goal;
geometry_msgs::PoseStamped gazebo_pose;
bool new_nav_goal;
bool gazebo_pose_ready;

void gazebo_model_states_callback(const gazebo_msgs::ModelStates::ConstPtr& msg);
void nav_goal_callback(const geometry_msgs::PoseStamped::ConstPtr& msg);

int main(int argc, char** argv)
{
  ros::init(argc, argv, "navigation_stack");
  ros::NodeHandle node;

  tf2_ros::Buffer tf_buffer;
  tf2_ros::TransformListener tf_listener(tf_buffer);
  costmap_2d::Costmap2DROS local_costmap("local_costmap", tf_buffer);
  costmap_2d::Costmap2DROS global_costmap("global_costmap", tf_buffer);
  base_local_planner::TrajectoryPlannerROS local_planner;
  global_planner::GlobalPlanner global_planner;
  local_planner.initialize("TrajectoryPlannerROS", &tf_buffer, &local_costmap);
  global_planner.initialize("GlobalPlanner", &global_costmap);
  assert(local_planner.isInitialized());

  std::cout << "Local cmap global_frame_id: " + local_costmap.getGlobalFrameID() +
            "\nGlobal cmap global_frame_id: " + global_costmap.getGlobalFrameID() + "\n";

  geometry_msgs::PoseStamped initial_pose;

  new_nav_goal = false;
  gazebo_pose_ready = false;
  ros::Subscriber goal_sub = node.subscribe("/move_base_simple/goal", 10, nav_goal_callback);
  //  ros::Subscriber gazebo_model_states_sub = node.subscribe("/gazebo/model_states", 1, gazebo_model_states_callback);
  ros::Publisher cmd_vel_pub = node.advertise<geometry_msgs::Twist>("/cmd_vel", 1);
  std::vector<geometry_msgs::PoseStamped> global_plan;
  geometry_msgs::Twist cmd_vel;

  ros::Rate loop_rate(10);

  ROS_INFO("Init Ok!");

  while(!global_costmap.getRobotPose(initial_pose));

  while(ros::ok())
  {
    if(new_nav_goal)
    {
      ROS_INFO("New nav goal arrives, making plans");
      if(!global_planner.makePlan(initial_pose, nav_goal, global_plan))
      {
        std::cout<<"Couldn't make global plan to pose " + initial_pose.header.frame_id + nav_goal.header.frame_id + "\n";
        ros::spinOnce();
        loop_rate.sleep();
        continue;
      }
      local_planner.setPlan(global_plan);
      ROS_INFO("Plans ready");
      new_nav_goal = false;
      while(!local_planner.isGoalReached() && !new_nav_goal)
      {
        local_planner.computeVelocityCommands(cmd_vel);
        ROS_INFO("Executing velocity commands");
        cmd_vel_pub.publish(cmd_vel);
        ros::spinOnce();
        loop_rate.sleep();
      }
      global_costmap.getRobotPose(initial_pose);
    }
    else
    {
      ROS_INFO("No new nav goal");
      ros::spinOnce();
      loop_rate.sleep();
    }
  }

}

// void gazebo_model_states_callback(const gazebo_msgs::ModelStates::ConstPtr& msg)
// {
//   ROS_INFO("Gazebo model states callback");
//   int model_no;
//   for(int i=0; i < msg->name.size(); ++i)
//   {
//     if(msg->name[i] == "velma") model_no = i;
//   }
//
//   gazebo_pose.pose = msg->pose[model_no];
//   gazebo_pose.header.frame_id = "map";
//   gazebo_pose_ready = true;
// }

void nav_goal_callback(const geometry_msgs::PoseStamped::ConstPtr& msg)
{
  ROS_INFO("Nav goal callback");
  nav_goal = *msg;
  //ROS_INFO(nav_goal.header.frame_id);
  std::cout << "nav goal frame msg" + msg->header.frame_id + "\n";
  std::cout << "nav goal frame copied" + nav_goal.header.frame_id + "\n";
  new_nav_goal = true;
}
