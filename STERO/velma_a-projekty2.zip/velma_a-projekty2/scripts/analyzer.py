#!/usr/bin/env python

import rospy
import math
import PyKDL
import tf
import copy
import sys

from geometry_msgs.msg import Pose
from nav_msgs.msg import Odometry
from gazebo_msgs import ModelStates
from geometry import Transform, make_wrench
from std_msgs import Float64

# topic callback message
odom = None

class Analyzer(object):
	def __init__(self, odom_topic, dest_topic, ref_pose_topic, rate=100):
		self._odom_sub = rospy.Subscriber(odom_topic, Odometry, self._odom_callback)
		self._dest_pose_sub = rospy.Subscriber(dest_topic, Pose, self._dest_pose_callback)
		self._ref_pose_sub = rospy.Subscriber(pose_topic, ModelStates, self._ref_pose_callback)
		self._path_error_pub = rospy.Publisher("/analyzer/path_error", Float64)
		self._pose_error_pub = rospy.Publisher("analyzer/pose_error", Float64)

		self._odom_msg
		self._dest_pose_msg
		self._ref_pose_msg
		self._prev_ref_pose_msg  # for path error calculation

		# analyzer variables
		self._pose_error = 0
		self._path_error = 0
		self._rate = rospy.Rate(rate)


	def _odom_callback(self, odom_msg):
		self._odom_msg = odom_msg

	def _dest_pose_callback(self, pose_msg):
		self._dest_pose_msg = pose_msg

	def _ref_pose_callback(self, pose_msg):
		self._prev_ref_pose_msg = self._ref_pose_msg
		self._ref_pose_msg = pose_msg

	def get_pose_offset(self):
		pass

	def get_path_offset(self):
		pass



if __name__ == "__main__":
	analyzer = Analyzer(odom_topic="/odom",
						dest_topic="/velma_dest_pose",
						ref_pose_topic="/gazebo/model_states",
						rate=100)
