#!/usr/bin/env python

import roslib; roslib.load_manifest('velma_task_cs_ros_interface')

import rospy
import math
import PyKDL
import tf
import copy
import sys
from enum import Enum

from velma_common import *
from control_msgs.msg import FollowJointTrajectoryResult
from geometry_msgs.msg import Twist, Pose
from nav_msgs.msg import Odometry
from survey_area import *
from rcprg_planner import *
from geometry import Transform, make_wrench
from move_robot import MoveRobot

odom = None
accel = None

def init_twist():
    ret = Twist()
    ret.linear.x = 0
    ret.linear.y = 0
    ret.linear.z = 0
    ret.angular.x = 0
    ret.angular.y = 0
    ret.angular.z = 0
    return ret

def move_straight(dist, accel, cmd_pub, dest_pub, dir = [1,0], rate = 50):
    global odom
    twist_msg = init_twist()
    r = rospy.Rate(rate)

    robot_frame = PyKDL.Frame(
            PyKDL.Rotation.Quaternion(odom.orientation.x,odom.orientation.y,odom.orientation.z,odom.orientation.w),
            PyKDL.Vector(odom.position.x,odom.position.y,odom.position.z))
    frame_halfway = PyKDL.Frame(PyKDL.Rotation(),PyKDL.Vector(dist*dir[0]/2,dist*dir[1]/2,0))
    frame_halfway = robot_frame*frame_halfway
    frame_there = PyKDL.Frame(PyKDL.Rotation(),PyKDL.Vector(dist*dir[0],dist*dir[1],0))
    frame_there = robot_frame*frame_there

    dest_pose_msg = Pose()
    dest_pose_msg.position.x = odom.position.x
    dest_pose_msg.position.y = odom.position.y
    dest_pose_msg.position.z = odom.position.z

    if sys.argv[1] == 'nodom':
        covered = 0
        last_covered = 0
        while covered < dist/2:
            twist_msg.linear.x += accel/rate*dir[0]
            twist_msg.linear.y += accel/rate*dir[1]
            covered += abs(twist_msg.linear.x/rate*dir[0]) + abs(twist_msg.linear.y/rate*dir[1])
            cmd_pub.publish(twist_msg)
            dest_pub.publish(dest_pose_msg)
            r.sleep()
        while covered > last_covered:
            last_covered = covered
            twist_msg.linear.x -= accel/rate*dir[0]
            twist_msg.linear.y -= accel/rate*dir[1]
            covered += abs(twist_msg.linear.x/rate*dir[0]) + abs(twist_msg.linear.y/rate*dir[1])
            cmd_pub.publish(twist_msg)
            dest_pub.publish(dest_pose_msg)
            r.sleep()
    elif sys.argv[1] == 'odom':
        err = 1000000
        last_err = 1000001
        while err <= last_err or err > 0.5:
            last_err = err
            err = (odom.position.x-frame_halfway.p.x())**2 + (odom.position.y-frame_halfway.p.y())**2 + (odom.position.z-frame_halfway.p.z())**2
            twist_msg.linear.x += accel/rate*dir[0]
            twist_msg.linear.y += accel/rate*dir[1]
            cmd_pub.publish(twist_msg)
            dest_pub.publish(dest_pose_msg)
            r.sleep()

        err = 1000000
        last_err = 1000001
        while err <= last_err or err > 0.5:
            last_err = err
            err = (odom.position.x-frame_there.p.x())**2 + (odom.position.y-frame_there.p.y())**2 + (odom.position.z-frame_there.p.z())**2
            twist_msg.linear.x -= accel/rate*dir[0]
            twist_msg.linear.y -= accel/rate*dir[1]
            cmd_pub.publish(twist_msg)
            dest_pub.publish(dest_pose_msg)
            r.sleep()

    cmd_pub.publish(init_twist())

def rotate(accel, cmd_pub, rate=50):
    covered = 0
    dist = math.pi/2
    msg = init_twist()
    r = rospy.Rate(rate) # 10hz

    if sys.argv[1] == 'nodom':
        while covered < dist/2:
            msg.angular.z += accel/rate
            covered += msg.angular.z/rate
            cmd_pub.publish(msg)
            r.sleep()
        while msg.angular.z > 0:
            msg.angular.z -= accel/rate
            covered += msg.angular.z/rate
            cmd_pub.publish(msg)
            r.sleep()
    elif sys.argv[1] == 'odom':
        robot_frame = PyKDL.Frame(
                PyKDL.Rotation.Quaternion(odom.orientation.x,odom.orientation.y,odom.orientation.z,odom.orientation.w),
                PyKDL.Vector(odom.position.x,odom.position.y,odom.position.z))
        frame_halfway = PyKDL.Frame(PyKDL.Rotation.EulerZYX(math.pi/4,0,0),PyKDL.Vector())
        frame_halfway = robot_frame*frame_halfway
        eul_halfway = frame_halfway.M.GetEulerZYX()
        frame_there = PyKDL.Frame(PyKDL.Rotation.EulerZYX(math.pi/2,0,0),PyKDL.Vector())
        frame_there = robot_frame*frame_there
        eul_there = frame_there.M.GetEulerZYX()
        err = 10000
        last_err = 10001
        while err <= last_err or err > 0.5:
            last_err = err
            err = abs(PyKDL.Rotation.Quaternion(odom.orientation.x,
                                                odom.orientation.y,
                                                odom.orientation.z,
                                                odom.orientation.w).GetEulerZYX()[0] - eul_halfway[0])
            msg.angular.z += accel/rate
            cmd_pub.publish(msg)
            r.sleep()
        err = 10000
        last_err = 10001
        while err <= last_err or err > 0.5:
            last_err = err
            err = abs(PyKDL.Rotation.Quaternion(odom.orientation.x,
                                                odom.orientation.y,
                                                odom.orientation.z,
                                                odom.orientation.w).GetEulerZYX()[0] - eul_there[0])
            msg.angular.z -= accel/rate
            cmd_pub.publish(msg)
            r.sleep()

    cmd_pub.publish(init_twist())

def do_square(cmd_pub, dest_pub, accel):
    rospy.sleep(2)
    print "Moving forward"
    move_straight(float(sys.argv[4]),accel,cmd_pub,dest_pub,[1,0],rate=50)
    print "Moving left"
    move_straight(float(sys.argv[4]),accel,cmd_pub,dest_pub,[0,1],rate=50)
    print "Moving back"
    move_straight(float(sys.argv[4]),accel,cmd_pub,dest_pub,[-1,0],rate=50)
    print "Moving right"
    move_straight(float(sys.argv[4]),accel,cmd_pub,dest_pub,[0,-1],rate=50)

def do_square_v2(cmd_pub, dest_pub, accel):
    rospy.sleep(0.5)
    for i in range(4):
        print "Moving forward"
        move_straight(float(sys.argv[4]),accel,cmd_pub,dest_pub,[1,0],rate=50)
        print "Turning"
        rotate(accel,cmd_pub)

def callback(data):
    global odom
    odom = data.pose.pose

if __name__ == "__main__":

    rospy.init_node('secure_velma')
    rospy.sleep(0.5)

    # initialize the robot, check starting position
    velma = VelmaInterface()
    robot = MoveRobot(velma)
    robot.initialize_robot()
    robot.secure_robot()
    rospy.sleep(0.5)



    rospy.sleep(1)
    exitError(0)
