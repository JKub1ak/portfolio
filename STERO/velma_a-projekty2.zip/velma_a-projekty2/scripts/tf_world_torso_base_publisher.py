#!/usr/bin/env python

import rospy
import math
import PyKDL
import tf2_ros
import copy
import sys

from gazebo_msgs.msg import ModelStates
from geometry_msgs.msg import TransformStamped


def model_states_callback(msg):
    model_no = 0
    for i in range(len(msg.name)):
        if msg.name[i] == 'velma':
            model_no = i
            break

    tf_world_torso_base = TransformStamped()
    tf_world_torso_base.header.stamp = rospy.Time.now()
    tf_world_torso_base.header.frame_id = 'world'
    tf_world_torso_base.child_frame_id = 'torso_base'
    tf_world_torso_base.transform.translation.x = msg.pose[model_no].position.x
    tf_world_torso_base.transform.translation.y = msg.pose[model_no].position.y
    tf_world_torso_base.transform.translation.z = msg.pose[model_no].position.z
    tf_world_torso_base.transform.rotation.x = msg.pose[model_no].orientation.x
    tf_world_torso_base.transform.rotation.y = msg.pose[model_no].orientation.y
    tf_world_torso_base.transform.rotation.z = msg.pose[model_no].orientation.z
    tf_world_torso_base.transform.rotation.w = msg.pose[model_no].orientation.w

    model_states_callback.tf_broadcaster.sendTransform(tf_world_torso_base)

model_states_callback.tf_broadcaster = tf2_ros.TransformBroadcaster()

if __name__ == '__main__':
    rospy.init_node('tf_world_torso_base_publisher')
    model_states_sub = rospy.Subscriber("/gazebo/model_states",
                                        ModelStates,
                                        model_states_callback)
    rospy.spin()
