#!/usr/bin/env python

## Runs test for jnt_imp mode motion.
# @ingroup integration_tests
# @file test_jimp.py
# @namespace scripts.test_jimp Integration test

# Copyright (c) 2017, Robot Control and Pattern Recognition Group,
# Institute of Control and Computation Engineering
# Warsaw University of Technology
#
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#     * Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of the Warsaw University of Technology nor the
#       names of its contributors may be used to endorse or promote products
#       derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL <COPYright HOLDER> BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# Author: Dawid Seredynski
#

import roslib; roslib.load_manifest('velma_task_cs_ros_interface')

import rospy
import math
import PyKDL
import tf
import copy
from enum import Enum

from velma_common import *
from control_msgs.msg import FollowJointTrajectoryResult
from survey_area import *
from rcprg_planner import *
from move_robot import MoveRobot, Side
from geometry import Transform, make_wrench


class OpenDoorTask:
    def __init__(self, velma, move_robot):
        self.opening_arm = Side.Undef
        self.velma = velma
        self.move_robot = move_robot
        self.arm_string = ''

        # position in a ready to open state
        self.q_map_ready_to_open = {'torso_0_joint':0,
                                    'left_arm_0_joint': -0.6866614078883287,
                                    'left_arm_1_joint': 1.8836200418542777,
                                    'left_arm_2_joint': -1.1901447618689311,
                                    'left_arm_3_joint': -1.9212832500287207,
                                    'left_arm_4_joint': -0.3394128998816182,
                                    'left_arm_5_joint': 0.5907277761846202,
                                    'left_arm_6_joint': 0.4240316698262875,
                                    'right_arm_0_joint': 0.6866614078883287,
                                    'right_arm_1_joint': -1.8836200418542777,
                                    'right_arm_2_joint': 1.1901447618689311,
                                    'right_arm_3_joint': 1.9212832500287207,
                                    'right_arm_4_joint': 0.3394128998816182,
                                    'right_arm_5_joint': -0.5907277761846202,
                                    'right_arm_6_joint': -0.4240316698262875}



    def rotate_towards_cabinet(self):
        tf_base_to_cabinet = self.velma.getTf("B", "cabinet")
        cabinet_angle_in_base = math.atan2(tf_base_to_cabinet.p.y(),
                                           tf_base_to_cabinet.p.x())
        assert abs(cabinet_angle_in_base) < math.pi/2, \
                "Cabinet out of reach"

        self.move_robot.rotate_base_in_starting_position(cabinet_angle_in_base)

    def choose_opening_arm(self):
        tf_base_to_cabinet = velma.getTf("cabinet", "B")
        cabinet_rotation = math.atan2(tf_base_to_cabinet.p.y(),
                                           tf_base_to_cabinet.p.x())
        assert abs(cabinet_rotation) < math.pi/4, \
                "Cabinet facing away from the robot - can't open"
        self.opening_arm = Side.Left if cabinet_rotation < 0 else Side.Right
        self.arm_string = 'left' if self.opening_arm == Side.Left else 'right'

    def prepare_hand(self):
        assert self.opening_arm != Side.Undef, \
               "Arm not chosen"
        move_robot.prepare_hand(self.opening_arm)

    def reset_hand(self):
        assert self.opening_arm != Side.Undef, \
               "Arm not chosen"
        velma.resetHand(self.arm_string)

    def reset_hands(self):
        velma.resetHand('left')
        velma.resetHand('right')

    def move_to_opening_position(self):
        _, q_map_target = velma.getLastJointState()
        for joint, val in q_map_target.items():
            if self.arm_string+'_arm' in joint:
                q_map_target[joint] = self.q_map_ready_to_open[joint]
        move_robot.move(q_map_target)

    def move_tool(self):
        print "Moving the "+self.arm_string+" tool and equilibrium pose from 'wrist' to 'grip' frame..."
        wrist = "Wr" if self.opening_arm == Side.Right else "Wl"
        tool = "Gr" if self.opening_arm == Side.Right else "Gl"
        tf_base_to_wrist = velma.getTf("B", wrist)
        tf_wrist_to_tool = velma.getTf(wrist, tool)
        assert velma.moveCartImp(self.arm_string,
                                 [tf_base_to_wrist*tf_wrist_to_tool], [0.1],
                                 [tf_wrist_to_tool], [0.1],
                                 None, None, PyKDL.Wrench(PyKDL.Vector(5,5,5), PyKDL.Vector(5,5,5)),
                                 start_time=0), \
               "Failed to move the tool"
        assert velma.waitForEffector(self.arm_string) == 0,\
               "Effector not responding"

        print "The "+self.arm_string+" tool moved successfuly"

    def bump_the_door(self):
        # calculate offset based on the opening arm
        offset_y = 0.07
        offset_y = -offset_y if self.opening_arm == Side.Left else offset_y
        offset = PyKDL.Vector(0.30,offset_y,0.04)

        # calculate rotation based on the opening arm
        rotation = PyKDL.Rotation.RPY(math.pi, math.pi/2, 0) if self.opening_arm == Side.Right else PyKDL.Rotation.RPY(0, -math.pi/2, 0)
        tf_cabinet_to_target1 = PyKDL.Frame(rotation, offset)

        # get a tf from base to cabinet -> from base to target destination
        tf_base_to_cabinet = velma.getTf("B", "cabinet")
        tf_base_to_target1 = tf_base_to_cabinet*tf_cabinet_to_target1

        # move to first target in front of the door (no bump yet)
        self.move_robot.move_to_target(self.opening_arm, tf_base_to_target1)

        # calculate offset for the first bump atempt
        offset = PyKDL.Vector(0.20,offset_y,0.04)
        tf_cabinet_to_target = PyKDL.Frame(rotation, offset)
        tf_base_to_target2 = tf_base_to_cabinet*tf_cabinet_to_target

        # enter low impedance on y and z in tool frame
        self.move_robot.enter_low_impedance(self.arm_string)
        world_to_move_target_diff = self.move_robot.move_to_target(self.opening_arm, tf_base_to_target2)

        err_tol = 0.05
        if world_to_move_target_diff.vel.Norm() > err_tol:
            print "Cabinet bumped successfuly"
        else:
            print "Cabinet not found. Trying a bit harder."
            offset = PyKDL.Vector(0.10,offset_y,0.04)
            tf_cabinet_to_target = PyKDL.Frame(rotation, offset)
            tf_base_to_target3 = tf_base_to_cabinet*tf_cabinet_to_target
            world_to_move_target_diff = self.move_robot.move_to_target(self.opening_arm, tf_base_to_target3)
            
            # error handling
            if world_to_move_target_diff.vel.Norm() < err_tol:
                print "Cabinet not found. What the heck?!\nReturning to opening position."
                world_to_move_target_diff = self.move_robot.move_to_target(self.opening_arm, tf_base_to_target3)
                world_to_move_target_diff = self.move_robot.move_to_target(self.opening_arm, tf_base_to_target2)
                world_to_move_target_diff = self.move_robot.move_to_target(self.opening_arm, tf_base_to_target1)
                self.move_to_opening_position()
                exit(1001)


        assert world_to_move_target_diff.rot.Norm() < 0.05, \
               "Difference between desired and reached rotation too high"


    def grab_handle(self):
        print "Grabbing the handle"
        # calculate offset based on the opening arm and it's current position
        tf_base_to_tool = velma.getTf("B", "Tl") if self.opening_arm == Side.Left else velma.getTf("B", "Tr")
        offset_y = 0.06
        offset = PyKDL.Vector(0,offset_y,0)
        offset_tf = PyKDL.Frame(PyKDL.Rotation.RPY(0,0,0), offset)
        tf_base_to_target = tf_base_to_tool*offset_tf
        self.move_robot.move_to_target(self.opening_arm, tf_base_to_target)


    def return_to_starting_position(self):
        print "Starting the return sequence"
        move_robot.exit_low_impedance(self.arm_string)
        task.move_to_opening_position()
        rospy.sleep(1)
        move_robot.return_to_starting_position()
        rospy.sleep(1)
        task.reset_hand()


    def moveto_point(self, tf, yaw, x, y, z=0.04, time=1):
        offset = PyKDL.Vector(x,y,z)
        rotation = PyKDL.Rotation.RPY(math.pi, math.pi/2, yaw) if self.opening_arm == Side.Right else PyKDL.Rotation.RPY(0, -math.pi/2, -yaw)
        tf_base_to_target = tf*PyKDL.Frame(rotation, offset)

        self.move_robot.move_to_target(self.opening_arm, tf_base_to_target, time=time)


    def open_door(self):
        print "Starting door opening sequence"
        yaw = 0
        # A set of points on a more or less circular path
        path_x = [0.15, 0.225, 0.285, 0.32,  0.363, 0.38,  0.41,  0.41,  0.41]
        path_y = [0.03, 0.041, 0.068, 0.093, 0.131, 0.169, 0.245, 0.276, 0.31]
        if self.opening_arm == Side.Left:
            path_y = [-y for y in path_y]

        tf_base_to_cabinet = velma.getTf("B", "cabinet")
        for x, y in zip(path_x, path_y):
            yaw += math.radians(11)
            self.moveto_point(tf_base_to_cabinet,yaw,x,y,time=0.75)

        print "Getting out of the handle"
        self.moveto_point(tf_base_to_cabinet,yaw,path_x[-1]-0.3,path_y[-1]+math.copysign(0.1,path_y[-1]),time=2)
        self.moveto_point(tf_base_to_cabinet,yaw,path_x[-1]-0.3,path_y[-1]+math.copysign(0.2,path_y[-1]),time=2)
        self.moveto_point(tf_base_to_cabinet,0,path_x[-1]+0.2,path_y[-1]+math.copysign(0.2,path_y[-1]),time=4)
        self.moveto_point(tf_base_to_cabinet,0,path_x[-1]+0.2,path_y[-1]-math.copysign(0.2,path_y[-1]),time=4)
        print "Pushing the door a little bit more"
        self.moveto_point(tf_base_to_cabinet,0,path_x[-1],path_y[-1]-math.copysign(0.2,path_y[-1]),time=2)
        self.moveto_point(tf_base_to_cabinet,0,path_x[-1],path_y[-1],time=2)
        self.moveto_point(tf_base_to_cabinet,0,path_x[-1]+0.2,path_y[-1]-math.copysign(0.2,path_y[-1]),time=3)


if __name__ == "__main__":

    # create node
    rospy.init_node('open_door')
    rospy.sleep(0.5)

    # initialize the robot, check starting position
    velma = VelmaInterface()
    move_robot = MoveRobot(velma)

    move_robot.initialize_robot()

    task = OpenDoorTask(velma, move_robot)
    task.rotate_towards_cabinet()
    task.choose_opening_arm()
    task.move_to_opening_position()
    task.move_tool()
    task.prepare_hand()
    task.bump_the_door()
    task.grab_handle()
    task.open_door()

    print "Task finished"
    rospy.sleep(0.5)

    task.return_to_starting_position()



    # TODO -ogarnac zeby rotacja nie wywalala
    #      -ogarnac zeby lewa reka tfa miala odpowiednio obroconego
    #      -just do the rest





    # move_robot.enter_jimp()
    # # back away after placing
    # print "Moving back to starting position"
    # move_robot.move(q_map_ready_to_open, duration=3)
    # move_robot.move(q_map_starting, duration=3)

    exitError(0)
