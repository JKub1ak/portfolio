#!/usr/bin/env python

import roslib; roslib.load_manifest('velma_task_cs_ros_interface')

import rospy
import math
import PyKDL
import tf
import copy
from enum import Enum

from velma_common import *
from control_msgs.msg import FollowJointTrajectoryResult
from survey_area import *
from rcprg_planner import *
from geometry import Transform, make_wrench

class MoveModes(Enum):
    Undef = 0
    Jimp = 1
    Cimp = 2

class Side(Enum):
    Undef = 0
    Left = 1
    Right = 2

class MoveRobot:
    def __init__(self, robot_interface):
        self.robot_interface = robot_interface
        self.current_mode = MoveModes.Undef
        self.q_map_starting = {'torso_0_joint':0,
                'right_arm_0_joint':-0.3,   'left_arm_0_joint':0.3,
                'right_arm_1_joint':-1.8,   'left_arm_1_joint':1.8,
                'right_arm_2_joint':1.25,   'left_arm_2_joint':-1.25,
                'right_arm_3_joint':0.85,   'left_arm_3_joint':-0.85,
                'right_arm_4_joint':0,      'left_arm_4_joint':0,
                'right_arm_5_joint':-0.5,   'left_arm_5_joint':0.5,
                'right_arm_6_joint':0,      'left_arm_6_joint':0 }

        self.q_map_secure = {'torso_0_joint':0,
                'right_arm_0_joint':-0.3,   'left_arm_0_joint':0.3,
                'right_arm_1_joint':-1.8,   'left_arm_1_joint':1.8,
                'right_arm_2_joint':1.25,   'left_arm_2_joint':-1.25,
                'right_arm_3_joint':1.6,   'left_arm_3_joint':-1.6,
                'right_arm_4_joint':0.0,    'left_arm_4_joint':-0.0,
                'right_arm_5_joint':-0.5,   'left_arm_5_joint':0.5,
                'right_arm_6_joint':0.5,      'left_arm_6_joint':-0.5 }

    def return_to_starting_position(self):
        # enter jnt_imp mode
        self.enter_jimp()
        # check starting position, if not as expected move to starting position
        print "Checking if the robot is in the starting configuration..."
        js = self.robot_interface.getLastJointState()
        if not isConfigurationClose(self.q_map_starting, js[1], tolerance=0.2):
            print "Moving to the starting position"
            self.move(self.q_map_starting)

    def rotate_base_in_starting_position(self, rot_angle):
        self.return_to_starting_position()
        q_map_base_rot = copy.copy(self.q_map_starting);
        q_map_base_rot['torso_0_joint'] = rot_angle
        self.move(q_map_base_rot)



    # initializes the robot and checks starting position
    def initialize_robot(self):
        print "Waiting for robot interface initialization..."
        assert self.robot_interface.waitForInit(timeout_s=10.0), \
               "Could not initialize robot interface\n"

        print "Initialization ok!\n"
        print "Motors must be enabled every time after the robot enters safe state."
        print "If the motors are already enabled, enabling them has no effect."
        print "Enabling motors..."
        assert self.robot_interface.enableMotors() == 0, \
               "Couldn't enable motors"

        rospy.sleep(0.5)

        diag = self.robot_interface.getCoreCsDiag()
        assert diag.motorsReady(), \
               "Motors must be homed and ready to use for this test."

        # get into startiong position
        # self.return_to_starting_position()

    def secure_robot(self):
        self.enter_cimp()
        self.prepare_hand(Side.Left)
        self.prepare_hand(Side.Right)
        self.enter_jimp()
        self.move(self.q_map_secure)
        rospy.loginfo("~~ROBOT SECURED~~")

    def move(self, q_map, duration=3, position_tol=15.0/180.0*math.pi, start_time=0.5):
        print "Moving to position"
        self.robot_interface.moveJoint(q_map, duration, start_time=0.5, position_tol=position_tol)
        self.robot_interface.waitForJoint()

        rospy.sleep(0.5)
        js = self.robot_interface.getLastJointState()
        assert isConfigurationClose(q_map, js[1], tolerance=0.1), \
               "End configuration error exceeds the tolerance"

        rospy.sleep(1.0)

    def enter_cimp(self):
        if self.current_mode != MoveModes.Cimp:
            print "Switch to cart_imp mode..."
            assert (self.robot_interface.moveCartImpLeftCurrentPos(start_time=0.2)
                    or self.robot_interface.moveCartImpRightCurrentPos(start_time=0.2)), \
                    "Could not initialize cart_imp mode"

            assert (self.robot_interface.waitForEffectorLeft() == 0
                    or self.robot_interface.waitForEffectorRight() == 0), \
                    "waitForEffectorRight or waitForEffectorLeft failed"

            self.current_mode = MoveModes.Cimp
            print "Mode switched to cart_imp"

    def enter_jimp(self):
        if self.current_mode != MoveModes.Jimp:
            print "Switching to jnt_imp mode..."
            self.robot_interface.moveJointImpToCurrentPos(start_time=0.5)
            assert self.robot_interface.waitForJoint() == 0, \
                   "Could not waitForJoint"
            self.current_mode = MoveModes.Jimp
            print "Mode switched to jnt_imp"

    def move_to_target(self, side, frame, time=3.0):
        self.enter_cimp()
        print "Moving {} wrist to pose defined in world frame...".format(side)

        assert side == Side.Left or side == Side.Right, \
               "side argument should be Side.Left or Side.Right, but is {}".format(side)

        if side == Side.Left:
            assert self.robot_interface.moveCartImpLeft([frame],
                                                        [time], None, None, None, None,
                                                        PyKDL.Wrench(PyKDL.Vector(5,5,5),
                                                        PyKDL.Vector(5,5,5)),
                                                        start_time=0.5), \
                   "moveCartImpLeft failed"

            assert self.robot_interface.waitForEffectorLeft() == 0, \
                   "Could not waitForEffectorLeft"

            rospy.sleep(0.5)
            world_to_move_target_diff = PyKDL.diff(frame,
                                                   self.robot_interface.getTf("B", "Tl"),
                                                   1.0)
        elif side == Side.Right:
            assert self.robot_interface.moveCartImpRight([frame],
                                                         [time], None, None, None, None,
                                                         PyKDL.Wrench(PyKDL.Vector(5,5,5),
                                                         PyKDL.Vector(5,5,5)),
                                                         start_time=0.5), \
                   "moveCartImpLeft failed"

            assert self.robot_interface.waitForEffectorRight() == 0, \
                   "Could not waitForEffectorRight"
            rospy.sleep(0.5)


        difference = PyKDL.diff(frame, self.robot_interface.getTf("B", "Tr"), 1.0) \
                     if side == Side.Right else \
                     PyKDL.diff(frame, self.robot_interface.getTf("B", "Tl"), 1.0)
        return difference

    def prepare_hand(self, side):
        assert side == Side.Left or side == Side.Right, \
               "side argument should be Side.Left or Side.Right, but is {}".format(side)
        dest_q1 = [math.radians(0), math.radians(0), math.radians(0), math.radians(180)]
        dest_q2 = [math.radians(100), math.radians(100), math.radians(100), math.radians(180)]

        if side == Side.Left:
            self.robot_interface.moveHandLeft(dest_q1, [1, 1, 1, 1],
                                              [8000, 8000, 8000, 8000],
                                              100000000, hold=False)
            assert self.robot_interface.waitForHandLeft() == 0, \
                "Could not waitForHandLeft"
            self.robot_interface.moveHandLeft(dest_q2, [1, 1, 1, 1],
                                              [8000, 8000, 8000, 8000],
                                              100000000, hold=False)
            assert self.robot_interface.waitForHandLeft() == 0, \
                "Could not waitForHandLeft"
        elif side == Side.Right:
            self.robot_interface.moveHandRight(dest_q1, [1, 1, 1, 1],
                                               [8000, 8000, 8000, 8000],
                                               100000000, hold=False)
            assert self.robot_interface.waitForHandRight() == 0, \
                "Could not waitForHandRight"
            self.robot_interface.moveHandRight(dest_q2, [1, 1, 1, 1],
                                              [8000, 8000, 8000, 8000],
                                              100000000, hold=False)
            assert self.robot_interface.waitForHandRight() == 0, \
                "Could not waitForHandLeft"
        rospy.sleep(0.5)

    def move_to_target_left(self, target_tool_rot, world_to_move_target_vector, offset_xyz=(0.0, 0.0, 0.0)):
        self.move_to_target(Side.Left,target_tool_rot,world_to_move_target_vector,offset_xyz)

    def move_to_target_right(self, target_tool_rot, world_to_move_target_vector, offset_xyz=(0.0, 0.0, 0.0)):
        self.move_to_target(Side.Right,target_tool_rot,world_to_move_target_vector,offset_xyz)

    def change_impedance(self,side,imp_list,imp_change_tlist):
        assert self.robot_interface.moveCartImp(side, None, None, None, None, imp_list, imp_change_tlist, PyKDL.Wrench(PyKDL.Vector(5,5,5), PyKDL.Vector(5,5,5)), start_time=0.5),\
               "Failed to set impedance"
        assert self.robot_interface.waitForEffector(side) == 0,\
               "Effector "+side+" not responding"
        rospy.sleep(1.0)


    def enter_low_impedance(self,side):
        print "Set impedance to (1000,125,125,150,150,150) in tool frame."
        imp_list = [make_wrench(1000,1000,1000,150,150,150),
                    make_wrench(1000,500,500,150,150,150),
                    make_wrench(1000,250,250,150,150,150),
                    make_wrench(1000,125,125,150,150,150)]
        imp_change_tlist = [0.5,1.0,1.5,2.0]
        self.change_impedance(side, imp_list, imp_change_tlist)

    def exit_low_impedance(self,side):
        print "Set impedance to (1000,1000,1000,150,150,150) in tool frame."
        imp_list = [make_wrench(1000,125,125,150,150,150),
                    make_wrench(1000,250,250,150,150,150),
                    make_wrench(1000,500,500,150,150,150),
                    make_wrench(1000,1000,1000,150,150,150)]
        imp_change_tlist = [0.5,1.0,1.5,2.0]
        self.change_impedance(side, imp_list, imp_change_tlist)
