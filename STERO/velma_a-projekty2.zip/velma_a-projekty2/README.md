# How to use

Swap the gazebo plugin source file in the `resource` folder with the one in `ws_velma_os`

```bash
roslaunch stero_mobile_init korytarz.launch
```
or

```bash
roslaunch stero_mobile_init parter.launch
```

wait for initalization to finish, then

```bash
roslaunch stero_mobile_init navigation_stack.launch
```

Use `2D Nav Goal` in `rviz` to give navigation goals
