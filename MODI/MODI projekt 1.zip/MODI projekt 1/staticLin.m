function [u,y] = staticLin(u0,K,a1,a2,a3,a4)
	u = [-1:0.001:1];
	y = zeros(1,length(u));
	y = K*(a1*u+a2*(u0^2+2*u0*(u-u0))+a3*(u0^3+3*u0^2*(u-u0))+a4*(u0^4+4*u0^3*(u-u0)));
end

