% parametry
uStep = 1;
K = 6;
T1 = 8;
T2 = 7;
a1 = -1.1;
a2 = -0.03;
a3 = 0.72;
a4 = 0.25;
set(0,'defaultLineLineWidth',1);

% symulacja punkt 3
ciagly = sim('ModelCiagly');

T = 10;
dyskretny = sim('ModelDyskretny');
figure;
plot(ciagly.y);
hold on;
plot(dyskretny.y);
title('Okres pr�bkowania 10s');
legend('model ci�g�y','model dyskretny','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('czas (s)');

%print('z3-ciagly-dyskretny-1','-dpng','-r400');
hold off;

T = 1;
dyskretny = sim('ModelDyskretny');
figure;
plot(ciagly.y);
hold on;
plot(dyskretny.y);
title('Okres pr�bkowania 1s');
legend('model ci�g�y','model dyskretny','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('czas (s)');

%print('z3-ciagly-dyskretny-2','-dpng','-r400');
hold off;

T = 0.1;
dyskretny1 = sim('ModelDyskretny');
figure;
plot(ciagly.y);
hold on;
plot(dyskretny1.y);
title('Okres pr�bkowania 0.1s');
legend('model ci�g�y','model dyskretny','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('czas (s)');

%print('z3-ciagly-dyskretny-3','-dpng','-r400');
hold off;

% charakterystyka statyczna punkt 4
us = [-1:0.001:1];
ys = zeros(1,length(us));
ys=K*(a1*us+a2*us.^2+a3*us.^3+a4*us.^4);
figure;
plot(us,ys);
title('Charakterystyka statyczna');
ylabel('sygna� wyj�ciowy y');
xlabel('sygna� wej�ciowy u');

%print('z4-statyczna','-dpng','-r400');
hold off;

% charakterystyki punkt 6
pl = -0.5;
[ul,yl] = staticLin(pl,K,a1,a2,a3,a4);
figure;
plot(us,ys);
hold on;
plot(ul,yl);
title('Charakterystyka statyczna zlinearyzowana u0=-0.5');
legend('nieliniowa','zlinearyzowana','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('sygna� wej�ciowy u');

%print('z6-statyczna zlin1','-dpng','-r400');
hold off;

pl = 0;
[ul,yl] = staticLin(pl,K,a1,a2,a3,a4);
figure;
plot(us,ys);
hold on;
plot(ul,yl);
title('Charakterystyka statyczna zlinearyzowana u0=0');
legend('nieliniowa','zlinearyzowana','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('sygna� wej�ciowy u');

%print('z6-statyczna zlin2','-dpng','-r400');
hold off;

pl = 0.5;
[ul,yl] = staticLin(pl,K,a1,a2,a3,a4);
figure;
plot(us,ys);
hold on;
plot(ul,yl);
title('Charakterystyka statyczna zlinearyzowana u0=0.5');
legend('nieliniowa','zlinearyzowana','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('sygna� wej�ciowy u');

%print('z6-statyczna zlin3','-dpng','-r400');
hold off;

pl = 1;
[ul,yl] = staticLin(pl,K,a1,a2,a3,a4);
figure;
plot(us,ys);
hold on;
plot(ul,yl);
title('Charakterystyka statyczna zlinearyzowana u0=1');
legend('nieliniowa','zlinearyzowana','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('sygna� wej�ciowy u');

%print('z6-statyczna zlin4','-dpng','-r400');
hold off;

% symulacja punkt 9
% step 0-1
T = 1;

pl = -0.5;
Beta = K*T/(T1*T2)*(a1 +2*a2*pl +3*a3*pl^2 +4*a4*pl^3);
Gamma = K*T/(T1*T2)*(a2*pl^2 +2*a3*pl^3 +3*a4*pl^4);
dysLin = sim('ModelDyskretnyLiniowy');

figure;
plot(dyskretny.y);
hold on;
plot(dysLin.y);
title('Por�wnanie linearyzacji: skok 0-1, u0=-0.5');
legend('nieliniowa','zlinearyzowana','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('czas (s)');

%print('z9-step01u-05','-dpng','-r400');
hold off;

pl = 0;
Beta = K*T/(T1*T2)*(a1 +2*a2*pl +3*a3*pl^2 +4*a4*pl^3);
Gamma = K*T/(T1*T2)*(a2*pl^2 +2*a3*pl^3 +3*a4*pl^4);
dysLin = sim('ModelDyskretnyLiniowy');

figure;
plot(dyskretny.y);
hold on;
plot(dysLin.y);
title('Por�wnanie linearyzacji: skok 0-1, u0=0');
legend('nieliniowa','zlinearyzowana','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('czas (s)');

%print('z9-step01u0','-dpng','-r400');
hold off;

pl = 0.5;
Beta = K*T/(T1*T2)*(a1 +2*a2*pl +3*a3*pl^2 +4*a4*pl^3);
Gamma = K*T/(T1*T2)*(a2*pl^2 +2*a3*pl^3 +3*a4*pl^4);
dysLin = sim('ModelDyskretnyLiniowy');

figure;
plot(dyskretny.y);
hold on;
plot(dysLin.y);
title('Por�wnanie linearyzacji: skok 0-1, u0=0.5');
legend('nieliniowa','zlinearyzowana','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('czas (s)');

%print('z9-step01u05','-dpng','-r400');
hold off;

pl = 1;
Beta = K*T/(T1*T2)*(a1 +2*a2*pl +3*a3*pl^2 +4*a4*pl^3);
Gamma = K*T/(T1*T2)*(a2*pl^2 +2*a3*pl^3 +3*a4*pl^4);
dysLin = sim('ModelDyskretnyLiniowy');

figure;
plot(dyskretny.y);
hold on;
plot(dysLin.y);
title('Por�wnanie linearyzacji: skok 0-1, u0=1');
legend('nieliniowa','zlinearyzowana','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('czas (s)');

%print('z9-step01u1','-dpng','-r400');
hold off;

% step 0-(0.5)

uStep = 0.5;
dyskretny = sim('ModelDyskretny');

pl = -0.5;
Beta = K*T/(T1*T2)*(a1 +2*a2*pl +3*a3*pl^2 +4*a4*pl^3);
Gamma = K*T/(T1*T2)*(a2*pl^2 +2*a3*pl^3 +3*a4*pl^4);
dysLin = sim('ModelDyskretnyLiniowy');

figure;
plot(dyskretny.y);
hold on;
plot(dysLin.y);
title('Por�wnanie linearyzacji: skok 0-0.5, u0=-0.5');
legend('nieliniowa','zlinearyzowana','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('czas (s)');

%print('z9-step005u-05','-dpng','-r400');
hold off;

pl = 0;
Beta = K*T/(T1*T2)*(a1 +2*a2*pl +3*a3*pl^2 +4*a4*pl^3);
Gamma = K*T/(T1*T2)*(a2*pl^2 +2*a3*pl^3 +3*a4*pl^4);
dysLin = sim('ModelDyskretnyLiniowy');

figure;
plot(dyskretny.y);
hold on;
plot(dysLin.y);
title('Por�wnanie linearyzacji: skok 0-0.5, u0=0');
legend('nieliniowa','zlinearyzowana','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('czas (s)');

%print('z9-step005u0','-dpng','-r400');
hold off;

pl = 0.5;
Beta = K*T/(T1*T2)*(a1 +2*a2*pl +3*a3*pl^2 +4*a4*pl^3);
Gamma = K*T/(T1*T2)*(a2*pl^2 +2*a3*pl^3 +3*a4*pl^4);
dysLin = sim('ModelDyskretnyLiniowy');

figure;
plot(dyskretny.y);
hold on;
plot(dysLin.y);
title('Por�wnanie linearyzacji: skok 0-0.5, u0=0.5');
legend('nieliniowa','zlinearyzowana','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('czas (s)');

%print('z9-step005u05','-dpng','-r400');
hold off;

pl = 1;
Beta = K*T/(T1*T2)*(a1 +2*a2*pl +3*a3*pl^2 +4*a4*pl^3);
Gamma = K*T/(T1*T2)*(a2*pl^2 +2*a3*pl^3 +3*a4*pl^4);
dysLin = sim('ModelDyskretnyLiniowy');

figure;
plot(dyskretny.y);
hold on;
plot(dysLin.y);
title('Por�wnanie linearyzacji: skok 0-0.5, u0=1');
legend('nieliniowa','zlinearyzowana','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('czas (s)');

%print('z9-step005u1','-dpng','-r400');
hold off;

% step 0-(-0.25)

uStep = -0.25;
dyskretny = sim('ModelDyskretny');

pl = -0.5;
Beta = K*T/(T1*T2)*(a1 +2*a2*pl +3*a3*pl^2 +4*a4*pl^3);
Gamma = K*T/(T1*T2)*(a2*pl^2 +2*a3*pl^3 +3*a4*pl^4);
dysLin = sim('ModelDyskretnyLiniowy');

figure;
plot(dyskretny.y);
hold on;
plot(dysLin.y);
title('Por�wnanie linearyzacji: skok 0-(-0.25), u0=-0.5');
legend('nieliniowa','zlinearyzowana','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('czas (s)');

%print('z9-step0-05u-05','-dpng','-r400');
hold off;

pl = 0;
Beta = K*T/(T1*T2)*(a1 +2*a2*pl +3*a3*pl^2 +4*a4*pl^3);
Gamma = K*T/(T1*T2)*(a2*pl^2 +2*a3*pl^3 +3*a4*pl^4);
dysLin = sim('ModelDyskretnyLiniowy');

figure;
plot(dyskretny.y);
hold on;
plot(dysLin.y);
title('Por�wnanie linearyzacji: skok 0-(-0.25), u0=0');
legend('nieliniowa','zlinearyzowana','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('czas (s)');

%print('z9-step0-05u0','-dpng','-r400');
hold off;

pl = 0.5;
Beta = K*T/(T1*T2)*(a1 +2*a2*pl +3*a3*pl^2 +4*a4*pl^3);
Gamma = K*T/(T1*T2)*(a2*pl^2 +2*a3*pl^3 +3*a4*pl^4);
dysLin = sim('ModelDyskretnyLiniowy');

figure;
plot(dyskretny.y);
hold on;
plot(dysLin.y);
title('Por�wnanie linearyzacji: skok 0-(-0.25), u0=0.5');
legend('nieliniowa','zlinearyzowana','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('czas (s)');

%print('z9-step0-05u05','-dpng','-r400');
hold off;

pl = 1;
Beta = K*T/(T1*T2)*(a1 +2*a2*pl +3*a3*pl^2 +4*a4*pl^3);
Gamma = K*T/(T1*T2)*(a2*pl^2 +2*a3*pl^3 +3*a4*pl^4);
dysLin = sim('ModelDyskretnyLiniowy');

figure;
plot(dyskretny.y);
hold on;
plot(dysLin.y);
title('Por�wnanie linearyzacji: skok 0-(-0.25), u0=1');
legend('nieliniowa','zlinearyzowana','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('czas (s)');

%print('z9-step0-05u1','-dpng','-r400');
hold off;

% step 0-(-0.5)

uStep = -0.5;
dyskretny = sim('ModelDyskretny');

pl = -0.5;
Beta = K*T/(T1*T2)*(a1 +2*a2*pl +3*a3*pl^2 +4*a4*pl^3);
Gamma = K*T/(T1*T2)*(a2*pl^2 +2*a3*pl^3 +3*a4*pl^4);
dysLin = sim('ModelDyskretnyLiniowy');

figure;
plot(dyskretny.y);
hold on;
plot(dysLin.y);
title('Por�wnanie linearyzacji: skok 0-(-0.5), u0=-0.5');
legend('nieliniowa','zlinearyzowana','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('czas (s)');

%print('z9-step0-1u-05','-dpng','-r400');
hold off;

pl = 0;
Beta = K*T/(T1*T2)*(a1 +2*a2*pl +3*a3*pl^2 +4*a4*pl^3);
Gamma = K*T/(T1*T2)*(a2*pl^2 +2*a3*pl^3 +3*a4*pl^4);
dysLin = sim('ModelDyskretnyLiniowy');

figure;
plot(dyskretny.y);
hold on;
plot(dysLin.y);
title('Por�wnanie linearyzacji: skok 0-(-0.5), u0=0');
legend('nieliniowa','zlinearyzowana','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('czas (s)');

%print('z9-step0-1u0','-dpng','-r400');
hold off;

pl = 0.5;
Beta = K*T/(T1*T2)*(a1 +2*a2*pl +3*a3*pl^2 +4*a4*pl^3);
Gamma = K*T/(T1*T2)*(a2*pl^2 +2*a3*pl^3 +3*a4*pl^4);
dysLin = sim('ModelDyskretnyLiniowy');

figure;
plot(dyskretny.y);
hold on;
plot(dysLin.y);
title('Por�wnanie linearyzacji: skok 0-(-0.5), u0=0.5');
legend('nieliniowa','zlinearyzowana','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('czas (s)');

%print('z9-step0-1u05','-dpng','-r400');
hold off;

pl = 1;
Beta = K*T/(T1*T2)*(a1 +2*a2*pl +3*a3*pl^2 +4*a4*pl^3);
Gamma = K*T/(T1*T2)*(a2*pl^2 +2*a3*pl^3 +3*a4*pl^4);
dysLin = sim('ModelDyskretnyLiniowy');

figure;
plot(dyskretny.y);
hold on;
plot(dysLin.y);
title('Por�wnanie linearyzacji: skok 0-(-0.5), u0=1');
legend('nieliniowa','zlinearyzowana','Location','northeast');
ylabel('sygna� wyj�ciowy y');
xlabel('czas (s)');

%print('z9-step0-1u1','-dpng','-r400');
hold off;

% wzmocnienie statyczne K_stat(u0) punkt 11
Ks=zeros(length(us));
Ks=5.9832*us.^3+12.9274*us.^2-0.3575*us-6.5866;

figure;
plot(us,Ks);

title('Wzmocnienie statyczne K_{stat}(u0)');
ylabel('Wzmocnienie statyczne');
xlabel('u0');
%print('z11-K_stat(u0)','-dpng','-r400');
