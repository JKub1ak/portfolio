x = [4.7987 1.7019 2.9263 1.1191 3.7563 1.2755 2.5298;
	 3.4954 4.4545 4.7965 2.7361 0.6931 0.7465 1.2875]';
y = [1.5444 0.3756 0.4553 -0.2349 1.1397 0.9478 0.5447]';

M = [x(:,1) x(:,2) ones(length(x),1)];

w = M\y;
for i = 1:length(x)
	e = ([x(i,:) 1]*w)^2;
end
e = e/length(x)
yout = [x ones(length(x),1)]*w;

xwer = [3.8958 4.6701 0.6495 2.8441; 
		2.3470 0.0595 1.6856 0.8109]';
ywer = [1.4835 1.7167 0.6183 0.5483]';
for i = 1:length(xwer)
	ewer = ([xwer(i,:) 1]*w)^2;
end
ewer = ewer/length(xwer)


[X,Y] = meshgrid(0:0.1:5);
Z = X*w(1)+Y*w(2)+w(3);

figure;
plot3(xwer(:,1),xwer(:,2),ywer,'or');
hold on;
%plot3(x(:,1),x(:,2),y,'ob');
grid on;
s = surf(X,Y,Z,'FaceAlpha',0.5);
s.EdgeColor = 'none';
axis([0 5 0 5]);
title('Funkcja y(x1,x2) i punkty zbioru weryfikuj�cego');