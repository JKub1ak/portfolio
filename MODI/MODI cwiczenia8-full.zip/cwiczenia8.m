%trzeba odpali� z odpskok1.mat i odpskok2.mat w tym samym folderze

load('odpskok1');

figure;
plot(t,y);
title('odpskok1');
xlabel('czas');
ylabel('amplituda');
%print('odpskok1','-dpng','-r400');

k = -4;
T0 = 10;
T = 20;

s = tf('s');
sys = exp(-T0*s)*k/(T*s+1);

figure;
plot(t,y,'m');
hold on;
stepplot(sys,t);
title('odpskok1+');
xlabel('czas');
ylabel('amplituda');
legend('y(t)','ys(t)');
hold off;
%print('odpskok1+','-dpng','-r400');

load('odpskok2');

figure;
plot(t,y);
title('odpskok2');
xlabel('czas');
ylabel('amplituda');
%print('odpskok2','-dpng','-r400');

k =	0.01;
T0 = 5;
sys = exp(-T0*s)*k/s;

figure;
plot(t,y,'m');
hold on;
stepplot(sys,t);
title('odpskok2+');
xlabel('czas');
ylabel('amplituda');
legend('y(t)','ys(t)');
hold off;
%print('odpskok2+','-dpng','-r400');
