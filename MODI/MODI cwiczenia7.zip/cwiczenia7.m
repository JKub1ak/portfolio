% praca domowa z �wicze� MODI

% zadanie 1
% a)
a = [0 0];
r = [0.001 0.001];
K = [50000 50000];
tspan = [0 365*40];
x0 = [1000 1000];
[t, x] = ode45(@(t,x) odefun(t,x,a,r,K), tspan, x0);

a1 = figure;
plot(t,x(:,1));
hold on;
plot(t,x(:,2));
legend('x_1','x_2','Location','northwest');
title('Populacje bez interakcji a)');
hold off;

% b)
r(2) = 0.0012;
[t, x] = ode45(@(t,x) odefun(t,x,a,r,K), tspan, x0);

b1 = figure;
plot(t,x(:,1));
hold on;
plot(t,x(:,2));
legend('x_1','x_2','Location','northwest');
title('Populacje bez interakcji b)');
hold off;

% c)
r(2) = 0.0015;
[t, x] = ode45(@(t,x) odefun(t,x,a,r,K), tspan, x0);

c1 = figure;
plot(t,x(:,1));
hold on;
plot(t,x(:,2));
legend('x_1','x_2','Location','northwest');
title('Populacje bez interakcji c)');
hold off;

% zadanie 2
a = [10^(-7) 10^(-7)];
r = [0.001 0.0012];
% a)
x0 = [1000 100];
[t, x] = ode45(@(t,x) odefun(t,x,a,r,K), tspan, x0);

a2 = figure;
plot(t,x(:,1));
hold on;
plot(t,x(:,2));
legend('x_1','x_2','Location','northwest');
title('Pop. z interakcji� i ma�� r�nic� w przyro�cie a)');
hold off;

% b)
x0(2) = 500;
[t, x] = ode45(@(t,x) odefun(t,x,a,r,K), tspan, x0);

b2 = figure;
plot(t,x(:,1));
hold on;
plot(t,x(:,2));
legend('x_1','x_2','Location','northwest');
title('Pop. z interakcji� i ma�� r�nic� w przyro�cie b)');
hold off;

% c)
x0(2) = 1000;
[t, x] = ode45(@(t,x) odefun(t,x,a,r,K), tspan, x0);

c2 = figure;
plot(t,x(:,1));
hold on;
plot(t,x(:,2));
legend('x_1','x_2','Location','northwest');
title('Pop. z interakcji� i ma�� r�nic� w przyro�cie c)');
hold off;

% zadanie 3
r = [0.001 0.002];
% a)
x0 = [1000 100];
[t, x] = ode45(@(t,x) odefun(t,x,a,r,K), tspan, x0);

a3 = figure;
plot(t,x(:,1));
hold on;
plot(t,x(:,2));
legend('x_1','x_2','Location','northwest');
title('Pop. z interakcji� i du�� r�nic� w przyro�cie a)');
hold off;

% b)
x0(2) = 500;
[t, x] = ode45(@(t,x) odefun(t,x,a,r,K), tspan, x0);

b3 = figure;
plot(t,x(:,1));
hold on;
plot(t,x(:,2));
legend('x_1','x_2','Location','northwest');
title('Pop. z interakcji� i du�� r�nic� w przyro�cie b)');
hold off;

% c)
x0(2) = 1000;
[t, x] = ode45(@(t,x) odefun(t,x,a,r,K), tspan, x0);

c3 = figure;
plot(t,x(:,1));
hold on;
plot(t,x(:,2));
legend('x_1','x_2','Location','northwest');
title('Pop. z interakcji� i du�� r�nic� w przyro�cie c)');
hold off;

% prints:
set(0,'defaultLineLineWidth',1);

%print(a1, 'zadanie_1_a','-dpng','-r400');
%print(b1, 'zadanie_1_b','-dpng','-r400');
%print(c1, 'zadanie_1_c','-dpng','-r400');

%print(a2, 'zadanie_2_a','-dpng','-r400');
%print(b2, 'zadanie_2_b','-dpng','-r400');
%print(c2, 'zadanie_2_c','-dpng','-r400');

%print(a3, 'zadanie_3_a','-dpng','-r400');
%print(b3, 'zadanie_3_b','-dpng','-r400');
%print(c3, 'zadanie_3_c','-dpng','-r400');

