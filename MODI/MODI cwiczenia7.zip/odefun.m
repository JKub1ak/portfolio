function dydt = odefun(t,x,a,r,K)
	dydt = [(r(1)-r(1)/K(1)*x(1)-a(1)*x(2))*x(1);
			(r(2)-r(2)/K(2)*x(2)-a(2)*x(1))*x(2)];
end