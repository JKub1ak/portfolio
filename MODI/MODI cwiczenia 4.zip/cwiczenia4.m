%skrypt licz�cy funkcje i rysuj�cy wykresy

%wszystko dla alfy = 0.02

%zadanie 2
%figure 1

[F1s, F2s, Y] = przemiel(0);

figure
s = surf(F1s,F2s,Y);
s.EdgeColor = 'none';
xlabel('F1');
ylabel('F2');
zlabel('h(F1,F2)');
%print('rysunek1','-dpng','-r400');


%zadanie 4
%figure 2 i 3

%przezroczystosc niezlinearyzowanej funkcji
vis = 0.85;
%kolor zlinearyzowanej funkcji
color = [0,0,0];

[F1s, F2s, Y] = przemiel(1);

figure
s = surf(F1s,F2s,Y);
s.EdgeColor = 'none';
s.FaceColor = color;

hold on;

[F1s, F2s, Y] = przemiel(0);

s = surf(F1s,F2s,Y);
s.EdgeColor = 'none';
s.FaceAlpha = vis;
%s.FaceColor = [0.75,0.75,0.75];
xlabel('F1');
ylabel('F2');
zlabel('h(F1,F2)');
hold off;
%print('rysunek2','-dpng','-r400');

figure
s = surf(F1s,F2s,Y);
s.EdgeColor = 'none';
s.FaceAlpha = vis;
%s.FaceColor = [0.75,0.75,0.75];
xlabel('F1');
ylabel('F2');
zlabel('h(F1,F2)');
hold on;

[F1s, F2s, Y] = przemiel(2);

s = surf(F1s,F2s,Y);
s.EdgeColor = 'none';
s.FaceColor = color;
hold off;
%print('rysunek3','-dpng','-r400');