function x = fun(F1,F2)
%funkcja nieliniowa
x = (F1 + F2)^2/(0.02)^2;
end

