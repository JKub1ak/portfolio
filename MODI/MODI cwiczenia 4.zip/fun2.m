function x = fun2(F1,F2)
	%funkcja zlinearyzowana
	%punkt linearyzacji:
	F1_0 = 0.005;
	F2_0 = 0.005;
	x = 1/(0.02)^2 * (  (F1_0 + F2_0)^2 + (2*F1_0 + 2*F2_0)*(F1 + F2 - (F1_0 + F2_0))  );
end