function [F1s,F2s,Y] = przemiel(n)
	%funkcja licz�ca warto�ci funkcji w punktach
	F1s = 1:200;
	F2s = 1:200;
	Y = zeros(200,200);
	i = 0;
	for F1 = 0.000001:0.0001:0.02
		i = i+1;
		j = 1;
		F1s(i) = F1;
		for F2 = 0.000001:0.0001:0.02
			F2s(j) = F2;
			if n == 0
				Y(i,j) = fun(F1,F2);
			elseif n == 1
				Y(i,j) = fun2(F1,F2);
			elseif n == 2
				Y(i,j) = fun3(F1,F2);
			end
			j = j+1;
		end
	end
end

