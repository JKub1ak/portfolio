load('importedData.mat');

u_ = [-1:0.01:1]';
uf = danestat12(:,1);
yf = danestat12(:,2);
u = [];
y = [];
uw = [];
yw = [];

[uf,I] = sort(uf);
for i = 1:1:length(uf)
	if mod(i,2) == 1
		u(length(u)+1,1) = uf(i);
		y(length(y)+1,1) = yf(I(i));
	else
		uw(length(uw)+1,1) = uf(i);
		yw(length(yw)+1,1) = yf(I(i));
	end
end

% kt�ry model odpali�
% model == 0 - wszystkie
% model == 1-6 - stopnie modelu
model = 0;

% printowanie wykres�w
% doPrint == 1 - print(), else nie
doPrint = 0;

figure;
tiledlayout(2,1);

ax1 = nexttile;
scatter(ax1,u,y,'g');
title('Zbi�r ucz�cy');
ax2 = nexttile;
scatter(ax2,uw,yw,'r');
title('Zbi�r weryfikuj�cy');

if doPrint == 1
	print('StatZbiory','-dpng','-r400');
end
	

M = [ones(length(u),1),u];

% model stopnia 1
if model == 1 || model == 0
	w = M\y;
	% wyj�cia modelu dla danych ucz�cych
	U = [ones(length(u),1) u];
	y_ = U*w;
	% wyj�cia modelu dla danych weryfikuj�cych
	Uw = [ones(length(uw),1) uw];
	yw_ = Uw*w;
	% wyj�cia modelu w przedziale -1 1 w celach rysunkowych
	U_ = [ones(length(u_),1) u_];
	Y_ = U_*w;
	
	figure;
	tiledlayout(2,1);
	
	ax1 = nexttile;
	scatter(ax1,u,y,'g');
	hold on;
	plot(ax1,u_,Y_,'b');
	title('Zbi�r ucz�cy');
	
	ax2 = nexttile;
	scatter(ax2,uw,yw,'r');
	hold on;
	plot(ax2,u_,Y_,'b');
	title('Zbi�r weryfikuj�cy');
	
	if (doPrint == 1)
		print('StatStop1','-dpng','-r400');
	end
	
	fprintf("B��dy modelu pierwszego stopnia:\n");
	E = sum((y_-y).^2);
	fprintf("B��d danych ucz�cych: %f\n",E);
	Ew = sum((yw_-yw).^2);
	fprintf("B��d danych weryfikuj�cych: %f\n",Ew);
	
end

M = [M,u.^2];

% model stopnia 2
if model == 2 || model == 0
	w = M\y;
	% wyj�cia modelu dla danych ucz�cych
	U = [ones(length(u),1) u u.^2];
	y_ = U*w;
	% wyj�cia modelu dla danych weryfikuj�cych
	Uw = [ones(length(uw),1) uw  uw.^2];
	yw_ = Uw*w;
	% wyj�cia modelu w przedziale -1 1 w celach rysunkowych
	U_ = [ones(length(u_),1) u_  u_.^2];
	Y_ = U_*w;
	
	figure;
	tiledlayout(2,1);
	
	ax1 = nexttile;
	scatter(ax1,u,y,'g');
	hold on;
	plot(ax1,u_,Y_,'b');
	title('Zbi�r ucz�cy');
	
	ax2 = nexttile;
	scatter(ax2,uw,yw,'r');
	hold on;
	plot(ax2,u_,Y_,'b');
	title('Zbi�r weryfikuj�cy');
	
	if (doPrint == 1)
		print('StatStop2','-dpng','-r400');
	end
	
	fprintf("B��dy modelu drugiego stopnia:\n");
	E = sum((y_-y).^2);
	fprintf("B��d danych ucz�cych: %f\n",E);
	Ew = sum((yw_-yw).^2);
	fprintf("B��d danych weryfikuj�cych: %f\n",Ew);
	
end

M = [M,u.^3];

% model stopnia 3
if model == 3 || model == 0
	w = M\y;
	% wyj�cia modelu dla danych ucz�cych
	U = [ones(length(u),1) u u.^2 u.^3];
	y_ = U*w;
	% wyj�cia modelu dla danych weryfikuj�cych
	Uw = [ones(length(uw),1) uw  uw.^2 uw.^3];
	yw_ = Uw*w;
	% wyj�cia modelu w przedziale -1 1 w celach rysunkowych
	U_ = [ones(length(u_),1) u_  u_.^2 u_.^3];
	Y_ = U_*w;
	
	figure;
	tiledlayout(2,1);
	
	ax1 = nexttile;
	scatter(ax1,u,y,'g');
	hold on;
	plot(ax1,u_,Y_,'b');
	title('Zbi�r ucz�cy');
	
	ax2 = nexttile;
	scatter(ax2,uw,yw,'r');
	hold on;
	plot(ax2,u_,Y_,'b');
	title('Zbi�r weryfikuj�cy');
	
	if (doPrint == 1)
		print('StatStop3','-dpng','-r400');
	end
	
	fprintf("B��dy modelu trzeciego stopnia:\n");
	E = sum((y_-y).^2);
	fprintf("B��d danych ucz�cych: %f\n",E);
	Ew = sum((yw_-yw).^2);
	fprintf("B��d danych weryfikuj�cych: %f\n",Ew);
	
end

M = [M,u.^4];

% model stopnia 4
if model == 4 || model == 0
	w = M\y;
	% wyj�cia modelu dla danych ucz�cych
	U = [ones(length(u),1) u u.^2 u.^3 u.^4];
	y_ = U*w;
	% wyj�cia modelu dla danych weryfikuj�cych
	Uw = [ones(length(uw),1) uw  uw.^2 uw.^3 uw.^4];
	yw_ = Uw*w;
	% wyj�cia modelu w przedziale -1 1 w celach rysunkowych
	U_ = [ones(length(u_),1) u_  u_.^2 u_.^3 u_.^4];
	Y_ = U_*w;
	
	figure;
	tiledlayout(2,1);
	
	ax1 = nexttile;
	scatter(ax1,u,y,'g');
	hold on;
	plot(ax1,u_,Y_,'b');
	title('Zbi�r ucz�cy');
	
	ax2 = nexttile;
	scatter(ax2,uw,yw,'r');
	hold on;
	plot(ax2,u_,Y_,'b');
	title('Zbi�r weryfikuj�cy');
	
	if (doPrint == 1)
		print('StatStop4','-dpng','-r400');
	end
	
	fprintf("B��dy modelu czwartego stopnia:\n");
	E = sum((y_-y).^2);
	fprintf("B��d danych ucz�cych: %f\n",E);
	Ew = sum((yw_-yw).^2);
	fprintf("B��d danych weryfikuj�cych: %f\n",Ew);
	
end

M = [M,u.^5];

% model stopnia 5
if model == 5 || model == 0
	w = M\y;
	% wyj�cia modelu dla danych ucz�cych
	U = [ones(length(u),1) u u.^2 u.^3 u.^4 u.^5];
	y_ = U*w;
	% wyj�cia modelu dla danych weryfikuj�cych
	Uw = [ones(length(uw),1) uw  uw.^2 uw.^3 uw.^4 uw.^5];
	yw_ = Uw*w;
	% wyj�cia modelu w przedziale -1 1 w celach rysunkowych
	U_ = [ones(length(u_),1) u_  u_.^2 u_.^3 u_.^4 u_.^5];
	Y_ = U_*w;
	
	figure;
	tiledlayout(2,1);
	
	ax1 = nexttile;
	scatter(ax1,u,y,'g');
	hold on;
	plot(ax1,u_,Y_,'b');
	title('Zbi�r ucz�cy');
	
	ax2 = nexttile;
	scatter(ax2,uw,yw,'r');
	hold on;
	plot(ax2,u_,Y_,'b');
	title('Zbi�r weryfikuj�cy');
	
	if (doPrint == 1)
		print('StatStop5','-dpng','-r400');
	end
	
	fprintf("B��dy modelu pi�tego stopnia:\n");
	E = sum((y_-y).^2);
	fprintf("B��d danych ucz�cych: %f\n",E);
	Ew = sum((yw_-yw).^2);
	fprintf("B��d danych weryfikuj�cych: %f\n",Ew);
	
end

M = [M,u.^6];

% model stopnia 6
if model == 6 || model == 0
	w = M\y;
	% wyj�cia modelu dla danych ucz�cych
	U = [ones(length(u),1) u u.^2 u.^3 u.^4 u.^5 u.^6];
	y_ = U*w;
	% wyj�cia modelu dla danych weryfikuj�cych
	Uw = [ones(length(uw),1) uw  uw.^2 uw.^3 uw.^4 uw.^5 uw.^6];
	yw_ = Uw*w;
	% wyj�cia modelu w przedziale -1 1 w celach rysunkowych
	U_ = [ones(length(u_),1) u_  u_.^2 u_.^3 u_.^4 u_.^5 u_.^6];
	Y_ = U_*w;
	
	figure;
	tiledlayout(2,1);
	
	ax1 = nexttile;
	scatter(ax1,u,y,'g');
	hold on;
	plot(ax1,u_,Y_,'b');
	title('Zbi�r ucz�cy');
	
	ax2 = nexttile;
	scatter(ax2,uw,yw,'r');
	hold on;
	plot(ax2,u_,Y_,'b');
	title('Zbi�r weryfikuj�cy');
	
	if (doPrint == 1)
		print('StatStop6','-dpng','-r400');
	end
	
	fprintf("B��dy modelu sz�stego stopnia:\n");
	E = sum((y_-y).^2);
	fprintf("B��d danych ucz�cych: %f\n",E);
	Ew = sum((yw_-yw).^2);
	fprintf("B��d danych weryfikuj�cych: %f\n",Ew);
	
end
