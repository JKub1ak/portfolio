function u = ugen(ut)
	u = zeros(1,length(ut));
	for i = 1:length(ut)
		if ut(i) >= 0 && ut(i) < 5
			u(i) = 5;
		elseif ut(i) >= 5 && ut(i) < 10
			u(i) = 10;
		elseif ut(i) >= 10 && ut(i) < 15
			u(i) = 0;
		elseif ut(i) >= 15 && ut(i) <= 30
			u(i) = 15;
		end
	end
end

