%symulacja w SYMULINKu

%symulacja dla ma�ej dok�adno�ci
dokladnosc = '0.2';
set_param('Uklad','Solver','ode45','RelTol',dokladnosc);
outm = sim('Uklad');

%symulacja dla �redniej dok�adno�ci
dokladnosc = '0.05';
set_param('Uklad','Solver','ode45','RelTol',dokladnosc);
outs = sim('Uklad');

%symulacja dla du�ej dok�adno�ci
dokladnosc = '1e-3';
set_param('Uklad','Solver','ode45','RelTol',dokladnosc);
outd = sim('Uklad');

set(0,'defaultLineLineWidth',1);

figure;
plot(outm.x1);
hold on;
plot(outs.x1);
hold on;
plot(outd.x1);
title('x1');
legend('tol=0.2','tol=0.05','tol=0.001');
%print('x1','-dpng','-r400');
hold off;

figure;
plot(outm.x2);
hold on;
plot(outs.x2);
hold on;
plot(outd.x2);
title('x2');
legend('tol=0.2','tol=0.05','tol=0.001');
%print('x2','-dpng','-r400');
hold off;

figure;
plot(outm.y);
hold on;
plot(outs.y);
hold on;
plot(outd.y);
title('y');
legend('tol=0.2','tol=0.05','tol=0.001');
%print('y','-dpng','-r400');
hold off;


%symulacja w MATLABie
%ta duza liczba ponizej jest zeby sygnal wejscowy byl dokladny
ut = linspace(0,30,300000);
u = ugen(ut);
tspan = [0 30];
x0 = [0 0.025];
[t, x] = ode45(@(t,x) odefun(t,x,ut,u),tspan,x0);
y = output(x);

figure;
plot(t,x(:,1));
hold on;
plot(outd.x1);
title('x1');
legend('matlab','symulink');
hold off;
print('porownanie_x1','-dpng','-r400');

figure;
plot(t,x(:,2));
hold on;
plot(outd.x2);
title('x2');
legend('matlab','symulink');
hold off;
print('porownanie_x2','-dpng','-r400');

figure;
plot(t,y);
hold on;
plot(outd.y);
title('y');
legend('matlab','symulink');
hold off;
print('porownanie_y','-dpng','-r400');
