function y = output(x)
	y = sin(2*x(:,1) + 3*x(:,2));
end