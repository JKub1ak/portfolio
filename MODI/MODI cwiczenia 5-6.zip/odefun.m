function dxdt = odefun(t,x,ut,u)
	u = interp1(ut,u,t);
	dxdt = [-10*x(1)-5*x(2)+0.001*u.^3;x(1)];
end