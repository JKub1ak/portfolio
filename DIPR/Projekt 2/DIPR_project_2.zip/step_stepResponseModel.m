function tl_prediction = step_stepResponseModel(p,k)

	global HLv;
	global TLv;
	global TLv_prediction;
	global horizon;
	global step_response;

	% Prosze zwr�ci� uwag�, �e:
	% - stepResponeModel pracuje na zmiannach sterowania a nie na warto�ciach
	% - wsp�czynniki odpowiedzi z indeksem wi�kszym ni� D maja warto�� sD (ostatniego wsp�czynnika)
	% - u�ycie blednego pomiaru tl w liczeniu estymaty nie jest najlepszym
	%   pomys�em - trzeba na te okoliczno�� zaproponowa� inne rozwi�zanie i uzasadni� dlaczego takie rozwi�zanie wybrano

	%tuaj nale�y wpisac poprawny wz�r
	%   tl_prediction = TLv(k-p) + 0.001 * HLv(k-5);
	
	Y0 = TLv(k-p);
	
	% Je�li wyj�cie z chwili k-p odbiega znacznie od przewidywanego wyj�cia
	% dla tej chwili, zak�adany jest b��d i do predykcji u�ywane jest
	% wyj�cie poprzednio przewidziane na t� chwil�.
	if abs(Y0 - TLv_prediction(k-p)) > 2.0
		Y0 = TLv_prediction(k-p);
	end
	
	% Wyliczanie predykowanej zmiany wyj�cia
	DY = 0;
	for j = 1:horizon-p
		if k-p-j-1 > 0
			DU = HLv(k-p-j)-HLv(k-p-j-1);
		else
			DU = 0;
		end
		DY = DY + (step_response(j+p)-step_response(j))*DU;
	end
	for j = 1:p
		DU = HLv(k-j)-HLv(k-j-1);
		DY = DY + step_response(j)*DU;
	end
	
	% Wyliczanie ostatecznej predykcji wyj�cia
	tl_prediction = Y0 + DY;
	
end