%UWAGA:
% * Symulator pracuje z czasem pr�bkowania Tp=1sec - jeden krok to 1 sec.
% * Symulator pami�ta stan i zaczyna symulacj� od warunk�w,
%   kt�re si� ustali�y po ostatnim uruchomieniu.

% init_simulator.m ustawia stan pocz�tkowy i powinien by� wykonany
% na pocz�tku symulacji, chyba �e u�ytkownik z jakiego� powodu chce
% kontynuowa� symulacj� dla ostatnich warunk�w.

% Takim powodem mo�e by� np. pr�ba zabrania odpowiedzi skokowej w punkcie
% pracy (hl, hr, fl, fr, tl, tr), gdzie:
%  hl - grza�ka lewa (0,100)
%  hr - grza�ka prawa (0,100)
%  fl - wentylator lewy (0,100)
%  fr - wentylator prawy (0,100)
%  tl - temperatura lewa C
%  tr - temperatura prawa C 
% Przeprowadzenie takiego eksperymentu wymaga wprowadzenie symulatora w
% zadany punkt pracy. W tym celu nale�y ustawi� sygna�y MV i DV i wykona�
% symulacj� na horyzoncie ok. 1800 krok�w, �eby zmienne procesowe PV (tl i
% tr) ustawi�y si� na warto�ciach punktu pracy. Nast�pnie mo�na wykona� 
% eksperyment w celu np identyfikacji transmitancji zak��cenia.


init_simulator
init_model


simLength = 3000;
global HLv;
global TLv;
global TLv_prediction;

tl_flt = 0;
tr_flt = 0;

%Sterowania kt�re nie b�d� si� zmienia�y podczas testu,
%tutaj ustawiamy warto�ci jakie b�d� obowi�zywa�y
FLv = zeros(1,simLength);
FRv = zeros(1,simLength);
HRv = zeros(1,simLength);
fl=30;
fr=30;
hr=0;

%Sterowanie grza�k� lew� hl bedzie si� zmienia� wg. zadanej trajektori
%tutaj ustawiamy warto�� pocz�tkow�
HLv = zeros(1,simLength);
hl=50;

%CV, nie kontrolujemy tych warto�ci
TLv = zeros(1,simLength);
TRv = zeros(1,simLength);
tl = TLamb;
tr = TRamb;

FAULT = zeros(1,simLength);

for k = 1:1:simLength
   % generacja MV
   if k > 1100
       hl=70;
   end
   if k > 1600
       hl=90;
   end
   if k > 2100
       hl=60;
   end
   if k > 2600
       hl=30;
   end
 
  if k > 1500
    tl_flt = 1;
  end
  if k > 1530
    tl_flt = 0;
  end
   if k > 2300
    tl_flt = 1;
  end
  if k > 2330
    tl_flt = 0;
  end  
   %Do napisania jest funkcja step_stepResponseModel, kt�ra na podstawie:
   % - przesz�ej warto�ci wyj�cia (dana przez global TLv)
   % - przesz�ych warto�ci sterowania (dana przez global HLv)
   % - parametru p, okre�laj�c� z kt�rej chwili u�y� warto�� temperatury 
   % - aktualnej chwili k
   % wyliczy predykowane wyj�cie na chwil� obecn� 
   % Wyliczenia rozpoczynamy w stanie ustalonym w chwili k>1000
   if k>1000
    p = 50;
    tl_prediction = step_stepResponseModel(p,k);
   else
    tl_prediction = tl;
   end
   
   TLv_prediction(k) = tl_prediction;
   [tl, tr] = step_simulator(hl, hr, fl, fr,tl_flt, tr_flt);
   TLv(k) = tl;
   TRv(k) = tr;
   FLv(k) = fl;
   FRv(k) = fr;
   HLv(k) = hl;
   HRv(k) = hr;
   
   % detekcja uszkodzenia
   FAULT(k)=0;
   if abs(TLv(k) - TLv_prediction(k)) > 2.0
     FAULT(k) = 10;
   end
%    k
end


figure;
    subplot(2,1,1);
    plot(FLv,'r');
    hold on;
    grid on;
    plot(FRv, 'b--');
    xlabel('k');
    ylabel('U(k)');
    title('Sterowanie wentylator�w');
    legend('FLU', 'FRU');
    
    subplot(2,1,2);
    plot(HLv,'r');
    hold on;
    grid on;
    plot(HRv, 'b--');
    xlabel('k');
    ylabel('U(k)');
    title('Sterowanie grza�ek');
    legend('HL', 'HR');
    
    figure;
    subplot(2,1,1);
    plot(TLv,'r');
    hold on;
    grid on;
    plot(TLv_prediction, 'b--');
    hold on;
    grid on;
    plot(FAULT, 'g');
    xlabel('k');
    ylabel('TL(k)');
    title('Temperatura lewa TL');
    legend('TL', 'TL prediction', 'fault');
    
    subplot(2,1,2);
    plot(TRv,'r');
    hold on;
    grid on;
    xlabel('k');
    ylabel('TR(k)');
    title('Temperatura prawa TR');

