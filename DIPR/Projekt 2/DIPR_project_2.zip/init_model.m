clear STEP_RESPONSE step_response horizon;
global step_response;

load("STEP_RESPONSE_65to66.mat");
step_response = (STEP_RESPONSE-STEP_RESPONSE(1));

global horizon; horizon = 1000;
% Przyjęto najdłuższy horyzont jaki się dało bez problemów z indeksami wejścia,
% nie żeby był jakoś bardzo potrzebny aż tak długi, 700 działało bardzo podobnie.
% Ale zgodność też jest oceniana ¯\_(ツ)_/¯.