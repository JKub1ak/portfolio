
Projekt na przedmiot PROZ 05.2020
Janusz Kubiak 300424


Wymagania do uruchomienia:
  - Java 8


Instalacja:
  - Wypakować folder Tetris gdzieś.


Uruchamianie:
  - W folderze Tetris uruchomić plik 'Tetris.bat'.
	Zignorować ewentualne powiadomienia o niebezpieczeństwie.


Dodatkowe informacje:
  - Pliki Javadoc wygenerowane przez gradle'a znajdują się w folderze Javadocs

  - W folderze sources znajdują się pliki źródłowe programu, pliki środowiska InteliJ, oraz gradle.
	Program można skompilować uruchamiając 'gradlew build'.
	Spowoduje to skompilowanie się klas.
	Nie spowoduje to że program będzie można uruchomić,
	ponieważ gradle nie doda bibliotek zewnętrznych,
	oraz struktura plików będzie niewłaściwa.
	Do tego użyte zostało środowisko InteliJ.
	Żeby przetestować skompilowane klas należałoby nimi nadpisać te w folderze 'Tetris'.

  - Folder Tetris został stworzony z archiwum jar zapakowanego przez wyżej wspomniane środowisko,
	po usunięciu z niego zbędnych plików.
	Samo archiwum jar nie dałoby się uruchomić,
	ponieważ nie wiem, jak załadować zasoby z wewnątrz jara,
	w szczególności systemowe biblioteki dll znajdujące się w resources\_natives.