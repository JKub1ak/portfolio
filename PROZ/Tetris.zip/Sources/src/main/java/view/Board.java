package view;

import model.ModelInterface.ObservableBoard;

import java.util.Observable;

/** Class used for displaying the board with fallen pieces. */
class Board extends Pieces {

	/**@see Pieces*/
	Board(String resources, int sizeY, int sizeX) {
		super(resources, sizeY,sizeX);
	}

	@Override
	public void update(Observable o, Object arg) {
		if (!((String)arg).equals(ObservableBoard.boardStateChangeNotification))
			return;
		setBlocks(((ObservableBoard)o).getBoard());
	}

}
