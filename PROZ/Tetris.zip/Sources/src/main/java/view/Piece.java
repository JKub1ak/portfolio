package view;

import model.ModelInterface.ObservablePiece;

import java.util.Observable;

/** A class used to display a piece */
class Piece extends Pieces {

	private int x, y = 0;
	int getX() {return x;}
	int getY() {return y;}
	void setX(int x) {this.x = x;}
	void setY(int y) {this.y = y;}
	/** If true this piece is considered a piece falling on the board. Else it's a display piece. */
	boolean playing = false;

	/**
	 * @see Pieces
	 * @param playing Sets if this piece is a playing or a display piece.
	 */
	Piece(String resources, int sizeY, int sizeX, boolean playing) {
		super(resources,sizeY,sizeX);
		this.playing = playing;
	}


	@Override
	public void update(Observable o, Object arg) {
		if (((String)arg).equals(ObservablePiece.piecePositionChangeNotification) && playing) {
			x = ((ObservablePiece)o).getX();
			y = ((ObservablePiece)o).getY();
		} else if (((String)arg).equals(ObservablePiece.pieceStateChangeNotification))
			setBlocks(((ObservablePiece)o).getPieceBoard());
	}

	@Override
	public void draw() {
		for (int i = 0; i < blocks.length; i++)
			for (int j = 0; j < blocks[i].length; j++)
				blocks[i][j].draw(
						offsetX + blocks[i][j].getWidth()*x + blocks[i][j].getWidth()*j,
						offsetY + blocks[i][j].getHeight()*y + blocks[i][j].getHeight()*i
				);
	}
}
