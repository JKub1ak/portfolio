package view;

import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheet;

import java.util.Observable;
import java.util.Observer;

/** Template class for any classes that have a board of tetris blocks - so Board and Piece */
abstract class Pieces implements Observer {

	/** Display offsets. */
	protected int offsetY, offsetX = 0;

	/** Sprite sheet with the blocks. */
	protected SpriteSheet sheet;
	/** The displaying image. */
	protected Image[][] blocks;

	/**
	 * Creates a Pieces object.
	 * @param resources A path to resources, specifically block sprite sheet.
	 * @param sizeY     Height of the board.
	 * @param sizeX     Width of the board.
	 */
	Pieces(String resources, int sizeY, int sizeX) {
		blocks = new Image[sizeY][sizeX];
		try {
			Image tileSet = new Image(resources+"\\block_texture.png");
			sheet = new SpriteSheet(tileSet,tileSet.getHeight(),tileSet.getHeight());
		} catch (SlickException e) {
			e.printStackTrace();
		}
		int[][] bl = new int[sizeY][sizeX];
		for (int i = 0; i < sizeY; i++) {
			for (int j = 0; j < sizeX; j++) {
				bl[i][j] = 0;
			}
		}
		setBlocks(bl);
	}

	/**
	 * Sets sprite sheet. Currently unused.
	 * @param sheet New sprite sheet.
	 */
	void setSpriteSheet(SpriteSheet sheet) {this.sheet = sheet;}

	/**@see Observer*/
	public abstract void update(Observable o, Object arg);

	/** Draws the board onto the screen. */
	public void draw() {
		for (int i = 0; i < blocks.length; i++)
			for (int j = 0; j < blocks[i].length; j++)
				blocks[i][j].draw(
						offsetX +blocks[i][j].getWidth()*j,
						offsetY +blocks[i][j].getHeight()*i
				);
	}

	/**
	 * Sets the images of the blocks to corresponding with the provided.
	 * @param board Board of numbers of sprite sheet sprites to be set.
	 */
	void setBlocks(int[][] board) {
		for (int i = 0; i < board.length; i++)
			for (int j = 0; j < board[i].length; j++)
				blocks[i][j] = sheet.getSprite(board[i][j],0);
	}
}
