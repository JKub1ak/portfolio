package view;

import model.ModelInterface.ObservableScore;
import org.newdawn.slick.TrueTypeFont;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.Observable;
import java.util.Observer;

/** A class responsible for displaying any user interface related things, such as score, paused text and so on. */
public class UI implements Observer{

	private TrueTypeFont font;
	private TrueTypeFont bigFont;
	TextBlock score;
	TextBlock level;
	TextBlock lines;
	TextBlock gameOver;
	TextBlock paused;
	TextBlockArray keys;

	/**
	 * Creates a UI object.
	 * @param resourcesPath Path to resources, specifically to the font.
	 */
	public UI(String resourcesPath) {
		try {
			GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
			File f = new File(resourcesPath+"\\Pixel Emulator.otf");
			if (!f.exists())
				f = new File("Pixel Emulator.otf");
			ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File(f.getAbsolutePath())));
		} catch (FontFormatException | IOException e) {
			e.printStackTrace();
		}
		font = new TrueTypeFont(new Font("Pixel Emulator",Font.PLAIN,20 ),false);
		bigFont = new TrueTypeFont(new Font("Pixel Emulator",Font.PLAIN,40 ),false);
		score = new TextBlock("000000", 100, 30);
		lines = new TextBlock("000", 200, 30);
		level = new TextBlock("00", 300, 30);
		gameOver = new TextBlock("Game Over",400,30);
		gameOver.setVisible(false);
		paused = new TextBlock("Paused",500,30);
		paused.setVisible(false);
		keys = new TextBlockArray(new String[]{"Esc"," -pause"," -restart","","Arrow keys"," -movement","","Z,X"," -rotate"});

	}

	/** Draws all the texts. */
	public void draw() {
		score.draw(font);
		level.draw(font);
		lines.draw(font);
		keys.draw(font);
		paused.draw(bigFont);
		gameOver.draw(bigFont);
	}

	@Override
	public void update(Observable o, Object arg) {
		if (((String)arg).equals(ObservableScore.scoreChangeNotification)) {
			int[] ret = ((ObservableScore)o).getData();

			String str = this.score.defaultText;
			int length = str.length();
			str = str + ret[0];
			this.score.text = str.substring(str.length()-length);

			str = this.lines.defaultText;
			length = str.length();
			str = str + ret[1];
			this.lines.text = str.substring(str.length()-length);

			str = this.level.defaultText;
			length = str.length();
			str = str + ret[2];
			this.level.text = str.substring(str.length()-length);
		} else if (((String)arg).equals(ObservableScore.gameOverNotification)) {
			gameOver.setVisible(true);
		} else if (((String)arg).equals(ObservableScore.gamePausedNotification)) {
			paused.setVisible(true);
		} else if (((String)arg).equals(ObservableScore.gameResumedNotification)) {
			paused.setVisible(false);
		}
	}

	/** An internal class used to display a number of texts under each other. */
	static class TextBlockArray {
		private TextBlock[] blocks;
		TextBlockArray(String[] texts) {
			blocks = new TextBlock[texts.length];
			for (int i = 0; i < blocks.length; i++) {
				blocks[i] = new TextBlock();
				blocks[i].text = texts[i];
			}
		}
		void setPosition(int y, int x) {
			for (int i = 0; i < blocks.length; i++) {
				blocks[i].setPosition(y+24*i,x);
			}
		}
		void draw(org.newdawn.slick.Font font) {
			for (int i = 0; i < blocks.length; i++) {
				blocks[i].draw(font);
			}
		}
	}

	/** An internal class used to store any texts and their location */
	static class TextBlock {
		private int y;
		private int x;
		private String defaultText;
		private String text;
		private boolean visible = true;

		TextBlock() {this("",0,0);}
		TextBlock(String text) {
			this(text,0,0);
		}
		TextBlock(String text, int y, int x) {
			this.defaultText = text;
			this.text = text;
			this.y = y;
			this.x = x;
		}

		void setPosition(int y, int x) {
			this.y = y;
			this.x = x;
		}

		void setVisible(boolean visible) {this.visible = visible;}

		protected void draw(org.newdawn.slick.Font font) {
			if (visible)
				font.drawString(x, y, text);
		}
	}
}
