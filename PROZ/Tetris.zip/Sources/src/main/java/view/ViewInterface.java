package view;

import java.util.Observer;

public interface ViewInterface {

	/**
	 * Initializes the view.
	 * @param boardSizeY Height of the board.
	 * @param boardSizeX Width of the board.
	 * @param pieceSize  Size of the piece board.
	 * @param resourcesPath Path to all resources. Should contain all assets used by the view.
	 */
	void init(int boardSizeY, int boardSizeX, int pieceSize, String resourcesPath);

	/** Renders the view. */
	void render();

	/**
	 * An observer for a ModelInterface.ObservablePiece interface of the playing piece
	 * @return An observer for the playing piece
	 */
	Observer getPlayingPieceObserver();

	/**
	 * An observer for a ModelInterface.ObservablePiece interface of the next piece
	 * @return An observer for the next piece
	 */
	Observer getNextPieceObserver();

	/**
	 * An observer for a ModelInterface.ObservableBoard interface of the board
	 * @return An observer for the board
	 */
	Observer getBoardObserver();

	/**
	 * An observer for a ModelInterface.ObservableScore interface of the score
	 * @return An observer for the score
	 */
	Observer getScoreObserver();
}
