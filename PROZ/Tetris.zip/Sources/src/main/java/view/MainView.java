package view;

import org.newdawn.slick.*;

import java.io.File;
import java.util.Observer;

/** The main view class holding things together. */
public class MainView implements ViewInterface {

	/** Path to resources. */
	private String resourcesPath;

	/* offsets */
	private final int nextPieceOffsetY = 40;
	private final int nextPieceOffsetX = 8;

	private final int boardOffsetY = 8;
	private final int boardOffsetX = 176;

	private final int scoreOffsetY = 232;
	private final int scoreOffsetX = 40;
	private final int linesOffsetY = 296;
	private final int linesOffsetX = 65;
	private final int levelOffsetY = 360;
	private final int levelOffsetX = 75;
	private final int gameOverOffsetY = 100;
	private final int gameOverOffsetX = 200;
	private final int keysOffsetY = 400;
	private final int keysOffsetX = 10;
	private final int pauseOffsetY = 100;
	private final int pauseOffsetX = 245;

	private Image background;
	private Image border;
	private Board board;
	private Piece playingPiece;
	private Piece nextPiece;
	private UI ui;
	private boolean initiated = false;

	/**
	 * Initializes the view.
	 * @param boardSizeY Height of the board.
	 * @param boardSizeX Width of the board.
	 * @param pieceSize  Size of the piece board.
	 * @param resourcesPath Path to all resources. Should contain all assets used by the view.
	 */
	public void init(int boardSizeY, int boardSizeX, int pieceSize, String resourcesPath) {
		this.resourcesPath = resourcesPath;
		try {
			File f = new File(resourcesPath+"\\Background.png");
			if (!f.exists())
				f = new File("Background.png");
			background = new Image(f.getAbsolutePath());
			f = new File(resourcesPath+"\\Border.png");
			if (!f.exists())
				f = new File("Border.png");
			border = new Image(f.getAbsolutePath());
		} catch (SlickException e) {
			e.printStackTrace();
		}
		this.board = new Board(resourcesPath,boardSizeY,boardSizeX);
		this.board.offsetY = boardOffsetY;
		this.board.offsetX = boardOffsetX;

		this.ui = new UI(resourcesPath);
		this.ui.score.setPosition(scoreOffsetY,scoreOffsetX);
		this.ui.lines.setPosition(linesOffsetY,linesOffsetX);
		this.ui.level.setPosition(levelOffsetY,levelOffsetX);
		this.ui.gameOver.setPosition(gameOverOffsetY,gameOverOffsetX);
		this.ui.keys.setPosition(keysOffsetY,keysOffsetX);
		this.ui.paused.setPosition(pauseOffsetY,pauseOffsetX);

		this.nextPiece = new Piece(resourcesPath,pieceSize,pieceSize,false);
		this.nextPiece.offsetY = nextPieceOffsetY;
		this.nextPiece.offsetX = nextPieceOffsetX;

		this.playingPiece = new Piece(resourcesPath,pieceSize,pieceSize,true);
		this.playingPiece.offsetY = boardOffsetY;
		this.playingPiece.offsetX = boardOffsetX;

		initiated = true;
	}

	/** Renders the view. */
	public void render() {
		if (!initiated)
			return;
		background.draw();
		board.draw();
		nextPiece.draw();
		playingPiece.draw();
		border.draw();
		ui.draw();
	}

	/**
	 * Returns an observer of the playing piece
	 * @return an observer of the playing piece
	 */
	public Observer getPlayingPieceObserver() {
		return playingPiece;
	}
	/**
	 * Returns an observer of the display piece
	 * @return an observer of the display piece
	 */
	public Observer getNextPieceObserver() {
		return nextPiece;
	}
	/**
	 * Returns an observer of the board
	 * @return an observer of the board
	 */
	public Observer getBoardObserver() {
		return board;
	}
	/**
	 * Returns an observer of the score
	 * @return an observer of the score
	 */
	public Observer getScoreObserver() {
		return ui;
	}
}
