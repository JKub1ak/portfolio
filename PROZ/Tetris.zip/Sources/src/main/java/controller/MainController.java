package controller;


import model.ModelInterface;
import view.ViewInterface;
import org.newdawn.slick.*;

import java.io.File;

/** The main class for controlling the model and view. Responsible for updating them and getting keyboard inputs. */
public class MainController extends BasicGame implements ControllerInterface {

	private ModelInterface model;
	private ViewInterface view;
	private boolean paused = false;
	private boolean gameOver = false;
	private boolean reinit = false;
	/** Path to resources such as native libraries and graphics assets. */
	private String resourcesPath;

	/**
	 * Creates a controller.
	 * @param title     Required by BasicGame. Sets the window title.
	 * @param resources File with path to the resources.
	 */
	public MainController(String title, File resources) {
		super(title);
		resourcesPath = resources.getAbsolutePath();
	}

	/**
	 * Initiates the game
	 * @param gameContainer Slick2d's game container
	 */
	@Override
	public void init(GameContainer gameContainer) {
		model.init();
		view.init(ModelInterface.boardHeight,ModelInterface.boardWidth, ModelInterface.pieceSize, resourcesPath);
		model.addObservers( view.getPlayingPieceObserver(),
							view.getNextPieceObserver(),
							view.getBoardObserver(),
							view.getScoreObserver());
	}

	/**
	 * Updates the game
	 * @param gameContainer Slick2d's game container
	 * @param delta         Time elapsed since last update in milliseconds
	 */
	@Override
	public void update(GameContainer gameContainer, int delta) {
		if (reinit) {
			reinit = false;
			init(gameContainer);
			return;
		}
		if (!paused)
			if (model.update(delta))
				gameOver = true;
	}

	/**
	 * Renders the game
	 * @param gameContainer Slick2d's game container
	 * @param graphics      Slick2d's graphics object
	 */
	@Override
	public void render(GameContainer gameContainer, Graphics graphics) throws SlickException {
		view.render();
	}

	/**
	 * Function called when a key press event is detected
	 * @param key Slick2d's key representation
	 * @param c   Char key representation
	 */
	@Override
	public void keyPressed(int key, char c) {
		if(key == Input.KEY_ESCAPE) {
			if (gameOver) {
				gameOver = false;
				reinit = true;
			} else {
				paused = !paused;
				model.setPaused(paused);
			}
		}
		if (paused)
			return;
		switch (key) {
			case Input.KEY_Z:
				model.zPressed();
				break;
			case Input.KEY_X:
				model.xPressed();
				break;
			case Input.KEY_LEFT:
				model.setLeftPressed();
				break;
			case Input.KEY_RIGHT:
				model.setRightPressed();
				break;
			case Input.KEY_DOWN:
				model.setDownPressed();
				break;
		}
	}

	/**
	 * Function called when a key release event is detected
	 * @param key Slick2d's key representation
	 * @param c   Char key representation
	 */
	@Override
	public void keyReleased(int key, char c) {
		switch (key) {
			case Input.KEY_LEFT:
				model.setLeftReleased();
				break;
			case Input.KEY_RIGHT:
				model.setRightReleased();
				break;
			case Input.KEY_DOWN:
				model.setDownReleased();
				break;
		}
	}

	@Override
	public void addModel(ModelInterface model) {
		this.model = model;
	}

	@Override
	public void addView(ViewInterface view) {
		this.view = view;
	}
}
