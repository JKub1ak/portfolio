package controller;

import model.ModelInterface;
import view.ViewInterface;

public interface ControllerInterface {

	/**
	 * Adds a model to the controller
	 * @param model Model to be added
	 */
	void addModel(ModelInterface model);

	/**
	 * Adds a view to the controller
	 * @param view View to be added
	 */
	void addView(ViewInterface view);
}
