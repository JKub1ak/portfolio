package model;

import java.util.Observer;

public interface ModelInterface {

	/** Width of the playing area in squares */
	int boardWidth = 10;
	/** Height of the playing area in squares */
	int boardHeight = 20;
	/** Size of each piece board (pieceSize x pieceSize) */
	int pieceSize = 5;

	/** Initialize the model. Creates new board, pieces, and score. Sets gameOver false. */
	void init();

	/**
	 * Adds observers to the model.
	 * @param playingPieceObs Observer of the playing piece on the board.
	 * @param nextPieceObs Observer of the next piece to be played.
	 * @param boardObs Observer of the state of the board.
	 * @param scoreObs Observer of the score and such.
	 */
	void addObservers(Observer playingPieceObs, Observer nextPieceObs , Observer boardObs, Observer scoreObs);

	/**
	 * Method for periodically updating the model. This method is called by a controller.
	 * @param delta Time elapsed since the last update in milliseconds.
	 * @return This method returns true if the game ended.
	 */
	boolean update(int delta);


	/** Called when down is released */
	void setDownReleased();

	/** Called when left is released */
	void setLeftReleased();

	/** Called when right is released */
	void setRightReleased();

	/** Called when down is pressed */
	void setDownPressed();

	/** Called when left is pressed */
	void setLeftPressed();

	/** Called when right is pressed */
	void setRightPressed();

	/** Called when z is pressed */
	void zPressed();

	/** Called when x is pressed */
	void xPressed();

	/**
	 * Pauses or un-pauses the model
	 * @param paused Pause or un-pause.
	 */
	void setPaused(boolean paused);

	/*------------------------------------------------------------------------------------------------------*/
	/*------------------------------------- Observables sub-interfaces -------------------------------------*/
	/*------------------------------------------------------------------------------------------------------*/

	/** Requirements for the model piece that allow the view to function. */
	interface ObservablePiece {
		/** Notification for when piece's position has changed. */
		String piecePositionChangeNotification = "PiecePositionChange";
		/** Notification for when piece's board state has changed. */
		String pieceStateChangeNotification = "PieceStateChange";

		int getX();
		int getY();

		/**
		 * Get the piece board.
		 * @return Returns the piece board.
		 */
		public int[][] getPieceBoard();
	}

	/*------------------------------------------------------------------------------------------------------*/

	/** Requirements for the model board that allow the view to function. */
	interface ObservableBoard {
		/** Notification for when the board state has been changed */
		String boardStateChangeNotification = "BoardStateChanged";

		/**
		 * Get a board.
		 * @return Returns a board.
		 */
		int[][] getBoard();
	}

	/*------------------------------------------------------------------------------------------------------*/

	/** Requirements for the model score that allow the view to function. */
	interface ObservableScore {
		/** Notification for when the score has been changed. */
		String scoreChangeNotification = "ScoreChange";
		/** Notification for when the game is over. */
		String gameOverNotification = "GameOver";
		/** Notification for when the game has been paused. */
		String gamePausedNotification = "GamePaused";
		/** Notification for when the game has been resumed. */
		String gameResumedNotification = "GameResumed";
		/**
		 * Used by observer after being notified of score changes.
		 * @return {score,lines,level}
		 */
		int[] getData();
	}


}
