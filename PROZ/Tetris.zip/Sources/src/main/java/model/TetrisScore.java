package model;

import java.util.Observable;
import java.util.Observer;

/** A class holding score and such. Also responsible for updating the game's speed. Notifies the entire UI observer. */
public class TetrisScore extends Observable implements ModelInterface.ObservableScore {

	private int score = 0;
	private int lines = 0;
	private int level = 0;

	/** Base speed of the game (ms)*/
	private final int baseSpeed = 1000;
	/** Current speed of the game (ms)*/
	private int speed = baseSpeed;
	/** How much the speed changes per level (ms)*/
	private int speedChangePerLevel = 40;
	/** At what level speed gets saturated */
	private int maxLevelChange = 15;

	/**
	 * Updates the score and game speed.
	 * @param linesCleared Lines cleared since last update
	 * @return Returns the new falling time based on the level
	 */
	int update(int linesCleared) {
		switch (linesCleared) {
			case 0:
				return speed;
			case 1:
				score += 100;
				break;
			case 2:
				score += 300;
				break;
			case 3:
				score += 500;
				break;
			case 4:
				score += 800;
				break;
			default:
				return -1;
		}
		lines += linesCleared;
		if (lines/10 > level) {
			++level;
			if (level < maxLevelChange) {
				speed -= speedChangePerLevel;
			}
		}
		setChanged();
		notifyObservers(scoreChangeNotification);
		return speed;
	}

	@Override
	public int[] getData() {
		return new int[] {score, lines, level};
	}

	/**
	 * Additionally to adding an observer, notifies it so the observer gets updated immediately.
	 * @param o Observer to be added.
	 */
	@Override
	public synchronized void addObserver(Observer o) {
		super.addObserver(o);
		setChanged();
		notifyObservers(scoreChangeNotification);
	}

	/** Called when the game is over. Notifies observers. */
	public void gameOver() {
		setChanged();
		notifyObservers(gameOverNotification);
	}

	/**
	 * Notifies observers.
	 * @param paused Paused or un-paused.
	 */
	public void setPaused(boolean paused) {
		setChanged();
		if (paused)
			notifyObservers(gamePausedNotification);
		else
			notifyObservers(gameResumedNotification);
	}
}
