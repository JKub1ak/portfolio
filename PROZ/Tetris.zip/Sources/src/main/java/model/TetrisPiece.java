package model;

import java.util.Observable;
import java.util.Observer;

/**
 * A class of a tetris piece.
 * Note: width or x grow right,
 *       height or y grow DOWN
 *       therefore row y = 0 is the top most row of the board
 */
public class TetrisPiece extends Observable implements ModelInterface.ObservablePiece {

	/** Number of possible different pieces */
	public static final int pieceCount = 7;
	/** Number of possible different rotations of each piece */
	public static final int rotCount = 4;
	/** Size of each piece board (pieceSize x pieceSize) */
	public static final int pieceSize = ModelInterface.pieceSize;

	/** Type of this piece. 0 - I; 1 - S; 2 - Z; 3 - L; 4 - inv L; 5 - square; 6 - T; */
	private int pieceType = -1;
	/** This pieces rotation, where 0 is default and ++pieceRotation is clockwise rotation of the piece */
	private int pieceRotation = -1;
	private boolean initialised = false;
	/** A value used for quickly moving a piece when a direction key is held down */
	protected int moveTimeout = 0;

	/** Board of this piece */
	private int[][] pieceBoard;
	/**
	 * Clones the pieceBoard and returns the copy
	 * @return Copy of the pieceBoard
	 */
	public int[][] getPieceBoard() {
		return pieceBoard.clone();
	}
	/**
	 * Returns a specified field on the piece board
	 * @param y Row (from top)
	 * @param x Column (from left)
	 * @return Returns number in position pointed to by x and y
	 */
	public int getField(int y, int x) {
		return pieceBoard[y][x];
	}

	/** Coordinates of top left point of the pieceBoard on the TetrisBoard */
	private int x, y = 0;
	public int getX() {return x;}
	public int getY() {return y;}
	void setX(int x) {this.x = x;}
	void setY(int y) {this.y = y;}

	TetrisPiece () {}
	/**
	 * Creates and initializes a piece object with a specific piece type and rotation.
	 * @param piece    Piece type of this piece.
	 * @param rotation Piece rotation of this piece.
	 */
	TetrisPiece (int piece, int rotation) {
		if (piece<pieceCount && rotation<rotCount)
			initialize(piece,rotation);
	}

	/**
	 * Creates and initializes the piece object using a PieceRandomizer.
	 * @param randomizer PieceRandomizer object to be used for generating this piece's type and rotation
	 */
	TetrisPiece (PieceRandomizer randomizer) {
		int[] randoms = randomizer.getRandom(pieceCount,rotCount);
		initialize(randoms[0],randoms[1]);
	}

	/**
	 * Initializes the piece with the specified piece type and rotation.
	 * Notifies any observers this object may have.
	 * @param piece    Piece type to be set.
	 * @param rotation Piece rotation to be set.
	 */
	private void initialize(int piece, int rotation) {
		this.pieceType = piece;
		this.pieceRotation = rotation;
		int[] temp = getInitPos(piece,rotation);
		this.y = temp[0];
		this.x = temp[1];
		setChanged();
		notifyObservers(piecePositionChangeNotification);
		updateBoardAfterPieceChange();
		this.initialised = true;
	}

	/**
	 * Initializes the piece using a PieceRandomiser object.
	 * @param randomizer PieceRandomizer object to be used for generating type and rotation
	 */
	void initialize(PieceRandomizer randomizer) {
		int[] randoms = randomizer.getRandom(pieceCount,rotCount);
		initialize(randoms[0],randoms[1]);
	}

	/**
	 * Initializes the piece with another pieces type and rotation. Used for transferring the nextPiece onto the board.
	 * @param other The piece to be used for initialization.
	 */
	void initialize(TetrisPiece other) {
		initialize(other.getPieceType(),other.getPieceRotation());
	}

	/** Function moves the piece down 1 */
	void fall() {
		if (!initialised)
			return;
		y+=1;
		setChanged();
		notifyObservers(piecePositionChangeNotification);
	}

	/**
	 * Function moves the piece by 1 either left or right
	 * @param ifRight True - move piece to the right, False - to the left
	 */
	void moveSide(boolean ifRight) {
		if (!initialised)
			return;
		if(ifRight)
			x+=1;
		else
			x-=1;
		setChanged();
		notifyObservers(piecePositionChangeNotification);
	}

	/**
	 * Rotate the piece and update it's pieceRotation. Notifies observers.
	 * @param clockwise If true the piece will be rotated clockwise, else counterclockwise
	 */
	void rotate(boolean clockwise) {rotate(clockwise,true);}

	/**
	 * Rotate the piece and update it's pieceRotation
	 * @param clockwise If true the piece will be rotated clockwise, else counterclockwise
	 * @param notify Weather or not observers should be notified
	 */
	void rotate(boolean clockwise, boolean notify) {
		if (pieceBoard == null)
			return;
		this.pieceBoard = getRotatedBoard(clockwise);
		if (clockwise) {
			pieceRotation = (pieceRotation + 1) % rotCount;
		} else {
			pieceRotation = (pieceRotation+3) % rotCount;
		}
		if (notify) {
			setChanged();
			notifyObservers(pieceStateChangeNotification);
		}
	}

	/**
	 * Method used to get a rotated board of the piece without changing the pieceBoard.
	 * Used to check if rotation is possible.
	 * @param clockwise If the piece should be rotated clockwise or counterclockwise.
	 * @return Returns a piece board rotated in the chosen direction.
	 */
	int[][] getRotatedBoard(boolean clockwise) {
		int[][] ret = new int[pieceSize][pieceSize];
		if (clockwise) {
			for (int i = 0; i < pieceSize; ++i)
				for (int j = 0; j < pieceSize; ++j)
					ret[i][j] = pieceBoard[(pieceSize-1)-j][i];
		} else
			for (int i = 0; i < pieceSize; ++i)
				for (int j = 0; j < pieceSize; ++j)
					ret[i][j] = pieceBoard[j][(pieceSize-1)-i];
		return ret;
	}

	/**
	 * Sets the piece board to the board provided. Notifies observers.
	 * @param board New board.
	 */
	void setBoard(int[][] board) {
		this.pieceBoard = board;
		setChanged();
		notifyObservers(pieceStateChangeNotification);
	}

	/**
	 * Sets the piece board to the board provided. Notifies observers.
	 * Used for the rotating of the piece.
	 * @param board          New board.
	 * @param rotationChange Change of the rotation. Can be -1 or 1.
	 */
	void setBoard(int[][] board, int rotationChange) {
		pieceRotation = (pieceRotation+rotationChange+4)%4;
		setBoard(board);
	}
	public int getPieceType() {return pieceType;}
	public int getPieceRotation() {return pieceRotation;}

	/**
	 * Updates the piece object to the current type and rotation.
	 */
	private void updateBoardAfterPieceChange() {
		this.pieceBoard = TetrisPiece.getPiece(this.pieceType);
		int rot = this.pieceRotation;
		for (int i = 0; i < rot; ++i)
			rotate(true,false);
		this.pieceRotation = rot;
		setChanged();
		notifyObservers(pieceStateChangeNotification);
	}

	boolean setPieceType(int piece) {
		if (piece < pieceCount) {
			this.pieceType = piece;
			updateBoardAfterPieceChange();
		} else {
			this.pieceType = -1;
			this.initialised = false;
			return false;
		}
		return true;
	}

	/**
	 * Sets the piece rotation and rotates the board accordingly.
	 * @param rotation New rotation.
	 * @return Returns false if rotation is out of bounds.
	 */
	boolean setPieceRotation(int rotation) {
		if (rotation >= 0 && rotation < rotCount) {
			if (rotation != this.pieceRotation) {
				for (int i = this.pieceRotation; i <= rotation; i=(++i)%rotCount) {
					rotate(true,false);
				}
				this.pieceRotation = rotation;
				setChanged();
				notifyObservers(pieceStateChangeNotification);
			}
		} else {
			this.pieceRotation = -1;
			this.initialised = false;
			return false;
		}
		return true;
	}

	/**
	 * Additionally to adding an observer, notifies it so the observer gets updated immediately.
	 * @param o Observer to be added.
	 */
	@Override
	public synchronized void addObserver(Observer o) {
		super.addObserver(o);
		setChanged();
		notifyObservers(piecePositionChangeNotification);
		setChanged();
		notifyObservers(pieceStateChangeNotification);
	}

	/** Array of all piece type boards pieceArray[piece][y][x], where y grows top-down and x left-right
	 *0 - I; 1 - S; 2 - Z; 3 - L; 4 - inv L; 5 - square; 6 - T */
	private static final int[/*piece*/][/*y*/][/*x*/] pieceArray = {
		{ //I - 0
			{0, 0, 1, 0, 0},
			{0, 0, 1, 0, 0},
			{0, 0, 1, 0, 0},
			{0, 0, 1, 0, 0},
			{0, 0, 0, 0, 0}
		},{ //S - 1
			{0, 0, 0, 0, 0},
			{0, 0, 2, 2, 0},
			{0, 2, 2, 0, 0},
			{0, 0, 0, 0, 0},
			{0, 0, 0, 0, 0}
		},{ //Z - 2
			{0, 0, 0, 0, 0},
			{0, 3, 3, 0, 0},
			{0, 0, 3, 3, 0},
			{0, 0, 0, 0, 0},
			{0, 0, 0, 0, 0}
		},{ //L - 3
			{0, 0, 0, 0, 0},
			{0, 0, 4, 0, 0},
			{0, 0, 4, 0, 0},
			{0, 0, 4, 4, 0},
			{0, 0, 0, 0, 0}
		},{ //iL - 4
			{0, 0, 0, 0, 0},
			{0, 0, 5, 0, 0},
			{0, 0, 5, 0, 0},
			{0, 5, 5, 0, 0},
			{0, 0, 0, 0, 0}
		},{ //square - 5
			{0, 0, 0, 0, 0},
			{0, 6, 6, 0, 0},
			{0, 6, 6, 0, 0},
			{0, 0, 0, 0, 0},
			{0, 0, 0, 0, 0}
		},{ //T - 6
			{0, 0, 0, 0, 0},
			{0, 0, 7, 0, 0},
			{0, 7, 7, 7, 0},
			{0, 0, 0, 0, 0},
			{0, 0, 0, 0, 0}
		}
	};

	/**
	 * Returns a piece board from pieceArray
	 * @param p Piece number to be returned
	 * @return pieceBoard of type p piece
	 * Note: does a manual array copy
	 *       for some reason .clone() was acting weirdly and putting 0 in the middle of the piece referred to with p = 0
	 * 		 dunno why
	 */
	protected static int[][] getPiece(int p) {
		if (!(p >= 0 && p <= TetrisPiece.pieceCount))
			return new int[][]{{-1}};
		return pieceArray[p].clone();
	}

	/** Starting positions on the board for each pieceType and pieceRotation
	 *  initialPos[piece][rot][y,x]
	 */
	private static final int[/*piece*/][/*rot*/][/*y,x*/] initialPos =
		{
			{// I
				{-4,2},
				{-3,2},
				{-5,2},
				{-3,3}
			},{// S
				{-3,2},
				{-4,2},
				{-4,3},
				{-4,3}
			},{// Z
				{-3,2},
				{-4,2},
				{-4,2},
				{-4,3}
			},{// L
				{-4,2},
				{-4,3},
				{-4,3},
				{-3,2}
			},{// iL
				{-4,3},
				{-3,3},
				{-4,2},
				{-4,2}
			},{// square
				{-3,3},
				{-3,2},
				{-4,2},
				{-4,3}
			}, {// T
				{-3,2},
				{-4,2},
				{-4,2},
				{-4,3}
			}
		};

	/**
	 * Function for getting a starting position for a piece with given type and rotation
	 * @param piece Piece type
	 * @param rot Piece rotation
	 * @return {y,x} Starting position offset
	 */
	public static int[] getInitPos(int piece, int rot) {
		return initialPos[piece][rot].clone();
	}
}
