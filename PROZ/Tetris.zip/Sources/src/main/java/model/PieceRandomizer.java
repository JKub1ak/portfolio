package model;

import java.util.Random;

/** A class used for getting random numbers for creating new pieces. */
public class PieceRandomizer {

	/** Random number generator */
	Random gen;

	/** Creates a new PieceRandomizer with time since epoch as a seed */
	public PieceRandomizer() {
		gen = new Random();
	}

	/**
	 * Creates a new PieceRandomizer with the given seed
	 * @param seed Seed for the randomizer
	 */
	public PieceRandomizer(long seed) {
		gen = new Random(seed);
	}

	/**
	 * Returns two random numbers
	 *
	 * @param first First return number's upper boundary
	 * @param second Second return number's upper boundary
	 * @return Returns an array of two ints, first between 0 and first-1, and second between 0 and second-1
	 */
	public int[] getRandom(int first, int second) {
		return new int[] {gen.nextInt(first), gen.nextInt(second)};
	}
}
