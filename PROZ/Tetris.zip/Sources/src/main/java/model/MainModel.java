package model;

import java.util.Observer;

/**
 * The main class of the model. Holds the model together.
 */
public class MainModel implements ModelInterface {

	/** Currently played piece */
	protected TetrisPiece currentPiece;
	/** Next played piece for display purposes */
	protected TetrisPiece nextPiece;
	/** Board with fallen pieces */
	protected TetrisBoard board;
	/** Class keeping a tabs on the score */
	protected TetrisScore score;
	protected PieceRandomizer pieceRandomizer = new PieceRandomizer();

	/** left key is pressed */
	private boolean leftPressed = false;
	/** right key is pressed */
	private boolean rightPressed = false;
	/** down key is pressed */
	private boolean downPressed = false;

	/** ms per drop of the piece */
	protected int speed = 1000;
	/** count of milliseconds since last piece fall */
	private int timer = 0;
	private boolean gameOver;
	private boolean paused = false;

	/** Initialize the model. Creates new board, pieces, and score. Sets gameOver false. */
	public void init() {
		board = new TetrisBoard();
		score = new TetrisScore();
		currentPiece = new TetrisPiece(pieceRandomizer);
		nextPiece = new TetrisPiece(pieceRandomizer);
		gameOver = false;
	}

	/**
	 * Adds observers to the model.
	 * @param playingPieceObs Observer of the playing piece on the board.
	 * @param nextPieceObs Observer of the next piece to be played.
	 * @param boardObs Observer of the state of the board.
	 * @param scoreObs Observer of the score and such.
	 */
	public void addObservers(Observer playingPieceObs, Observer nextPieceObs , Observer boardObs, Observer scoreObs) {
		currentPiece.addObserver(playingPieceObs);
		nextPiece.addObserver(nextPieceObs);
		board.addObserver(boardObs);
		score.addObserver(scoreObs);
	}

	/**
	 * Method for periodically updating the model. This method is called by a controller.
	 * @param delta Time elapsed since the last update in milliseconds.
	 * @return This method returns true if the game ended.
	 */
	public boolean update(int delta) {
		if (paused || gameOver)
			return false;

		currentPiece.moveTimeout -= delta;

		if (timer > speed) {
			tryFall();
			timer = 0;
		} else if (downPressed && currentPiece.moveTimeout <= 0) {
			currentPiece.moveTimeout = 80;
			tryFall();
			timer = 0;
		}

		if (leftPressed && currentPiece.moveTimeout <= 0) {
			currentPiece.moveTimeout = 80;
			tryMovePiece(false);
		}

		if (rightPressed && currentPiece.moveTimeout <= 0) {
			currentPiece.moveTimeout = 80;
			tryMovePiece(true);
		}

		timer += delta;
		return gameOver;
	}

	/**
	 * Method for checking if the piece can fall down.
	 * If it can, then it does, if not then it tries to settle the piece into the board.
	 */
	private void tryFall() {
		if(board.checkPosition(currentPiece.getY()+1,currentPiece.getX(),currentPiece.getPieceBoard()))
			currentPiece.fall();
		else
			settle();
	}

	/**
	 * Called in case a piece is being settled above the playing board, when the player loses.
	 * Sets a flag and calls gameOver in score to notify UI observers.
	 */
	private void gameOver() {
		gameOver = true;
		score.gameOver();
	}

	/**
	 * This method tries to move a piece one to a side. The side is specified in an argument.
	 * @param ifRight If the piece is to be moved to the right or left. True - right, false - left.
	 * @return Method returns true if the move was successful.
	 */
	private boolean tryMovePiece(boolean ifRight) {
		int d;
		if (ifRight) d = 1;
		else d = -1;
		if (board.checkPosition(currentPiece.getY(),currentPiece.getX()+d,currentPiece.getPieceBoard())) {
			currentPiece.moveSide(ifRight);
			return true;
		}
		return false;
	}

	/**
	 * This method tries to rotate a piece.
	 * @param clockwise If this is true the piece is rotated clockwise, else - counterclockwise.
	 */
	private void tryRotate(boolean clockwise) {
		int[][] rotatedBoard = currentPiece.getRotatedBoard(clockwise);
		if (board.checkPosition(currentPiece.getY(),currentPiece.getX(),rotatedBoard))
			if (clockwise)
				currentPiece.setBoard(rotatedBoard,1);
			else
				currentPiece.setBoard(rotatedBoard,-1);
	}

	/**
	 * This method tries to settle a moving playing piece into the board at it's location,
	 * then gets board to check for lines to clear and updates the score.
	 * Afterwards it re-initializes the pieces.
	 */
	private void settle() {
		if (board.settle(currentPiece)) {
			speed = score.update(board.checkLines());
		} else if (board.isGameOver()) {
			gameOver();
			return;
		}
		currentPiece.initialize(nextPiece);
		nextPiece.initialize(pieceRandomizer);
	}

	/** Called when down is released */
	public void setDownReleased() {
		downPressed = false;
	}
	/** Called when left is released */
	public void setLeftReleased() {
		leftPressed = false;
	}
	/** Called when right is released */
	public void setRightReleased() {
		rightPressed = false;
	}

	/** Called when down is pressed */
	public void setDownPressed() {
		if (gameOver)
			return;
		currentPiece.moveTimeout = 300;
		tryFall();
		timer = 0;
		downPressed = true;
	}

	/** Called when left is pressed */
	public void setLeftPressed() {
		if (gameOver)
			return;
		if(!tryMovePiece(false))
			return;
		currentPiece.moveTimeout = 300;
		leftPressed = true;
	}

	/** Called when right is pressed */
	public void setRightPressed() {
		if (gameOver)
			return;
		if(!tryMovePiece(true))
			return;
		currentPiece.moveTimeout = 300;
		rightPressed = true;
	}

	/** Called when z is pressed */
	public void zPressed() {
		if (gameOver)
			return;
		tryRotate(false);
	}

	/** Called when x is pressed */
	public void xPressed() {
		if (gameOver)
			return;
		tryRotate(true);
	}

	/**
	 * Pauses or un-pauses the model
	 * @param paused Pause or un-pause.
	 */
	public void setPaused(boolean paused) {
		this.paused = paused;
		score.setPaused(paused);
	}
}
