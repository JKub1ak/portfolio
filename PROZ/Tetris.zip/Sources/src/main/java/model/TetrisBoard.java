package model;


import java.util.Observable;
import java.util.Observer;

/**
 * The board with fallen pieces
 * Note: width or x grow right,
 *       height or y grow DOWN
 *       therefore row y = 0 is the top most row of the board
 */
public class TetrisBoard extends Observable implements ModelInterface.ObservableBoard {

	/** Width of the playing area in squares */
	public static final int boardWidth = ModelInterface.boardWidth;
	/** Height of the playing area in squares */
	public static final int boardHeight = ModelInterface.boardHeight;

	private boolean gameOver;

	/** Playing board array */
	protected int[][] board = new int[boardHeight][boardWidth];

	TetrisBoard() {clearBoard();}

	/** Clears the board */
	void clearBoard() {
		gameOver = false;
		for (int i = 0; i < boardHeight; i++)
			for (int j = 0; j < boardWidth; j++)
				board[i][j] = 0;
	}

	/**
	 * Checks if an element with given coordinates is within the board boundary
	 * @param y Y coordinate of the element
	 * @param x X coordinate of the element
	 * @return True if the element is within the boundaries of the board
	 */
	boolean isOnBoard(int y, int x) {
		return  (x >= 0 && x < boardWidth) &&
				(y >= 0 && y < boardHeight);
	}

	/**
	 * Get value of a field on the board
	 * @param y Y coordinate of the element
	 * @param x X coordinate of the element
	 * @return Returns value of an element on the board or -1 if impossible
	 */
	int getBoardPoint(int y, int x) {
		if( isOnBoard(y,x) )
			return board[y][x];
		return -1;
	}

	/**
	 * Returns the current board state
	 * @return Clone of the current board
	 */
	public int[][] getBoard() {
		return board.clone();
	}

	/**
	 * Test method that sets value of a field on the board
	 * @param x X coordinate of the element
	 * @param y Y coordinate of the element
	 * @return Returns true if successful
	 */
	boolean setBoardPoint(int y, int x, int val) {
		if(isOnBoard(y,x)) {
			board[y][x] = val;
			setChanged();
			notifyObservers(boardStateChangeNotification);
			return true;
		}
		return false;
	}

	/**
	 * Tries to settle a given piece into the board
	 * @param piece A piece to be settled into the board
	 * @return Whether or not operation was successful. If wasn't, the board might need to be re-initiated
	 */
	boolean settle(TetrisPiece piece) {
		for (int i = 0; i < TetrisPiece.pieceSize; i++)
			for (int j = 0; j < TetrisPiece.pieceSize; j++) {
				if (piece.getField(i,j) != 0) {
					if (i+piece.getY() < 0) {
						gameOver = true;
						return false;
					}
					if (board[i][j] != 0 || !setBoardPoint(i+piece.getY(), j+piece.getX(), piece.getPieceType()+1) ){
						return false;
					}
				}
			}
		setChanged();
		notifyObservers(boardStateChangeNotification);
		return true;
	}

	/**
	 * Removes row y and falls all the above pieces
	 * @param y Row to be removed
	 */
	protected void deleteLine(int y) {
		for (int i = y; i > 0; --i)
			for (int j = 0; j < boardWidth; ++j)
				setBoardPoint(i,j,getBoardPoint(i-1,j));
	}

	/**
	 * Checks for filled lines, removes them and returns the number of lines removed
	 * @return Number of found and removed full lines
	 */
	int checkLines() {
		int lines = 0;
		for (int i = 0; i < boardHeight; ++i) {
			int j = 0;
			while (j < boardWidth) {
				if (getBoardPoint(i,j) == 0)
					break;
				++j;
			}
			if (j == boardWidth) {
				deleteLine(i);
				++lines;
			}
		}
		setChanged();
		notifyObservers(boardStateChangeNotification);
		return lines;
	}

	/**
	 * Checks if the playing piece can be moved to a specific place on the board without collision.
	 * @param y     Y on the playing board.
	 * @param x     X on the playing board.
	 * @param pieceBoard Board of the playing piece to be checked.
	 * @return Returns true if the specified position on the board can have the pieceBoard without collision.
	 */
	boolean checkPosition(int y, int x, int[][] pieceBoard) {
		for (int i = 0; i < pieceBoard.length; i++)
			for (int j = 0; j < pieceBoard[i].length; j++) {
				if (y+i >= 0 && y+i < boardHeight && x+j >= 0 && x+j < boardWidth) {
					if (this.board[y + i][x + j] != 0 && pieceBoard[i][j] != 0)
						return false;
				} else if ( (y+i >= boardHeight || x+j < 0 || x+j >= boardWidth) && pieceBoard[i][j] != 0)
					return false;
			}
		return true;
	}

	/**
	 * Additionally to adding an observer, notifies it so the observer gets updated immediately.
	 * @param o Observer to be added.
	 */
	@Override
	public synchronized void addObserver(Observer o) {
		super.addObserver(o);
		setChanged();
		notifyObservers(boardStateChangeNotification);
	}

	/** Returns true if the game is over. */
	boolean isGameOver() {return gameOver;}
}
