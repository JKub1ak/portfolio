import controller.MainController;
import model.MainModel;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.SlickException;
import view.MainView;

import java.io.File;

public class Main {
	public static void main(String[] args) {

		File resources = new File("build\\resources\\main");
		if (!resources.exists()) {
			resources = new File("resources");
		}
		System.setProperty("org.lwjgl.librarypath", resources.getAbsolutePath() + "\\_natives");
		System.setProperty("net.java.games.input.librarypath", resources.getAbsolutePath() + "\\_natives");

		try {
			MainModel model = new MainModel();
			MainView view = new MainView();
			MainController game = new MainController("Tetris",resources);
			game.addModel(model);
			game.addView(view);
			AppGameContainer container = new AppGameContainer(game);
			container.setShowFPS(false);
			container.setDisplayMode(504,656,false);
			container.start();
		} catch (SlickException e) {
			e.printStackTrace();
		}
	}
}
