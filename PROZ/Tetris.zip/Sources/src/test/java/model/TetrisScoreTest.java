package model;

import model.ModelInterface.ObservableScore;
import org.junit.Test;

import java.util.Observable;
import java.util.Observer;

import static org.junit.Assert.*;

public class TetrisScoreTest {

	@Test
	public void update() {
		TetrisScore score = new TetrisScore();
		TestObserver o = new TestObserver();
		score.addObserver(o);
		assertArrayEquals(new int[] {0,0,0},o.data);
		assertEquals(-1, score.update(7));
		assertEquals(1000, score.update(1));
		assertArrayEquals(new int[] {100,1,0},o.data);
		assertEquals(1000, score.update(1));
		assertArrayEquals(new int[] {200,2,0},o.data);
		assertEquals(1000, score.update(2));
		assertArrayEquals(new int[] {500,4,0},o.data);
		assertEquals(1000, score.update(3));
		assertArrayEquals(new int[] {1000,7,0},o.data);
		assertEquals(1000-40, score.update(4));
		assertArrayEquals(new int[] {1800,11,1},o.data);
	}

	private static class TestObserver implements Observer {
		int[] data = {0,0,0};

		@Override
		public void update(Observable o, Object arg) {
			if (!((String)arg).equals(((ObservableScore)o).scoreChangeNotification))
				return;
			this.data = ((ObservableScore)o).getData();
		}
	}
}