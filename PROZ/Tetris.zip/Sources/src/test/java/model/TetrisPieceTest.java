package model;

import org.junit.Test;

import static org.junit.Assert.*;

public class TetrisPieceTest {

	void printArray(int[][] arr) {
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				System.out.print(arr[i][j]);
			}
			System.out.println("");
		}
		System.out.println("");
	}

	@Test
	public void getPieceType() {
		TetrisPiece tp = new TetrisPiece();
		assertEquals(-1, tp.getPieceType());
		tp = new TetrisPiece(0, 0);
		assertEquals(0, tp.getPieceType());
		tp = new TetrisPiece(1, 0);
		assertEquals(1, tp.getPieceType());
		tp = new TetrisPiece(2, 0);
		assertEquals(2, tp.getPieceType());
		tp = new TetrisPiece(3, 0);
		assertEquals(3, tp.getPieceType());
		tp = new TetrisPiece(4, 0);
		assertEquals(4, tp.getPieceType());
		tp = new TetrisPiece(5, 0);
		assertEquals(5, tp.getPieceType());
		tp = new TetrisPiece(6, 0);
		assertEquals(6, tp.getPieceType());
	}

	@Test
	public void setPieceType() {
		TetrisPiece tp = new TetrisPiece();
		TestObserver o = new TestObserver();
		tp.addObserver(o);
		assertEquals(-1, tp.getPieceType());
		assertTrue(tp.setPieceType(5));
		assertEquals(5, tp.getPieceType());
		assertEquals(o.updated, tp.pieceStateChangeNotification);
		o.updated = "";
		assertFalse(tp.setPieceType(77));
		assertEquals(-1, tp.getPieceType());
		assertNotEquals(o.updated, tp.pieceStateChangeNotification);
	}

	@Test
	public void getPiece() {
		int[][] out = {
				{0, 0, 1, 0, 0},
				{0, 0, 1, 0, 0},
				{0, 0, 1, 0, 0},
				{0, 0, 1, 0, 0},
				{0, 0, 0, 0, 0}};
		assertArrayEquals(out,TetrisPiece.getPiece(0));
		out = new int[][]{
				{0, 0, 0, 0, 0},
				{0, 0, 2, 2, 0},
				{0, 2, 2, 0, 0},
				{0, 0, 0, 0, 0},
				{0, 0, 0, 0, 0}};
		assertArrayEquals(out,TetrisPiece.getPiece(1));
		out = new int[][]{
				{0, 0, 0, 0, 0},
				{0, 3, 3, 0, 0},
				{0, 0, 3, 3, 0},
				{0, 0, 0, 0, 0},
				{0, 0, 0, 0, 0}};
		assertArrayEquals(out,TetrisPiece.getPiece(2));
		out = new int[][]{
				{0, 0, 0, 0, 0},
				{0, 0, 4, 0, 0},
				{0, 0, 4, 0, 0},
				{0, 0, 4, 4, 0},
				{0, 0, 0, 0, 0}};
		assertArrayEquals(out,TetrisPiece.getPiece(3));
		out = new int[][]{
				{0, 0, 0, 0, 0},
				{0, 0, 5, 0, 0},
				{0, 0, 5, 0, 0},
				{0, 5, 5, 0, 0},
				{0, 0, 0, 0, 0}};
		assertArrayEquals(out,TetrisPiece.getPiece(4));
		out = new int[][]{
				{0, 0, 0, 0, 0},
				{0, 6, 6, 0, 0},
				{0, 6, 6, 0, 0},
				{0, 0, 0, 0, 0},
				{0, 0, 0, 0, 0}};
		assertArrayEquals(out,TetrisPiece.getPiece(5));
		out = new int[][]{
				{0, 0, 0, 0, 0},
				{0, 0, 7, 0, 0},
				{0, 7, 7, 7, 0},
				{0, 0, 0, 0, 0},
				{0, 0, 0, 0, 0}};
		assertArrayEquals(out,TetrisPiece.getPiece(6));
	}

	@Test
	public void getInitPos() {
		// manual check, unfortunately
		int type = 6;
		int rot = 3;
		TetrisBoard tb = new TetrisBoard();
		TetrisPiece tp = new TetrisPiece(type, rot);
		boardPrint(tb,tp);
		tp.fall();
		boardPrint(tb,tp);
		tp.fall();
		boardPrint(tb,tp);
	}

	@Test
	public void getPieceRotation() {
		System.out.println("One piece");
		TetrisPiece tp = new TetrisPiece(0,0);
		assertEquals(0,tp.getPieceRotation());
		System.out.println("Two piece");
		tp = new TetrisPiece(0,1);
		assertEquals(1,tp.getPieceRotation());
		System.out.println("Three piece");
		tp = new TetrisPiece(0,2);
		assertEquals(2,tp.getPieceRotation());
		System.out.println("Four piece");
		tp = new TetrisPiece(0,3);
		assertEquals(3,tp.getPieceRotation());
		System.out.println("Five piece");
		tp = new TetrisPiece(0,4);
		assertEquals(-1,tp.getPieceRotation());
	}

	@Test
	public void setPieceRotation() {
		TetrisPiece tp = new TetrisPiece(0,0);
		assertEquals(0,tp.getPieceRotation());
		TestObserver o = new TestObserver();
		tp.addObserver(o);
		o.updated = "";
		assertTrue(tp.setPieceRotation(0));
		assertEquals(0,tp.getPieceRotation());
		assertNotEquals(o.updated, tp.pieceStateChangeNotification);
		o.updated = "";
		assertTrue(tp.setPieceRotation(2));
		assertEquals(2,tp.getPieceRotation());
		assertEquals(o.updated, tp.pieceStateChangeNotification);
		o.updated = "";
		assertFalse(tp.setPieceRotation(77));
		assertEquals(-1,tp.getPieceRotation());
		assertNotEquals(o.updated, tp.pieceStateChangeNotification);
	}

	@Test
	public void fall() {
		TetrisPiece tp = new TetrisPiece(0,0);
		assertEquals(-4,tp.getY());
		TestObserver o = new TestObserver();
		tp.addObserver(o);
		tp.fall();
		assertEquals(-3,tp.getY());
		assertEquals(o.updated, tp.piecePositionChangeNotification);
	}

	@Test
	public void moveSide() {
		TetrisPiece tp = new TetrisPiece(0,0);
		TestObserver o = new TestObserver();
		tp.addObserver(o);
		assertEquals(2,tp.getX());
		tp.moveSide(true);
		assertEquals(3,tp.getX());
		assertEquals(o.updated, tp.piecePositionChangeNotification);
		o.updated = "";
		tp.moveSide(false);
		assertEquals(o.updated, tp.piecePositionChangeNotification);
		o.updated = "";
		tp.moveSide(false);
		assertEquals(o.updated, tp.piecePositionChangeNotification);
		o.updated = "";
		assertEquals(1,tp.getX());
	}

	@Test
	public void rotate() {
		int[][] out ={
				{0, 0, 1, 0, 0},
				{0, 0, 1, 0, 0},
				{0, 0, 1, 0, 0},
				{0, 0, 1, 0, 0},
				{0, 0, 0, 0, 0}};
		TetrisPiece tp = new TetrisPiece(0,0);
		assertEquals(0,tp.getPieceRotation());
		tp.rotate(true,false);
		assertEquals(1,tp.getPieceRotation());
		tp.rotate(false,false);
		tp.rotate(false,false);
		assertEquals(3,tp.getPieceRotation());
		TestObserver o = new TestObserver();
		tp.addObserver(o);
		tp.rotate(true,true);
		assertEquals(0,tp.getPieceRotation());
		assertEquals(o.updated, tp.pieceStateChangeNotification);
		o.updated = "";
		tp.rotate(true,false);
		assertNotEquals(o.updated, tp.pieceStateChangeNotification);
	}

	void boardPrint (TetrisBoard tb, TetrisPiece testPiece) {
		System.out.print("\\  0 1 2 3 4 5 6 7 8 9\n");
		for (int i = 0; i < 5; i++) {
			System.out.print(i+": ");
			for (int j = 0; j < tb.board[i].length; j++) {
				if (testPiece == null)
					System.out.print(tb.board[i][j]+" ");
				else {
					if (i < testPiece.getY() || i >= testPiece.getY() + TetrisPiece.pieceSize
							|| j < testPiece.getX() || j >= testPiece.getX() + TetrisPiece.pieceSize)
						System.out.print(tb.board[i][j] + " ");
					else if (testPiece.getPieceBoard()[i - testPiece.getY()][j - testPiece.getX()] > tb.board[i][j])
						System.out.print(testPiece.getPieceBoard()[i - testPiece.getY()][j - testPiece.getX()] + " ");
					else
						System.out.print(tb.board[i][j] + " ");
				}
			}
			System.out.print("\n");
		}
		System.out.print("-----------------------\n");
	}

}