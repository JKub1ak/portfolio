package model;

import org.junit.Test;

import static org.junit.Assert.*;

public class TetrisBoardTest {

	void printArray(int[][] arr) {
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				System.out.print(arr[i][j]);
			}
			System.out.println("");
		}
		System.out.println("");
	}

	@Test
	public void clearBoard() {
		TetrisBoard board = new TetrisBoard();
		assertTrue(board.setBoardPoint(TetrisBoard.boardHeight/2,TetrisBoard.boardWidth/2,2));
		boolean ret = true;
		for (int i = 0; i < TetrisBoard.boardHeight; i++) {
			for (int j = 0; j < TetrisBoard.boardWidth; j++) {
				if (board.getBoardPoint(i,j)!=0)
					ret = false;
			}
		}
		assertFalse(ret);
		board.clearBoard();
		ret = true;
		for (int i = 0; i < TetrisBoard.boardHeight; i++) {
			for (int j = 0; j < TetrisBoard.boardWidth; j++) {
				if (board.getBoardPoint(i,j)!=0)
					ret = false;
			}
		}
		assertTrue(ret);
	}

	@Test
	public void isOnBoard() {
		TetrisBoard board = new TetrisBoard();
		assertTrue(board.isOnBoard(0,0));
		assertTrue(board.isOnBoard(TetrisBoard.boardHeight/2,TetrisBoard.boardWidth/2));
		assertFalse(board.isOnBoard(TetrisBoard.boardHeight,TetrisBoard.boardWidth));
	}

	@Test
	public void getBoardPointAndSetBoardPoint() {
		TetrisBoard board = new TetrisBoard();
		TestObserver o = new TestObserver();
		board.addObserver(o);
		assertTrue(board.setBoardPoint(TetrisBoard.boardHeight/2,TetrisBoard.boardWidth/2,2));
		assertEquals(o.updated,board.boardStateChangeNotification);
		assertEquals(2,board.getBoardPoint(TetrisBoard.boardHeight/2,TetrisBoard.boardWidth/2));
	}

	@Test
	public void settle() {
		TetrisBoard board = new TetrisBoard();
		TestObserver o = new TestObserver();
		board.addObserver(o);
		TetrisPiece tp = new TetrisPiece(0,0);
		boolean ret = true;
		for (int i = 0; i < TetrisBoard.boardHeight; i++) {
			for (int j = 0; j < TetrisBoard.boardWidth; j++) {
				if (board.getBoardPoint(i,j)!=0)
					ret = false;
			}
		}
		assertTrue(ret);
		for (int i = 0; i < TetrisBoard.boardHeight / 2; i++)
			tp.fall();
		for (int j = 0; j < TetrisBoard.boardWidth / 2; j++)
			tp.moveSide(true);
		assertTrue(board.settle(tp));
		assertEquals(o.updated,board.boardStateChangeNotification);
		ret = true;
		for (int i = 0; i < TetrisBoard.boardHeight; i++) {
			for (int j = 0; j < TetrisBoard.boardWidth; j++) {
				if (board.getBoardPoint(i,j)!=0)
					ret = false;
			}
		}
		assertFalse(ret);
	}

	@Test
	public void deleteLine() {
		TetrisBoard board = new TetrisBoard();
		for (int i = TetrisBoard.boardHeight-1; i > TetrisBoard.boardHeight-3; --i)
			for (int j = 0; j < TetrisBoard.boardWidth; ++j)
				board.setBoardPoint(i,j,1);
		for (int j = 0; j < TetrisBoard.boardWidth; ++j)
			board.setBoardPoint(TetrisBoard.boardHeight-3,j,2);
		assertEquals(1,board.getBoardPoint(TetrisBoard.boardHeight-1,0));
		assertEquals(2,board.getBoardPoint(TetrisBoard.boardHeight-3,0));
		board.deleteLine(TetrisBoard.boardHeight-1);
		boolean ret = true;
		for (int i = 0; i < TetrisBoard.boardWidth; i++) {
			if (    (board.getBoardPoint(TetrisBoard.boardHeight-1,i) != 1)
				||  (board.getBoardPoint(TetrisBoard.boardHeight-2,i) != 2) )
				ret = false;
		}
		assertTrue(ret);
	}

	@Test
	public void checkLines() {
		TetrisBoard board = new TetrisBoard();
		TestObserver o = new TestObserver();
		board.addObserver(o);
		for (int i = TetrisBoard.boardHeight-1; i > TetrisBoard.boardHeight-3; --i)
			for (int j = 0; j < TetrisBoard.boardWidth; ++j)
				board.setBoardPoint(i,j,1);
		for (int j = 0; j < TetrisBoard.boardWidth-1; ++j)
			board.setBoardPoint(TetrisBoard.boardHeight-3,j,2);
		assertEquals(2,board.checkLines());
		assertEquals(o.updated,board.boardStateChangeNotification);
		boolean ret = true;
		for (int i = 0; i < TetrisBoard.boardWidth-1; i++) {
			if (board.getBoardPoint(TetrisBoard.boardHeight-1,i) != 2)
				ret = false;
		}
		if (board.getBoardPoint(TetrisBoard.boardHeight-1,TetrisBoard.boardWidth-1) != 0)
			ret = false;

		assertTrue(ret);
	}

	@Test
	public void getBoard() {
		TetrisBoard tb = new TetrisBoard();
		tb.setBoardPoint(0,0,17);
		int[][] expectedArray = new int[TetrisBoard.boardHeight][TetrisBoard.boardWidth];
		for (int i = 0; i < TetrisBoard.boardHeight; i++) {
			for (int j = 0; j < TetrisBoard.boardWidth; j++) {
				expectedArray[i][j] = 0;
			}
		}
		expectedArray[0][0]=17;
		assertArrayEquals(expectedArray,tb.getBoard());
	}

	@Test
	public void checkPosition() {
		TetrisBoard tb = new TetrisBoard();
		tb.setBoardPoint(10,5,1);
//		boardPrint(tb,null);
		TetrisPiece testPiece = new TetrisPiece(5,0);
		testPiece.setY(7);
		testPiece.setX(3);
//		boardPrint(tb,testPiece);
		assertTrue(tb.checkPosition(testPiece.getY(),testPiece.getX(),testPiece.getPieceBoard()));
		testPiece.fall();
//		boardPrint(tb,testPiece);
		assertFalse(tb.checkPosition(testPiece.getY(),testPiece.getX(),testPiece.getPieceBoard()));
	}
	void boardPrint (TetrisBoard tb, TetrisPiece testPiece) {
		System.out.print("\\  0 1 2 3 4 5 6 7 8 9\n");
		for (int i = 0; i < tb.board.length; i++) {
			System.out.print(i+": ");
			for (int j = 0; j < tb.board[i].length; j++) {
				if (testPiece == null)
					System.out.print(tb.board[i][j]+" ");
				else {
					if (i < testPiece.getY() || i >= testPiece.getY() + TetrisPiece.pieceSize
							|| j < testPiece.getX() || j >= testPiece.getX() + TetrisPiece.pieceSize)
						System.out.print(tb.board[i][j] + " ");
					else if (testPiece.getPieceBoard()[i - testPiece.getY()][j - testPiece.getX()] > tb.board[i][j])
						System.out.print(testPiece.getPieceBoard()[i - testPiece.getY()][j - testPiece.getX()] + " ");
					else
						System.out.print(tb.board[i][j] + " ");
				}
			}
			System.out.print("\n");
		}
		System.out.print("-----------------------\n");
	}
}