package model;

import java.util.Observable;
import java.util.Observer;

class TestObserver implements Observer {

	public String updated = "";

	@Override
	public void update(Observable o, Object arg) {
		updated = (String) arg;
	}
}
