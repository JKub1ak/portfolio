package model;

import org.junit.Test;

import static org.junit.Assert.*;

public class PieceRandomizerTest {

	@Test
	public void getRandom() {
		PieceRandomizer rand = new PieceRandomizer();
		int first = 7;
		int second = 4;
		for (int i = 0; i < 100; i++) {
			int[] table = rand.getRandom(first,second);
			assertTrue( table[0]>=0 && table[0]<first && table[1]>=0 &&table[1]<second );
		}
	}
}