package view;

import model.ModelInterface;

import java.util.Observable;

class TestObservableBoard extends Observable implements ModelInterface.ObservableBoard {

	private int y = 5;
	private int x = 5;
	private int num = 3;
	public void testNotify() {setChanged();notifyObservers(boardStateChangeNotification);}

	TestObservableBoard () {}
	TestObservableBoard (int y, int x) {
		this.y = y;
		this.x = x;
	}

	public void setNum(int num) {
		this.num = num;
	}

	@Override
	public int[][] getBoard() {
		int[][] ints = new int[y][x];
		for (int i = 0; i < y; i++) {
			for (int j = 0; j < x; j++) {
				ints[i][j] = num;
			}
		}
		return ints;
	}
}
