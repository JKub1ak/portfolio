package view;

import model.ModelInterface;

import java.util.Observable;

class TestObservablePiece extends Observable implements ModelInterface.ObservablePiece {

	private int num = 5;

	public void testNotifyPos() {setChanged();notifyObservers(piecePositionChangeNotification);}
	public void testNotifyState() {setChanged();notifyObservers(pieceStateChangeNotification);}

	@Override
	public int getX() {
		return 3;
	}

	@Override
	public int getY() {
		return 3;
	}

	public void setNum(int num) {
		this.num = num;
	}

	@Override
	public int[][] getPieceBoard() {
		return new int[][]{
				{0,0,0,0,0},
				{0,0,num,0,0},
				{0,num,num,num,0},
				{0,0,0,0,0},
				{0,0,0,0,0}
		};
	}
}
