package view;

import org.junit.Before;
import org.junit.Test;
import org.newdawn.slick.*;

import java.io.File;

public class PieceTest {

	@Before
	public void setUp() {
		File JGLLib = new File("D:/PROZProject/src/test/resources/_natives");
		System.setProperty("org.lwjgl.librarypath", JGLLib.getAbsolutePath());
		System.setProperty("net.java.games.input.librarypath", JGLLib.getAbsolutePath());
	}

	@Test
	public void pieceTest() throws SlickException {
		BasicGame game = new BasicGame("Test piece") {
			private Piece piece;
			private TestObservablePiece to;
			private int timer = 3000;
			private int timer2 = 1000;
			private int timer3 = 2000;

			@Override
			public void init(GameContainer gameContainer) throws SlickException {
				int size = 5;
				piece = new Piece("D:\\PROZProject\\src\\test\\resources",size,size,true);
				to = new TestObservablePiece();
				to.addObserver(piece);
//				Image img = new Image("D:\\PROZProject\\src\\test\\resources\\block_texture.png");
//				piece.setSpriteSheet(new SpriteSheet(img,img.getHeight(),img.getHeight()));
				piece.offsetY = 20;
				piece.offsetX = 20;
				int[][] ints = new int[][]{
						{0,0,0,0,0},
						{0,0,2,2,0},
						{0,2,2,0,0},
						{0,0,0,0,0},
						{0,0,0,0,0}
				};
				piece.setBlocks(ints);
			}

			@Override
			public void update(GameContainer gameContainer, int i) throws SlickException {
				if(timer2 < 0)
					to.testNotifyPos();
				if(timer3 < 0)
					to.testNotifyState();
				if (timer < 0)
					gameContainer.exit();
				else {
					timer -= i;
					timer2 -= i;
					timer3 -= i;
				}
			}

			@Override
			public void render(GameContainer gameContainer, Graphics graphics) throws SlickException {
				piece.draw();
			}
		};
		AppGameContainer container = new AppGameContainer(game);
		container.setDisplayMode(640,480,false);
		container.start();
	}

}