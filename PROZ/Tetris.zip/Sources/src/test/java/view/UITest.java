package view;

import org.junit.Before;
import org.junit.Test;
import org.newdawn.slick.*;

import java.io.File;

public class UITest {

	@Before
	public void before() {
		File JGLLib = new File("D:/PROZProject/src/test/resources/_natives");
		System.setProperty("org.lwjgl.librarypath", JGLLib.getAbsolutePath());
		System.setProperty("net.java.games.input.librarypath", JGLLib.getAbsolutePath());
	}

	@Test
	public void uiTest() throws SlickException {
		BasicGame game = new BasicGame("Test ui") {
			private UI ui;
			private TestObservableUi to;
			private int timer = 3000;
			private int timer2 = 1000;
			private boolean observe = false;

			@Override
			public void init(GameContainer gameContainer) throws SlickException {
				ui = new UI("D:/PROZProject/src/test/resources");
				to = new TestObservableUi();
				to.addObserver(ui);
			}

			@Override
			public void update(GameContainer gameContainer, int i) throws SlickException {
				if(timer2 < 0)
					observe = true;
				if (timer < 1000){
					ui.score.setPosition(100,100);
					ui.lines.setPosition(200,100);
					ui.level.setPosition(300,100);
				}
				if (timer < 0) {
					gameContainer.exit();
				}
				else {
					timer -= i;
					timer2 -= i;
				}
				if(observe)
					to.testNotify();
			}

			@Override
			public void render(GameContainer gameContainer, Graphics graphics) throws SlickException {
				ui.draw();
			}
		};
		AppGameContainer container = new AppGameContainer(game);
		container.setDisplayMode(640,480,false);
		container.start();
	}

}