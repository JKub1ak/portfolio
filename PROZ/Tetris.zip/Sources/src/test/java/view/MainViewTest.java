package view;

import org.junit.Before;
import org.junit.Test;
import org.newdawn.slick.*;

import java.io.File;

public class MainViewTest {

	@Before
	public void setUp() {
		File JGLLib = new File("D:/PROZProject/src/test/resources/_natives");
		System.setProperty("org.lwjgl.librarypath", JGLLib.getAbsolutePath());
		System.setProperty("net.java.games.input.librarypath", JGLLib.getAbsolutePath());
	}

	@Test
	public void mainViewTest() throws SlickException {
		BasicGame game = new BasicGame("Main View Test") {
			private TestObservableBoard testBoard = new TestObservableBoard(20,10);
			private TestObservablePiece testPlayingPiece = new TestObservablePiece();
			private TestObservablePiece testNextPiece = new TestObservablePiece();
			private TestObservableUi testUi = new TestObservableUi();
			private MainView view = new MainView();
			private int timer = 2000;

			@Override
			public void init(GameContainer gameContainer) throws SlickException {
				view.init(20,10,5,"D:\\PROZProject\\src\\test\\resources");
				testUi.addObserver(view.getScoreObserver());
				testBoard.addObserver(view.getBoardObserver());
				testBoard.testNotify();
				testNextPiece.addObserver(view.getNextPieceObserver());
				testNextPiece.testNotifyState();
				testPlayingPiece.addObserver(view.getPlayingPieceObserver());
				testPlayingPiece.testNotifyState();

				testBoard.setNum(3);
				testNextPiece.setNum(6);
				testPlayingPiece.setNum(6);
			}

			@Override
			public void update(GameContainer gameContainer, int i) throws SlickException {
				if (timer < 0)
					gameContainer.exit();
				if (timer < 1000){
					testUi.testNotify();
					testBoard.testNotify();
					testNextPiece.testNotifyState();
					testPlayingPiece.testNotifyState();
					testPlayingPiece.testNotifyPos();
				}

				timer -= i;
			}

			@Override
			public void render(GameContainer gameContainer, Graphics graphics) throws SlickException {
				view.render();
			}
		};
		AppGameContainer container = new AppGameContainer(game);
		container.setDisplayMode(504,656,false);
		container.start();
	}

}