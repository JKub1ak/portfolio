package view;

import org.junit.Before;
import org.junit.Test;
import org.newdawn.slick.*;

import java.io.File;

public class BoardTest {

	@Before
	public void before() {
		File JGLLib = new File("D:/PROZProject/src/test/resources/_natives");
		System.setProperty("org.lwjgl.librarypath", JGLLib.getAbsolutePath());
		System.setProperty("net.java.games.input.librarypath", JGLLib.getAbsolutePath());
	}

	@Test
	public void boardTest() throws SlickException {

		BasicGame game = new BasicGame("Test board") {
			private Board board;
			private TestObservableBoard to;
			private int timer = 2000;
			private int timer2 = 1000;
			private boolean observe = false;

			@Override
			public void init(GameContainer gameContainer) throws SlickException {
				int size = 5;
				board = new Board("D:\\PROZProject\\src\\test\\resources", size,size);
				to = new TestObservableBoard();
				to.addObserver(board);
//				Image img = new Image("D:\\PROZProject\\src\\test\\resources\\block_texture.png");
//				board.setSpriteSheet(new SpriteSheet(img,img.getHeight(),img.getHeight()));
				board.offsetX = 20;
				board.offsetY = 20;
				int[][] ints = new int[size][size];
				for (int i = 0; i < size; i++) {
					for (int j = 0; j < size; j++) {
						ints[i][j] = 1;
					}
				}
				board.setBlocks(ints);
			}

			@Override
			public void update(GameContainer gameContainer, int i) throws SlickException {
				if(timer2 < 0)
					observe = true;
				if (timer < 0)
					gameContainer.exit();
				else {
					timer -= i;
					timer2 -= i;
				}
				if(observe)
					to.testNotify();
			}

			@Override
			public void render(GameContainer gameContainer, Graphics graphics) throws SlickException {
				board.draw();
			}
		};
		AppGameContainer container = new AppGameContainer(game);
		container.setDisplayMode(640,480,false);
		container.start();
	}
}