package view;

import model.ModelInterface;

import java.util.Observable;

class TestObservableUi extends Observable implements ModelInterface.ObservableScore {

	public void testNotify() {setChanged();notifyObservers(scoreChangeNotification);}

	@Override
	public int[] getData() {
		return new int[] {1000,30,3};
	}
}
