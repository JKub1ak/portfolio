
time = 10;
G = tf([10.9994 -8.1923 0.0381], [1 -244.696 0.9788 0.0009], 0.5,'InputDelay',2);

wp = zeros(3,1);

out = sim('RysunkiModeliWPrzestrzeniStanow');

figure;
step(G,10);
hold on;
plot(out.warpierw_y,'-g');
hold on;
plot(out.wardrug_y,'-m');
title('Zerowe stany pocz�tkowe');
legend('G(z)','War 1','War 2');
hold off;
%print('out1wp0','-dpng','-r400');

figure;
step(G,10);
hold on;
plot(out.warpierw_y,'-g');
hold on;
plot(out.wardrug_y,'-m');
title('Zerowe stany pocz�tkowe');
legend('G(z)','War 1','War 2');
axis([0 10 0 3000])
hold off;
%print('out1wp0_ograniczony','-dpng','-r400');


wp = [-3;1;6];

out = sim('RysunkiModeliWPrzestrzeniStanow');

figure;
step(G,10);
hold on;
plot(out.warpierw_y,'-g');
hold on;
plot(out.wardrug_y,'-m');
title('Stan pocz�tkowy x1=1, reszta 0');
legend('G(z)','War 1','War 2');
hold off;
%print('out1wp1_0_0','-dpng','-r400');

figure;
step(G,10);
hold on;
plot(out.warpierw_y,'-g');
hold on;
plot(out.wardrug_y,'-m');
title('Stan pocz�tkowy x1=1, reszta 0');
legend('G(z)','War 1','War 2');
axis([0 10 0 3000])
hold off;
%print('out1wp1_0_0_ograniczony','-dpng','-r400');


wp = ones(3,1);

out = sim('RysunkiModeliWPrzestrzeniStanow');

figure;
step(G,10);
hold on;
plot(out.warpierw_y,'-g');
hold on;
plot(out.wardrug_y,'-m');
title('Wszystkie stany pocz�tkowe 1');
legend('G(z)','War 1','War 2');
hold off;
%print('out1wp1','-dpng','-r400');

figure;
step(G,10);
hold on;
plot(out.warpierw_y,'-g');
hold on;
plot(out.wardrug_y,'-m');
title('Wszystkie stany pocz�tkowe 1');
legend('G(z)','War 1','War 2');
axis([0 10 0 3000])
hold off;
%print('out1wp1_ograniczony','-dpng','-r400');

%-----------------------------------
%-----------------------------------

%warunki pocz�tkowe
wp = [-3 1 6];

%macierz wykorzystywana do rozwi�zania uk�adu r�wna� parametr�w
P = [10.9994 -8.1923 0.0381;-8.1923 1993.9 -9.313;0.0381 -9.313 0.0299];
p = [-244.696;0.9788;-0.0009];


%-----------------------------------
%-----------------------------------

%regulator (z-z0)^3
z0 = 0.1;
k = P\(mkZ(z0)-p);

out = sim('Model2ZRegulatorami','StopTime','10');
figure;
plot(out.x1);
hold on;
plot(out.x2);
hold on;
plot(out.x3);
xlim([0 10]);
title('Regulator I, z0=0.1. Zmienne stanu');
legend('x1','x2','x3');
%print('out2z0=01stany','-dpng','-r400');
figure;
plot(out.u);
xlim([0 10]);
title('Regulator I, z0=0.1. Sygna� steruj�cy');
%print('out2z0=01sterowanie','-dpng','-r400');

z0 = 0.3;
k = P\(mkZ(z0)-p);

out = sim('Model2ZRegulatorami','StopTime','15');
figure;
plot(out.x1);
hold on;
plot(out.x2);
hold on;
plot(out.x3);
xlim([0 10]);
title('Regulator I, z0=0.3. Zmienne stanu');
legend('x1','x2','x3');
%print('out2z0=03stany','-dpng','-r400');
figure;
plot(out.u);
xlim([0 10]);
title('Regulator I, z0=0.3. Sygna� steruj�cy');
%print('out2z0=03sterowanie','-dpng','-r400');


z0 = 0.5;
k = P\(mkZ(z0)-p);

out = sim('Model2ZRegulatorami','StopTime','40');
figure;
plot(out.x1);
hold on;
plot(out.x2);
hold on;
plot(out.x3);
xlim([0 10]);
title('Regulator I, z0=0.5. Zmienne stanu');
legend('x1','x2','x3');
%print('out2z0=05stany','-dpng','-r400');
figure;
plot(out.u);
xlim([0 10]);
title('Regulator I, z0=0.5. Sygna� steruj�cy');
%print('out2z0=05sterowanie','-dpng','-r400');


%-----------------------------------
%-----------------------------------

%regulator (z-z0)(z-(a+bj))(z-(a-bj)
z0 = 0.3;

%zmiany b
a = 0.3;
b = 0.1;
k = P\(mkZ2(z0,a,b)-p);

out = sim('Model2ZRegulatorami','StopTime','40');
figure;
plot(out.x1);
hold on;
plot(out.x2);
hold on;
plot(out.x3);
xlim([0 10]);
title('Regulator II, a=0.3, b=0.1. Zmienne stanu');
legend('x1','x2','x3');
%print('out3a=03b=01stany','-dpng','-r400');
figure;
plot(out.u);
xlim([0 10]);
title('Regulator II, a=0.3, b=0.1. Sygna� steruj�cy');
%print('out3a=03b=01sterowanie','-dpng','-r400');


a = 0.3;
b = 0.5;
k = P\(mkZ2(z0,a,b)-p);

out = sim('Model2ZRegulatorami','StopTime','40');
figure;
plot(out.x1);
hold on;
plot(out.x2);
hold on;
plot(out.x3);
xlim([0 10]);
title('Regulator II, a=0.3, b=0.5. Zmienne stanu');
legend('x1','x2','x3');
%print('out3a=03b=05stany','-dpng','-r400');
figure;
plot(out.u);
xlim([0 10]);
title('Regulator II, a=0.3, b=0.5. Sygna� steruj�cy');
%print('out3a=03b=05sterowanie','-dpng','-r400');


a = 0.3;
b = 0.8;
k = P\(mkZ2(z0,a,b)-p);

out = sim('Model2ZRegulatorami','StopTime','40');
figure;
plot(out.x1);
hold on;
plot(out.x2);
hold on;
plot(out.x3);
xlim([0 10]);
title('Regulator II, a=0.3, b=0.8. Zmienne stanu');
legend('x1','x2','x3');
%print('out3a=03b=08stany','-dpng','-r400');
figure;
plot(out.u);
xlim([0 10]);
title('Regulator II, a=0.3, b=0.8. Sygna� steruj�cy');
%print('out3a=03b=08sterowanie','-dpng','-r400');

%-----------------------------------
%-----------------------------------

%testy biernego obserwatora
wp = [-3 1 6];
A = [244.696 1 0;-0.9788 0 1;0.0009 0 0];
B = [10.9994;-8.1923;0.0381];
%ustawienia obserwatora
wpo = [0 0];
z2 = 0.1;
z3 = 0.1;

L = [-z2-z3;z2*z3];
E = [-L(1)^2+L(2)+A(2,1)-A(1,1)*L(1); -L(1)*L(2)+A(3,1)-A(1,1)*L(2)];
F = [B(2)-L(1)*B(1); B(3)-L(2)*B(1)];
%ustawienia regulatora
z0 = 0.1;

k=P\(mkZ(z0)-p);


out = sim('Model2ZBiernymObserwatorem','StopTime','40');
figure;
plot(out.x2);
hold on;
plot(out.ox2,'--');
hold on;
plot(out.x3);
hold on;
plot(out.ox3,'--');
xlim([0 10]);
title(sprintf('Regulator rzeczywisty. Obserwator z2=%.1f, z3=%.1f. Zmienne stanu',z2,z3));
legend('x2','ox2','x3','ox3');
%print(sprintf('out4RrObZ2=%.fZ3=%.fstany',z2,z3),'-dpng','-r400');
figure;
plot(out.x2);
hold on;
plot(out.ox2,'--');
axis([0.95 1.55 700 710])
title(sprintf('Regulator rzeczywisty. Obserwator z2=%.1f, z3=%.1f. Zmienne stanu',z2,z3));
legend('x2','ox2');
%print(sprintf('out4RrObZ2=%.fZ3=%.fstanyZoom',z2,z3),'-dpng','-r400');

z0 = 0.3;
a = 0.3;
b = 0.1;

k=P\(mkZ2(z0,a,b)-p);

out = sim('Model2ZBiernymObserwatorem','StopTime','40');
figure;
plot(out.x2);
hold on;
plot(out.ox2,'--');
hold on;
plot(out.x3);
hold on;
plot(out.ox3,'--');
xlim([0 10]);
title(sprintf('Regulator zespolony. Obserwator z2=%.1f, z3=%.1f. Zmienne stanu',z2,z3));
legend('x2','ox2','x3','ox3');
%print(sprintf('out4RzObZ2=%.fZ3=%.fstany',z2,z3),'-dpng','-r400');


wpo = [0 0];
z2 = 0.7;
z3 = 0.7;

L = [-z2-z3;z2*z3];
E = [-L(1)^2+L(2)+A(2,1)-A(1,1)*L(1); -L(1)*L(2)+A(3,1)-A(1,1)*L(2)];
F = [B(2)-L(1)*B(1); B(3)-L(2)*B(1)];
%ustawienia regulatora
z0 = 0.1;

k=P\(mkZ(z0)-p);


out = sim('Model2ZBiernymObserwatorem','StopTime','40');
figure;
plot(out.x2);
hold on;
plot(out.ox2,'--');
hold on;
plot(out.x3);
hold on;
plot(out.ox3,'--');
xlim([0 10]);
title(sprintf('Regulator rzeczywisty. Obserwator z2=%.1f, z3=%.1f. Zmienne stanu',z2,z3));
legend('x2','ox2','x3','ox3');
%print(sprintf('out4RrObZ2=%.fZ3=%.fstany',z2,z3),'-dpng','-r400');
figure;
plot(out.x2);
hold on;
plot(out.ox2,'--');
axis([0.95 1.55 695 705])
title(sprintf('Regulator rzeczywisty. Obserwator z2=%.1f, z3=%.1f. Zmienne stanu',z2,z3));
legend('x2','ox2');
%print(sprintf('out4RrObZ2=%.fZ3=%.fstanyZoom',z2,z3),'-dpng','-r400');


z0 = 0.3;
a = 0.3;
b = 0.1;

k=P\(mkZ2(z0,a,b)-p);

out = sim('Model2ZBiernymObserwatorem','StopTime','40');
figure;
plot(out.x2);
hold on;
plot(out.ox2,'--');
hold on;
plot(out.x3);
hold on;
plot(out.ox3,'--');
xlim([0 10]);
title(sprintf('Regulator zespolony. Obserwator z2=%.1f, z3=%.1f. Zmienne stanu',z2,z3));
legend('x2','ox2','x3','ox3');
%print(sprintf('out4RzObZ2=%.fZ3=%.fstany',z2,z3),'-dpng','-r400');

%-----------------------------------
%-----------------------------------
%uk�ad z obserwatorem

wp = [-3 1 6];
A = [244.696 1 0;-0.9788 0 1;0.0009 0 0];
B = [10.9994;-8.1923;0.0381];
%ustawienia obserwatora
wpo = [0 0];
z2 = 0.1;
z3 = 0.1;

L = [-z2-z3;z2*z3];
E = [-L(1)^2+L(2)+A(2,1)-A(1,1)*L(1); -L(1)*L(2)+A(3,1)-A(1,1)*L(2)];
F = [B(2)-L(1)*B(1); B(3)-L(2)*B(1)];
%ustawienia regulatora
z0 = 0.1;

k=P\(mkZ(z0)-p);


out = sim('Model2ZObserwatorem','StopTime','40');
figure;
plot(out.x2);
hold on;
plot(out.ox2,'--');
hold on;
plot(out.x3);
hold on;
plot(out.ox3,'--');
xlim([0 10]);
title(sprintf('Regulator rzeczywisty. Obserwator z2=%.1f, z3=%.1f. Zmienne stanu',z2,z3));
legend('x2','ox2','x3','ox3');
%print(sprintf('out5RrObZ2=%.fZ3=%.fstany',z2,z3),'-dpng','-r400');
figure;
plot(out.u);
xlim([0 10]);
title(sprintf('Regulator rzeczywisty. Obserwator z2=%.1f, z3=%.1f. Sterowanie',z2,z3));
%print(sprintf('out5RrObZ2=%.fZ3=%.fsterowanie',z2,z3),'-dpng','-r400');

z2 = 0.7;
z3 = 0.7;

L = [-z2-z3;z2*z3];
E = [-L(1)^2+L(2)+A(2,1)-A(1,1)*L(1); -L(1)*L(2)+A(3,1)-A(1,1)*L(2)];
F = [B(2)-L(1)*B(1); B(3)-L(2)*B(1)];

out = sim('Model2ZObserwatorem','StopTime','40');
figure;
plot(out.x2);
hold on;
plot(out.ox2,'--');
hold on;
plot(out.x3);
hold on;
plot(out.ox3,'--');
xlim([0 10]);
title(sprintf('Regulator rzeczywisty. Obserwator, z2=%.1f, z3=%.1f. Zmienne stanu',z2,z3));
legend('x2','ox2','x3','ox3');
%print(sprintf('out5RrObZ2=%.fZ3=%.fstany',z2,z3),'-dpng','-r400');
figure;
plot(out.u);
xlim([0 10]);
title(sprintf('Regulator rzeczywisty. Obserwator, z2=%.1f, z3=%.1f. Sterowanie',z2,z3));
%print(sprintf('out5RrObZ2=%.fZ3=%.fsterowanie',z2,z3),'-dpng','-r400');

%ustawienia regulatroa
z0 = 0.3;
a = 0.3;
b = 0.1;
k = P\(mkZ2(z0,a,b)-p);

z2 = 0.1;
z3 = 0.1;

L = [-z2-z3;z2*z3];
E = [-L(1)^2+L(2)+A(2,1)-A(1,1)*L(1); -L(1)*L(2)+A(3,1)-A(1,1)*L(2)];
F = [B(2)-L(1)*B(1); B(3)-L(2)*B(1)];

out = sim('Model2ZObserwatorem','StopTime','40');
figure;
plot(out.x2);
hold on;
plot(out.ox2,'--');
hold on;
plot(out.x3);
hold on;
plot(out.ox3,'--');
xlim([0 10]);
title(sprintf('Regulator zespolony. Obserwator, z2=%.1f, z3=%.1f. Zmienne stanu',z2,z3));
legend('x2','ox2','x3','ox3');
%print(sprintf('out5RzObZ2=%.fZ3=%.fstany',z2,z3),'-dpng','-r400');
figure;
plot(out.u);
xlim([0 10]);
title(sprintf('Regulator zespolony. Obserwator, z2=%.1f, z3=%.1f. Sterowanie',z2,z3));
%print(sprintf('out5RzObZ2=%.fZ3=%.fsterowanie',z2,z3),'-dpng','-r400');

z2 = 0.7;
z3 = 0.7;

L = [-z2-z3;z2*z3];
E = [-L(1)^2+L(2)+A(2,1)-A(1,1)*L(1); -L(1)*L(2)+A(3,1)-A(1,1)*L(2)];
F = [B(2)-L(1)*B(1); B(3)-L(2)*B(1)];

out = sim('Model2ZObserwatorem','StopTime','40');
figure;
plot(out.x2);
hold on;
plot(out.ox2,'--');
hold on;
plot(out.x3);
hold on;
plot(out.ox3,'--');
xlim([0 10]);
title(sprintf('Regulator zespolony. Obserwator, z2=%.1f, z3=%.1f. Zmienne stanu',z2,z3));
legend('x2','ox2','x3','ox3','Location','southeast');
%print(sprintf('out5RzObZ2=%.fZ3=%.fstany',z2,z3),'-dpng','-r400');
figure;
plot(out.u);
xlim([0 10]);
title(sprintf('Regulator zespolony. Obserwator, z2=%.1f, z3=%.1f. Sterowanie',z2,z3));
%print(sprintf('out5RzObZ2=%.fZ3=%.fsterowanie',z2,z3),'-dpng','-r400');


z0 = 0.3;
k = P\(mkZ(z0)-p);

z2 = 0.1;
z3 = 0.1;

L = [-z2-z3;z2*z3];
E = [-L(1)^2+L(2)+A(2,1)-A(1,1)*L(1); -L(1)*L(2)+A(3,1)-A(1,1)*L(2)];
F = [B(2)-L(1)*B(1); B(3)-L(2)*B(1)];

out = sim('Model2ZObserwatorem','StopTime','40');
figure;
plot(out.x2);
hold on;
plot(out.ox2,'--');
hold on;
plot(out.x3);
hold on;
plot(out.ox3,'--');
xlim([0 10]);
title(sprintf('Regulator rzeczywisty. Obserwator, z2=%.1f, z3=%.1f. Zmienne stanu',z2,z3));
legend('x2','ox2','x3','ox3');
%print(sprintf('out5Rr3ObZ2=%.fZ3=%.fstany',z2,z3),'-dpng','-r400');
figure;
plot(out.u);
xlim([0 10]);
title(sprintf('Regulator rzeczywisty. Obserwator, z2=%.1f, z3=%.1f. Sterowanie',z2,z3));
%print(sprintf('out5Rr3ObZ2=%.fZ3=%.fsterowanie',z2,z3),'-dpng','-r400');

z2 = 0.7;
z3 = 0.7;

L = [-z2-z3;z2*z3];
E = [-L(1)^2+L(2)+A(2,1)-A(1,1)*L(1); -L(1)*L(2)+A(3,1)-A(1,1)*L(2)];
F = [B(2)-L(1)*B(1); B(3)-L(2)*B(1)];

out = sim('Model2ZObserwatorem','StopTime','40');
figure;
plot(out.x2);
hold on;
plot(out.ox2,'--');
hold on;
plot(out.x3);
hold on;
plot(out.ox3,'--');
xlim([0 10]);
title(sprintf('Regulator rzeczywisty. Obserwator, z2=%.1f, z3=%.1f. Zmienne stanu',z2,z3));
legend('x2','ox2','x3','ox3','Location','southeast');
%print(sprintf('out5Rr3ObZ2=%.fZ3=%.fstany',z2,z3),'-dpng','-r400');
figure;
plot(out.u);
xlim([0 10]);
title(sprintf('Regulator rzeczywisty. Obserwator, z2=%.1f, z3=%.1f. Sterowanie',z2,z3));
%print(sprintf('out5Rr3ObZ2=%.fZ3=%.fsterowanie',z2,z3),'-dpng','-r400');

%-----------------------------------
%-----------------------------------

function Z = mkZ(z0)
	Z = [-3*z0;3*z0^2;-z0^3];
end

function Z = mkZ2(z0,a,b)
	Z = [-2*a-z0;a^2+2*z0*a+b^2;-z0*(a^2+b^2)];
end