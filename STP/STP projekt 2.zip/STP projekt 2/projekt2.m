K_0 = 4.4;
T_0 = 5;
T_1 = 2.11;
T_2 = 4.71;
Tp = 0.5;

Km = 1.75;
Tm = 2;


% obrazek 1-TODO - wykres/y do pokazania
obrazek = 5;
% printing == 1 - obrazek zostanie zapisany
printing = 0;

% transmitancja ci�g�a:
s = tf('s');
Gs0 = K_0/((T_1*s+1)*(T_2*s+1))*exp(-T_0*s);
Gs = K_0*Km/((T_1*s+1)*(T_2*s+1))*exp(-T_0*Tm*s);

% transmitancja dyskretna:
z = tf('z');
Gz0 = c2d(Gs0,Tp,'zoh');
Gz = c2d(Gs,Tp,'zoh');

if obrazek == 1
	f = figure;
	step(Gs);
	hold on;
	step(Gz);
	hold off;
	if printing == 1
		print('odpowiedzi_skok_tr','-dpng','-r400');
	end
end
clear f;

% regulator:
reg = 1;

K_kr = 0.48884;
T_kr = 20;
if reg == 0
	Kp = K_kr;
	Ki = 0;
	Td = 0;
	Ti = 1;
elseif reg == 1
	Kp = K_kr*0.6;
	Ti = T_kr*0.5;
	Td = T_kr*0.12;
	Ki = 1;
elseif reg == 2
	Kp = K_kr*0.5;
	Ti = T_kr*0.4;
	Td = T_kr*0.16;
	Ki = 1;
end
Rs = Kp*(1+Ki/(Ti*s) + Td*s);

% uk�ad:
Hs = Gs*Rs/(1+Gs*Rs);
if obrazek == 2
	f = figure;
	step(Hs);
	if printing == 1
		print('regulator_PID_ciagly','-dpng','-r400');
	end
end

% regulator dyskretny:
r = [Kp*Td/Tp Kp*(Tp/(2*Ti)-2*Td/Tp-1) Kp*(1+Tp/(2*Ti)+Td/Tp)];
Rz = (r(1)*z^(-2)+r(2)*z^(-1)+r(3))/(1-z^(-1));

% uk�ad:
Hz = Gz*Rz/(1+Gz*Rz);
if obrazek == 3
	f = figure;
	step(Hz);
	if printing == 1
		print(f,'regulator_PID_dyskretny','-dpng','-r400');
	end
end
clear Rz Hz Rs Hs K_kr T_kr reg Kp Ki Ti Td;

% zadanie 4 - regulatory
% r�wnanie r�nicowe
% y(k) = 1.688*y(k-1) - 0.7096*y(k-2) + 0.04942*u(k-11) + 0.04408*u(k-12);
% a = [1.688 -0.7096 0.04942 0.04408];
a = [-Gz.Denominator{1,1}(2), -Gz.Denominator{1,1}(3), Gz.Numerator{1,1}(2), Gz.Numerator{1,1}(3)];
delay = Gz.InputDelay;
% r - wy�ej
rozp = delay+2;
% kk = 160; % koniec symulacji
kk = 1000;

% warunki pocz�tkowe
u(1:rozp,1) = zeros();
y(1:rozp,1) = zeros();
yzad(1:rozp,1) = 0;
yzad(rozp+1:kk+rozp+1) = 1;
e(1:rozp,1) = zeros();

for k = rozp+1:kk+rozp+1
% 	y(k) = a(1)*y(k-1) + a(2)*y(k-2) + a(3)*u(k-11) + a(4)*u(k-12);
	y(k) = a(1)*y(k-1) + a(2)*y(k-2) + a(3)*u(k-1-delay) + a(4)*u(k-2-delay);
	e(k) = yzad(k)-y(k);
	u(k) = r(1)*e(k-2) + r(2)*e(k-1) + r(3)*e(k) + u(k-1);
end

if obrazek == 4
	figure;
	stairs(u);
	title('u');
	xlabel('k');
	xlim([0 kk+rozp]);
	if printing == 1
		print('regulator_PID_roznicowy_u','-dpng','-r400');
	end
	figure;
	stairs(yzad,'--','Color','#D95319');
	hold on;
	stairs(y,'Color','#0072BD');
	title('yzad, y');
	xlabel('k');
	legend('yzad','y');
	xlim([0 kk+rozp]);
	if printing == 1
		print('regulator_PID_roznicowy_y','-dpng','-r400');
	end
end

if obrazek == 6
	fu = figure;
	stairs(u);
	title('u');
	xlabel('k');
	xlim([0 kk+rozp]);
	
	fy = figure;
	stairs(yzad,':','Color','#D95319');
	hold on;
	stairs(y,'Color','#0072BD');
	title('yzad, y');
	xlabel('k');
	xlim([0 kk+rozp]);
end

% DMC
% erase u�ywane do czyszczenia figur w przypadku kiedy nie chcemy �eby si�
% nak�ada�y. U�ywane do sprawdzania zmian wyj�cia przy zmianie parametr�w
erase = 1;

% parametry
D = 160;
% N = 25;
% Nu = 1;
N = 20;
Nu = 1;
% lam = 400;
lam = 400;

ch = 'lam';
val = lam;

steps = step(Gz0,0:Tp:(D-1)*Tp);
u(:) = zeros(); y(:) = zeros();
yzad(length(yzad):length(yzad)+N) = 1;
du(1:rozp,1) = zeros();

Lam = eye(Nu)*lam;

M = zeros(N,Nu);
for i = 1:N
	for j = 1:Nu
		if i>=j
			M(i,j) = steps(i-j+1);
		end
	end
end

Mp = zeros(N,D-1);
for i = 1:N
	for j = 1:D-1
		if i+j <= D
			Mp(i,j) = steps(i+j)-steps(j);
		else
			Mp(i,j) = steps(D)-steps(j);
		end
	end
end

K = (M'*M+Lam)^(-1)*M';
k1 = K(1,:);
e = zeros(N,1);

for k = rozp+1:kk+rozp+1
% 	y(k) = a(1)*y(k-1) + a(2)*y(k-2) + a(3)*u(k-11) + a(4)*u(k-12);
	y(k) = a(1)*y(k-1) + a(2)*y(k-2) + a(3)*u(k-1-delay) + a(4)*u(k-2-delay);
	pasts = 0;
	for j = 1:D-1
		if k-j > 0
			pasts = pasts+ ( k1*Mp(:,j)*du(k-j) );
		else
			pasts = pasts+ ( k1*Mp(:,j)*du(1) );
		end
	end
	e(:) = yzad(k)-y(k);
	du(k) = k1*e - pasts;
	u(k) = u(k-1)+du(k);
end

if obrazek == 5
	c = exist('fu');
	if c == 1
		figure(fu);
		hold on;
	else
		fu = figure;
		legend();
		hold on;
	end
% 	stairs(u,'DisplayName',sprintf('u,%s=%d',ch,val));
	stairs(u,'DisplayName','u');
	title('u');
	xlabel('k');
	xlim([0 kk+rozp]);
	if printing == 1
		print('regulator_DMC_roznicowy_u','-dpng','-r400');
	end
	c = exist('fy');
	if c == 1
		figure(fy)
		hold on;
	else
		fy = figure;
		stairs(yzad,'--');
		legend('yzad')
		hold on;
	end
% 	stairs(yzad,'--','Color','#D95319');
% 	stairs(y,'Color','#0072BD');
% 	stairs(y,'DisplayName',sprintf('y,%s=%d',ch,val));
	stairs(y,'DisplayName','y');
	title('yzad, y');
	xlabel('k');
	xlim([0 kk+rozp]);
	if printing == 1
		print('regulator_DMC_roznicowy_y','-dpng','-r400');
	end
end

if obrazek == 6
	figure(fu);
	hold on;
	stairs(u,'Color','#A2142F');
	legend('PID','DMC');
	if printing == 1
		print(fu,'regulatory_PID_DMC_u','-dpng','-r400');
	end
	figure(fy);
	hold on;
	stairs(y,'Color','#A2142F');
	legend('yzad','PID','DMC');
	if printing == 1
		print(fy,'regulatory_PID_DMC_y','-dpng','-r400');
	end
end
clear ch val
if erase == 1
	clear fu fy;
end

clear y yzad N D M Mp Lam lam kk ku ke k1 K k i j pasts steps u e du a r

