global e;
global data;
data.pid = struct();

% Number of local regulators
data.fpid.R = 3;

% Parameters for each regulator
Ku = 20;
Tu = 80;

K=0.6*Ku;
Ti=Tu/2;
Td=Tu/8;

data.fpid.Ks = [ K*0.6 K*0.75 K*1];
data.fpid.Tis = [ Ti*1.5 Ti*1.45 Ti*1.4];
data.fpid.Tds = [ Td*0.050 Td*0.0225 Td*0.025];
data.T = 1;

data.fpid.mfpts{1} = [ 5 3 32];
data.fpid.mfpts{2} = [ 4 3 42.68];
data.fpid.mfpts{3} = [ 3 3 49.06];
data.fpid.rs={};

% Init all local regulators
for r=1:data.fpid.R
	data.fpid.rs{r}(1) = data.fpid.Ks(r)...
					  * (1 + data.T/(2*data.fpid.Tis(r))...
					  + data.fpid.Tds(r)/data.T);
	data.fpid.rs{r}(2) = data.fpid.Ks(r)...
					  * (data.T/(2*data.fpid.Tis(r))...
					  - 2*(data.fpid.Tds(r)/data.T) - 1);
	data.fpid.rs{r}(3) = data.fpid.Ks(r) * data.fpid.Tds(r) / data.T;
end

e = [0,0,0];