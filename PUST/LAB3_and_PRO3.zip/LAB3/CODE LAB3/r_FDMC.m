function u = r_FDMC(U,Y,yzad,k)
	global data
	data.E = yzad - Y(k);
	for i = 1:max(data.fdmc.Ds)-1
		if i+1 < k
			data.fdmc.dUP(i) = U(k-i) - U(k-(i+1));
		else
			data.fdmc.dUP(i) = 0;
		end
	end

	data.du = 0;
	data.fdmc.dus = zeros(1,data.fdmc.R);
	for r=1:data.fdmc.R
		data.fdmc.dus(r) = data.fdmc.Ke{r}*data.E(k) - data.fdmc.Ku{r}*data.fdmc.dUP(1:data.fdmc.Ds(r)-1);

		data.fdmc.ws(r) = gbellmf(Y(k),data.fdmc.mfpts(r,:));
		data.du = data.du + data.fdmc.ws(r)*data.fdmc.dus(r);
	end
	data.du = data.du/sum(data.fdmc.ws);

	% if du < data.dUbox(1)
	% 	du = data.dUbox(1);
	% elseif du > data.dUbox(2)
	% 	du = data.dUbox(2);
	% end

    if k == 1
        u = U(k) + data.du;
    else
        u = U(k-1) + data.du;
    end
    
	if u < data.Ubox(1)
		u = data.Ubox(1);
	elseif u > data.Ubox(2)
		u = data.Ubox(2);
	end
end