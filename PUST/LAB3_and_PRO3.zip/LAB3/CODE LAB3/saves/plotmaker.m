% figure();
% hold on;
% for i = 1:7
%     plot(Y{i});
% end
% plot([20,30,40,50,60,70,80],T,'-o')


set(0,'defaulttextinterpreter','latex');
set(0,'DefaultLineLineWidth',1);
set(0,'DefaultStairLineWidth',1);

% legend('u=20','u=30','u=40','u=50','u=60','u=70','u=80');
subplot(2,1,1);
plot(Y,'--');
hold on;
plot(yzad,'LineStyle', '--', 'Color', [0.17 0.17 0.17]);
xlabel('k');
ylabel('$y, y_{zad}$');
legend('FPID','FDMC');

subplot(2,1,2);
plot(U,'--');
hold on;
xlabel('k');
ylabel('u');
% legend('u_{FDMC}', 'u_{FDMC} \lambda=[1,4,1]');

% legend('y_{FPID1}','y_{ZAD}', 'y_{FPID2}');




