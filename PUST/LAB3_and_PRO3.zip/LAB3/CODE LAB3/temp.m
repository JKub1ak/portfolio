clear all
x = 31:0.1:50;
p{1} = [ 5 3 32];
p{2} = [ 4 3 42.68];
p{3} = [ 3 3 49.06];
figure;
hold on;
for i = 1:length(p)
	tmp{i} = gbellmf(x,p{i});
	plot(x,tmp{i});
end
ylabel('membership')
xlabel('y')