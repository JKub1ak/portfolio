function u = r_FPID(u,y,y_zad)
    global data e;
    e = [y_zad-y, e(1:2)];

    du = 0;
    dus = zeros(1,3);
    ws = zeros(1,3);
    for r=1:data.fpid.R
        dus(r) = data.fpid.rs{r}(3)*e(3)...
               + data.fpid.rs{r}(2)*e(2)...
               + data.fpid.rs{r}(1)*e(1);

        ws(r) = gbellmf(y,data.fpid.mfpts{r});
        du = du + ws(r)*dus(r);
    end
    du = du/sum(ws);

    u = u + du;

    if u < data.Ubox(1)
        u = data.Ubox(1);
    elseif u > data.Ubox(2)
        u = data.Ubox(2);
    end
end