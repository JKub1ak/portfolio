clear all
close all
addpath('D:\SerialCommunication'); % add a path to the functions
initSerialControl COM9 % initialise com port

sendControls([1], ... send for these elements
             [50]);  % new corresponding control values

yzad = ones(1,300);
% yzad = ones(1,10 + 210);
% for i = 1:length(yzad)
%     if i < 10
%         yzad(i) = yzad(i)*32;
%     else
%         yzad(i) = yzad(i)*42;
%     end
% end

u = 27;
sendNonlinearControls(u);

% init_DMC

% U = [u];

% while 32.76 < readMeasurements(1); waitForNewIteration(); end

US = [20 30 40 50 60 70 80];
Y={};
for j=1:length(US)
    
    u=US(j);
    for i = 1:length(yzad)
        y = readMeasurements(1:1);
        Y{j}(i) = y;

    %     u = r_DMC(U,Y,z,yzad,i);

    %     U(i) = u;
        sendNonlinearControls(u);
    %     fprintf('i=%d\nu=%f\ny=%f\ny_zad=%f\n\n',i,u,y,yzad(i));
        fprintf('i=%d\nu=%f\ny=%f\n\n',i,u,y);

        waitForNewIteration();
    end
    
end
% sendControls([5],[27]);
% sendControlsToG1AndDisturbance(27,0);

% E = sum((yzad - Y).^2);
% fprintf("E: %f\n",E);

save("temp.mat");

% subplot(2,1,1);
% plot(Y);
% hold on;
% plot(yzad(1:i));
% subplot(2,1,2);
% plot(U);
