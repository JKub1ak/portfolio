function value = fun(x)
%x = [T1, T2, K, Td]
T1 = x(1); T2 = x(2); K = x(3); Td = ceil(x(4));

global yy y

alfa1 = exp(-1/T1); alfa2 = exp(-1/T2);
a1 = -alfa1 - alfa2; a2 = alfa1*alfa2;
b1 = (K/(T1-T2))*(T1*(1-alfa1)-T2*(1-alfa2));
b2 = (K/(T1-T2))*(alfa1*T2*(1-alfa2)-alfa2*T1*(1-alfa1));

y = zeros(1,length(yy)-1);
value = 0;
for k = 2:length(yy)-1
    if k-Td-2>=0
        y(k) = b2;
    end
    if k-Td-1>=0
        y(k) = y(k) + b1;
    end
    if k-2>0
        y(k) = y(k) - a2*y(k-2);
    end
    if k-1>0
        y(k) = y(k) - a1*y(k-1);
    end
    value = value + (yy(k)-y(k))*(yy(k)-y(k));
end
end

