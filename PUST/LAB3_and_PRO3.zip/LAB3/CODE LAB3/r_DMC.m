function u = r_DMC(U,Y,yzad,k)
    global data
    for i = 1:data.dmc.D-1
        if i+1 < k
            data.dmc.dUP(i) = U(k-i) - U(k-(i+1));
        else
            data.dmc.dUP(i) = 0;
        end
    end

    du = data.dmc.Ke*(yzad(k) - Y(k)) - data.dmc.Ku*data.dmc.dUP;

    if k == 1
        u = U(k) + du;
    else
        u = U(k-1) + du;
    end

    if u < 0
        u = 0;
    elseif u > 100
        u = 100;
    end
end