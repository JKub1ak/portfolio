clear all
close all
addpath('D:\SerialCommunication'); % add a path to the functions
initSerialControl COM9 % initialise com port
global regulator data
data.Ubox = [0 100];

sendControls([1], ... send for these elements
             [50]);  % new corresponding control values


yzad = ones(1,50 + 300 + 300 + 300);
% yzad = ones(1,5); % testowe
upp=27;
ypp=34;

for i = 1:length(yzad)
    if i <= 50
        yzad(i) = yzad(i)*ypp;
    elseif i <= 50 + 300
        yzad(i) = yzad(i)*(ypp+5);
    elseif i <= 50 + 300*2
        yzad(i) = yzad(i)*(ypp+15);
    elseif i <= 50 + 300*3
        yzad(i) = yzad(i)*ypp;
    end
end

u = 27;
sendNonlinearControls(u);

regulator = 3;
if regulator==1
    init_pid
elseif regulator==2
    init_DMC
elseif regulator==3
    init_FPID
elseif regulator==4
    init_FDMC
end

U = [u];

for i = 1:length(yzad)
    y = readMeasurements(1:1);
    Y(i) = y;

    if regulator==1
        u=r_pid(u,y,yzad(i));
    elseif regulator==2
        u=r_DMC(U,Y,yzad,i);
    elseif regulator==3
        u=r_FPID(u,y,yzad(i));
    elseif regulator==4
        u=r_FDMC(U,Y,yzad,i);
    end

    U(i) = u;
    sendNonlinearControls(u);
    fprintf('i=%d\nu=%f\ny=%f\ny_zad=%f\n\n',i,u,y,yzad(i));
%     fprintf('i=%d\nu=%f\ny=%f\n\n',i,u,y);

    waitForNewIteration();
end
    
sendNonlinearControls(27);

E = sum((yzad - Y).^2);
fprintf("E: %f\n",E);

save("temp.mat");

subplot(2,1,1);
plot(Y);
hold on;
plot(yzad(1:i));
subplot(2,1,2);
plot(U);
