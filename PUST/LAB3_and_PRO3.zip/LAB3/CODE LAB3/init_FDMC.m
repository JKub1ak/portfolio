global data


% 	data.fdmc.S = {zeros(1,20) zeros(1,50) };
data.fdmc = load('step_response_fuzzy.mat');
data.fdmc.mfpts(1,:) = [ 5 3 32];
data.fdmc.mfpts(2,:) = [ 4 3 42.68];
data.fdmc.mfpts(3,:) = [ 3 3 49.06];

% Number of local regulators
data.fdmc.R = length(data.fdmc.mfpts(:,1));

for r=1:data.fdmc.R
	data.fdmc.Ds(r) = length(data.fdmc.S{r});
end

data.fdmc.Ns = data.fdmc.Ds;
data.fdmc.Nus = data.fdmc.Ns;
data.fdmc.lambdas = [ 1 4 1];

data.fdmc.Lambda={};
data.fdmc.M={};
data.fdmc.MP={};
data.fdmc.K={};
data.fdmc.Ku={};
data.fdmc.Ke={};

for r=1:data.fdmc.R

	data.fdmc.Lambda{r} = eye(data.fdmc.Nus(r))*data.fdmc.lambdas(r);
	data.fdmc.M{r} = zeros(data.fdmc.Ns(r),data.fdmc.Nus(r));
	for i=1:data.fdmc.Ns(r)
	   for j=1:data.fdmc.Nus(r)
		  if (i>=j)
			data.fdmc.M{r}(i,j)=data.fdmc.S{r}(i-j+1);
		  end
	   end
	end

	data.fdmc.K{r}(:,:) = (data.fdmc.M{r}(:,:)'*data.fdmc.M{r}(:,:)+data.fdmc.Lambda{r}(:,:))^(-1)*data.fdmc.M{r}(:,:)';

	data.fdmc.MP{r}(:,:)=zeros(data.fdmc.Ns(r),data.fdmc.Ds(r)-1);
	for i=1:data.fdmc.Ns(r)
	   for j=1:data.fdmc.Ds(r)-1
		  if i+j<=data.fdmc.Ds(r)
			 data.fdmc.MP{r}(i,j)=data.fdmc.S{r}(i+j)-data.fdmc.S{r}(j);
		  else
			data.fdmc.MP{r}(i,j)=data.fdmc.S{r}(data.fdmc.Ds(r))-data.fdmc.S{r}(j);
		  end
	   end
	end

	data.fdmc.Ke{r} = sum(data.fdmc.K{r}(1,:));
	data.fdmc.Ku{r} = data.fdmc.K{r}(1,:)*data.fdmc.MP{r};
end

data.fdmc.dUP = zeros(max(data.fdmc.Ds)-1,1);
data.fdmc.ws = zeros(1,data.fdmc.R);