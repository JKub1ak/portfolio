function u = r_pid(u,y,y_zad)
    global data e;
    e = [y_zad-y, e(1:2)];
    u = data.pid.r2*e(3) + data.pid.r1*e(2) + data.pid.r0*e(1) + u;
    
    if u < 0
        u = 0;
    elseif u > 100
        u = 100;
    end
end

