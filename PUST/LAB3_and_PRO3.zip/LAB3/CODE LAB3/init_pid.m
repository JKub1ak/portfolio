global e;
global data;

data.pid = struct();

Ku = 20;
Tu = 80;

data.pid.K = 0.6 * Ku *0.8;
data.pid.Ti = Tu / 2  *1.4;
data.pid.Td = Tu / 8  *0.025;
data.T = 1;

data.pid.r2 = data.pid.K * data.pid.Td / data.T;
data.pid.r1 = data.pid.K * (data.T/(2*data.pid.Ti) - 2*(data.pid.Td/data.T) - 1);
data.pid.r0 = data.pid.K * (1 + data.T/(2*data.pid.Ti) + data.pid.Td/data.T);

e = [0,0,0];