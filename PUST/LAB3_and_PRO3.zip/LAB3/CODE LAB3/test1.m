clear all
close all
addpath('D:\SerialCommunication'); % add a path to the functions
initSerialControl COM9 % initialise com port

%% obtaining measurements
measurements1 = readMeasurements(1); % read measurements from 1 to 7
%% processing of the measurements and new control values calculation

%% sending new values of control signals
sendControls([ 1], ... send for these elements
             [ 50]);  % new corresponding control values
         i=1;
sendNonlinearControls(27);
while(1)

    measurement_ = readMeasurements(1:1)
    measurement(i) = measurement_;
    i=i+1;
    waitForNewIteration();
end