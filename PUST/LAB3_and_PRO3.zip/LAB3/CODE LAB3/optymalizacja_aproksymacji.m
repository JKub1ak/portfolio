load 13_10_Z_skok_o_30.mat
global yy y

%odpowiedź skokowa
yy=(Y(31:end)-Y(30))/30;

%x = [T1, T2, K, Td]
x0 = [1 2 1 10];

x = fmincon(@fun, x0,[],[],[],[],[0 0 0 0],[]);

figure
plot(y);
hold on;
plot(yy);
