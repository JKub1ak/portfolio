clear all;
global data;
data = struct();
data.dont_set_params = 0;

data.Upp = 0;
data.Ypp = 0;

data.Ubox = [-1 1];
data.dUbox = [-Inf Inf];
data.Ybox = [-0.131267457303220 4.827579433181025];

data.T = 0.5;

data.startup = 7;

data.task = 5;

data.sim_len = 100;
if data.task > 3
	data.sim_len = 250;
end

data.stpt = 1;

data.regulator = 4;
data.fuzzy_n = 2;

if data.task < 4
	data.regulator = 0;
end
if data.regulator == 1
	init_PID
elseif data.regulator == 2
	init_DMC
elseif data.regulator == 3
	init_FPID
elseif data.regulator == 4
	init_FDMC
end

data.stpt = data.stpt*ones(1,data.sim_len);
if data.task > 3
	for i=1:data.sim_len
		if i <= 50
			data.stpt(i) = data.stpt(i)*0;
		elseif i<=100
			data.stpt(i) = data.stpt(i)*(-.1);
		elseif i<=150
			data.stpt(i) = data.stpt(i)*(3);
		elseif i<=200
			data.stpt(i) = data.stpt(i)*(1.5);
		else
			data.stpt(i) = data.stpt(i)*(4.5);
		end
	end
end
data.seed = 0;

data.dont_set_params = 0;
if data.task == 1
	task_1;
elseif data.task == 2
	task_2;
elseif data.task == 3
	task_3;
elseif data.task == 4
	task_4;
elseif data.task == 5
	task_5;
elseif data.task == 6
	task_6;
elseif data.task == 7
	task_7;
end

if data.task > 3
	E = sum((data.stpt - data.Y).^2);
	fprintf("E: %f\n",E);
end