function value = fun(x)
global US YS OUT;
a = x(1:2);
b = x(3:4);
c = x(5:6);
y0 = [static_out(c(1)) static_out(c(2))];
ders = [DX(c(1)) DX(c(2))];

value = 0;
for i=1:length(US)
	w = [gbellmf(US(i),[a(1) b(1) c(1)]) gbellmf(US(i),[a(2) b(2) c(2)])];
	us = [ders(1)*US(i)+y0(1) ders(2)*US(i)+y0(2)];
	OUT(i) = (w(1)*us(1) + w(2)*us(2))/sum(w);
	E = (YS(i)-OUT(i))^2;
	value = value + E;
end


function dx = DX(x)
step = .00001;
temp = [x-step/2 x+step/2];
dx = (static_out(temp(2))-static_out(temp(1)))/step;
end

% %x = [T1, T2, K, Td]
% T1 = x(1); T2 = x(2); K = x(3); Td = ceil(x(4));
% 
% global yy y
% 
% alfa1 = exp(-1/T1); alfa2 = exp(-1/T2);
% a1 = -alfa1 - alfa2; a2 = alfa1*alfa2;
% b1 = (K/(T1-T2))*(T1*(1-alfa1)-T2*(1-alfa2));
% b2 = (K/(T1-T2))*(alfa1*T2*(1-alfa2)-alfa2*T1*(1-alfa1));
% 
% y = zeros(1,length(yy)-1);
% value = 0;
% for k = 2:length(yy)-1
%     if k-Td-2>=0
%         y(k) = b2;
%     end
%     if k-Td-1>=0
%         y(k) = y(k) + b1;
%     end
%     if k-2>0
%         y(k) = y(k) - a2*y(k-2);
%     end
%     if k-1>0
%         y(k) = y(k) - a1*y(k-1);
%     end
%     value = value + (yy(k)-y(k))*(yy(k)-y(k));
% end
end

