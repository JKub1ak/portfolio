global data
data.E(k) = data.stpt(k) - data.Y(k);
for i = 1:data.dmc.D-1
	if i+1 < k
		data.dmc.dUP(i) = data.U(k-i) - data.U(k-(i+1));
	else
		data.dmc.dUP(i) = 0;
	end
end

du = data.dmc.Ke*data.E(k) - data.dmc.Ku*data.dmc.dUP;

% if du < data.dUbox(1)
% 	du = data.dUbox(1);
% elseif du > data.dUbox(2)
% 	du = data.dUbox(2);
% end

data.U(k) = data.U(k-1) + du;

if data.U(k) < data.Ubox(1)
	data.U(k) = data.Ubox(1);
elseif data.U(k) > data.Ubox(2)
	data.U(k) = data.Ubox(2);
end