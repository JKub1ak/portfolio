global data
data.E(k) = data.stpt(k) - data.Y(k);
data.du = data.pid.r2*data.E(k-2) + data.pid.r1*data.E(k-1) + data.pid.r0*data.E(k);

if data.du < data.dUbox(1)
	data.du = data.dUbox(1);
elseif data.du > data.dUbox(2)
	data.du = data.dUbox(2);
end

data.U(k) = data.U(k-1) + data.du;

if data.U(k) < data.Ubox(1)
	data.U(k) = data.Ubox(1);
elseif data.U(k) > data.Ubox(2)
	data.U(k) = data.Ubox(2);
end
