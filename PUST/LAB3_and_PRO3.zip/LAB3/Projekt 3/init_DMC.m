global data
if data.dont_set_params ~= 1
	data.dmc = load('step_response_basic.mat');
end

data.dmc.D = length(data.dmc.S);
if data.dont_set_params ~= 1
	data.dmc.N = data.dmc.D;
	data.dmc.Nu = data.dmc.N;
	data.dmc.lambda = 1;
end

data.dmc.Lambda = eye(data.dmc.Nu)*data.dmc.lambda;
data.dmc.M = zeros(data.dmc.N,data.dmc.Nu);
for i=1:data.dmc.N
   for j=1:data.dmc.Nu
	  if (i>=j)
		data.dmc.M(i,j)=data.dmc.S(i-j+1);
	  end
   end
end

data.dmc.K = (data.dmc.M'*data.dmc.M+data.dmc.Lambda)^(-1)*data.dmc.M';

data.dmc.MP=zeros(data.dmc.N,data.dmc.D-1);
for i=1:data.dmc.N
   for j=1:data.dmc.D-1
	  if i+j<=data.dmc.D
		 data.dmc.MP(i,j)=data.dmc.S(i+j)-data.dmc.S(j);
	  else
		data.dmc.MP(i,j)=data.dmc.S(data.dmc.D)-data.dmc.S(j);
	  end
   end
end

data.dmc.Ke = sum(data.dmc.K(1,:));
data.dmc.Ku = data.dmc.K(1,:)*data.dmc.MP;

data.dmc.dUP = zeros(data.dmc.D-1,1);