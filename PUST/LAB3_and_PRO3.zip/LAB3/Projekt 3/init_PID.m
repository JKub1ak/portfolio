global data
% data.pid.K = 2.03;
% data.pid.Ti = inf;
% data.pid.Td = 0;

data.pid.Ku = 2.03;
data.pid.Tu = 53*data.T;

if data.dont_set_params ~= 1
	data.pid.K = 0.6 * data.pid.Ku	*1.1;
	data.pid.Ti = data.pid.Tu / 2	*0.85;
	data.pid.Td = data.pid.Tu / 8	*1;
end

data.pid.r2 = data.pid.K * data.pid.Td / data.T;
data.pid.r1 = data.pid.K * (data.T/(2*data.pid.Ti) - 2*(data.pid.Td/data.T) - 1);
data.pid.r0 = data.pid.K * (1 + data.T/(2*data.pid.Ti) + data.pid.Td/data.T);

data.E = zeros(1,data.sim_len);