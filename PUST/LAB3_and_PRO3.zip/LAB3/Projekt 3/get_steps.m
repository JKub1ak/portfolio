clear all;
global data US YS;
load('very_detailed_static.mat');
data = struct();
data.dont_set_params = 0;

data.Upp = 0;
data.Ypp = 0;

data.Ubox = [-1 1];
data.dUbox = [-Inf Inf];
data.Ybox = [-0.131267457303220 4.827579433181025];

data.T = 0.5;

data.startup = 7;

data.task = 5;

data.sim_len = 100;

data.regulator = 0;

data.dont_set_params = 0;

Su = {};
dU = .01;

Y = [data.Ybox(1),
	 data.Ybox(2)-dU,
	 data.Ybox(1)+abs(data.Ybox(2)-data.Ybox(1))/2,
	 data.Ybox(1)+abs(data.Ybox(2)-data.Ybox(1))/3,
	 data.Ybox(2)-abs(data.Ybox(2)-data.Ybox(1))/3,
	 data.Ybox(1)+abs(data.Ybox(2)-data.Ybox(1))/4,
	 data.Ybox(2)-abs(data.Ybox(2)-data.Ybox(1))/4,
	 data.Ybox(1)+abs(data.Ybox(2)-data.Ybox(1))/5,
	 data.Ybox(1)+2*abs(data.Ybox(2)-data.Ybox(1))/5,
	 data.Ybox(2)-2*abs(data.Ybox(2)-data.Ybox(1))/5,
	 data.Ybox(2)-abs(data.Ybox(2)-data.Ybox(1))/5
];
% Step start points:
U = find_by_y(Y);
% These corresond to following Y values:


for i=1:length(Y)
	% Equalizing pass, just in case
	data.U=U(i)*ones(1,data.sim_len);
	data.Y=Y(i)*ones(1,data.sim_len);
	simulation;
	data.U=U(i)*ones(1,data.sim_len)+dU;
	simulation;
	Su{i} = (data.Y(2:51)-data.Y(1))/dU;
end

figure
for i=1:length(Su)
	plot(Su{i});
	hold on;
end
title(sprintf("Odpowiedź skokowa U do DMC"));
ylabel("y(k)");
xlabel("k");
hold off;

fuzzy_steps = {};
S = {Su{1} Su{2}};
fuzzy_steps{1} = S;
S = {Su{1} Su{3} Su{2}};
fuzzy_steps{end+1} = S;
S = {Su{1} Su{4} Su{5} Su{2}};
fuzzy_steps{end+1} = S;
S = {Su{1} Su{6} Su{3} Su{7} Su{2}};
fuzzy_steps{end+1} = S;
S = {Su{1} Su{8} Su{9} Su{10} Su{11} Su{2}};
fuzzy_steps{end+1} = S;

% save('step_response_fuzzy.mat','fuzzy_steps');