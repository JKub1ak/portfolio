
data.E(k) = data.stpt(k) - data.Y(k);

data.du = 0;
for r=1:data.fpid.R
	data.fpid.dus(r) = data.fpid.rs{r}(3)*data.E(k-2)...
					 + data.fpid.rs{r}(2)*data.E(k-1)...
					 + data.fpid.rs{r}(1)*data.E(k);
				 
	data.fpid.ws(r) = gbellmf(data.Y(k),data.fpid.mfpts{r});
	data.du = data.du + data.fpid.ws(r)*data.fpid.dus(r);
end
data.fpid.WS(:,k) = data.fpid.ws;
data.du = data.du/sum(data.fpid.ws);

% if data.du < data.dUbox(1)
% 	data.du = data.dUbox(1);
% elseif data.du > data.dUbox(2)
% 	data.du = data.dUbox(2);
% end

data.U(k) = data.U(k-1) + data.du;

if data.U(k) < data.Ubox(1)
	data.U(k) = data.Ubox(1);
elseif data.U(k) > data.Ubox(2)
	data.U(k) = data.Ubox(2);
end
