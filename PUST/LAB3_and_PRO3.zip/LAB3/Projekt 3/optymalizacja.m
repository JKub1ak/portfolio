global US YS OUT;
US = linspace(-1,1,1001);
YS = zeros(1,1001);
for i=1:length(US)
	data.U = ones(1,data.sim_len)*US(i);
	data.Y = ones(1,data.sim_len)*data.Ypp;
	simulation;
	YS(i) = data.Y(end);
end
figure
plot(US,YS);
title('Charakterystyka statyczna');
ylabel("y(u)");
xlabel("u");

a0 = [.5 .5];
b0 = [10 10];
c0 = [-.1 .1];
x0 = [a0 b0 c0];

OUT = zeros(1,1001);
x = fmincon(@fun, x0, [], [], [], [], [0 0 0 0 -1 -1], [Inf Inf Inf Inf 1 1]);
hold on;
plot(US,OUT);

a = x(1:2);
b = x(3:4);
c = x(5:6);
figure;
hold on;
for i = 1:2
	y(i,:) = gbellmf(US,[a(i) b(i) c(i)]);
	plot(US,y(i,:));
end
% load z2plus20.mat
% global yy y
% 
% %odpowiedź skokowa
% yy(1:349)=(measurement(2:350)-measurement(1))/20;
% 
% %x = [T1, T2, K, Td]
% x0 = [1 2 1 1];
% 
% x = fmincon(@fun, x0,[],[],[],[],[0 0 0 0],[]);
% 
% figure
% plot(y);
% hold on;
% plot(yy(1:349));
