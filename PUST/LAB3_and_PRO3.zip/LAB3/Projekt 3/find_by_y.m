function u = find_by_y(y)
	global US YS
	u = zeros(length(y));
	for i=1:length(y)
		[~,j] = min(abs(YS-y(i)));
		u(i) = US(j);
	end
end