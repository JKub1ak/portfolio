global data
for k = data.startup:data.sim_len
	data.Y(k) = symulacja_obiektu2y_p3(data.U(k-5),data.U(k-6),data.Y(k-1),data.Y(k-2));
	
	if data.regulator == 0
	elseif data.regulator == 1
		r_PID
	elseif data.regulator == 2
		r_DMC
	elseif data.regulator == 3
		r_FPID
	elseif data.regulator == 4
		r_FDMC
	end
end
