
data.E(k) = data.stpt(k) - data.Y(k);
for i = 1:max(data.fdmc.Ds)-1
	if i+1 < k
		data.fdmc.dUP(i) = data.U(k-i) - data.U(k-(i+1));
	else
		data.fdmc.dUP(i) = 0;
	end
end

data.du = 0;
data.fdmc.dus = zeros(1,data.fdmc.R);
for r=1:data.fdmc.R
	data.fdmc.dus(r) = data.fdmc.Ke{r}*data.E(k) - data.fdmc.Ku{r}*data.fdmc.dUP(1:data.fdmc.Ds(r)-1);
	
	data.fdmc.ws(r) = gbellmf(data.U(k-1),data.fdmc.mfpts{r});
	data.du = data.du + data.fdmc.ws(r)*data.fdmc.dus(r);
end
data.fdmc.WS(:,k) = data.fdmc.ws;
data.du = data.du/sum(data.fdmc.ws);

% if du < data.dUbox(1)
% 	du = data.dUbox(1);
% elseif du > data.dUbox(2)
% 	du = data.dUbox(2);
% end

data.U(k) = data.U(k-1) + data.du;

if data.U(k) < data.Ubox(1)
	data.U(k) = data.Ubox(1);
elseif data.U(k) > data.Ubox(2)
	data.U(k) = data.Ubox(2);
end