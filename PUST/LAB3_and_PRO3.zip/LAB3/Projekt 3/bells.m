global data
data.regulator=0;
data.Ypp = 0;
data.sim_len = 100;
US = data.Ubox(1):0.001:data.Ubox(2);
YS = zeros(1,length(US));
for i=1:length(US)
	YS(i) = static_out(US(i));
end

data.fpid.mfpts{1}=[ 1 2 data.Ybox(1)];
data.fpid.mfpts{2}=[ 1 2 data.Ybox(1)+(data.Ybox(2)+data.Ybox(1))/4];
data.fpid.mfpts{3}=[ 1 2 data.Ybox(2)];
data.fpid.mfpts{4}=[ 1 2 data.Ybox(2)-(data.Ybox(2)+data.Ybox(1))/2];
data.fpid.mfpts{5}=[ 1 2 data.Ybox(2)-(data.Ybox(2)+data.Ybox(1))/4];

% p(1,:)=[ 1 5 data.Ubox(1)];
% p(2,:)=[ .15 1 .404];
% p(3,:)=[ .5 4 data.Ubox(2)];
p(1,:)=data.fpid.mfpts{1};
p(2,:)=data.fpid.mfpts{2};
p(3,:)=data.fpid.mfpts{3};
p(4,:)=data.fpid.mfpts{4};
p(5,:)=data.fpid.mfpts{5};
figure;
plot(YS,US);
hold on;
for i = 1:length(p(:,1))
	y(i,:) = gbellmf(YS,p(i,:));
	plot(YS,2*y(i,:)-1,'--');
end
% xlabel('gbellmf, P=[2 4 6]')
% 
% figure
% plot(US,YS);
% hold on;
% plot(US,y(1,:).*(a(1)*US+b(1))+y(2,:).*(a(2)*US+b(2))+y(3,:).*(a(3)*US+b(3)));

% p(1,:)=[.5 1 data.Ybox(1)];
% p(2,:)=[ 1 2 data.Ypp+.8];
% p(3,:)=[ 4 3 data.Ybox(2)];
% figure;
% plot(YS,US);
% hold on;
% for i = 1:length(p(:,1))
% 	y(i,:) = gbellmf(x,p(i,:));
% 	plot(x,2*y(i,:)-1,'--');
% end
% xlabel('gbellmf, P=[2 4 6]')