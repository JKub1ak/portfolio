global data

% Parameters for each regulator
if data.dont_set_params ~= 1
	data.fpid.mfpts = {};
	
	if data.fuzzy_n == 2
		data.fpid.Ks = [ 1 1];
		data.fpid.Tis = [ 10 10];
		data.fpid.Tds = [ 0 0];
		data.fpid.mfpts{1}=[1 2 data.Ybox(1)];
		data.fpid.mfpts{end+1}=[ 1 2 data.Ybox(2)];
	elseif data.fuzzy_n == 3
		data.fpid.Ks = [ 1 1 1];
		data.fpid.Tis = [ 10 10 10];
		data.fpid.Tds = [ 0 0 0];
		data.fpid.mfpts{1}=[1 2 data.Ybox(1)];
		data.fpid.mfpts{end+1}=[ 1 2 data.Ybox(1)+abs(data.Ybox(2)-data.Ybox(1))/2];
		data.fpid.mfpts{end+1}=[ 1 2 data.Ybox(2)];	
	elseif data.fuzzy_n == 4
		data.fpid.Ks = [ 1 1 1 1];
		data.fpid.Tis = [ 10 10 10 10];
		data.fpid.Tds = [ 0 0 0 0];
		data.fpid.mfpts{1}=[1 2 data.Ybox(1)];
		data.fpid.mfpts{end+1}=[ 1 2 data.Ybox(1)+abs(data.Ybox(2)-data.Ybox(1))/3];
		data.fpid.mfpts{end+1}=[ 1 2 data.Ybox(2)-abs(data.Ybox(2)-data.Ybox(1))/3];
		data.fpid.mfpts{end+1}=[ 1 2 data.Ybox(2)];	
	elseif data.fuzzy_n == 5
		data.fpid.Ks = [ 1 1 1 1 1];
		data.fpid.Tis = [ 10 10 10 10 10];
		data.fpid.Tds = [ 0 0 0 0 0];
		data.fpid.mfpts{1}=[1 2 data.Ybox(1)];
		data.fpid.mfpts{end+1}=[ 1 2 data.Ybox(1)+abs(data.Ybox(2)-data.Ybox(1))/4];
		data.fpid.mfpts{end+1}=[ 1 2 data.Ybox(1)+abs(data.Ybox(2)-data.Ybox(1))/2];
		data.fpid.mfpts{end+1}=[ 1 2 data.Ybox(2)-abs(data.Ybox(2)-data.Ybox(1))/4];
		data.fpid.mfpts{end+1}=[ 1 2 data.Ybox(2)];	
	elseif data.fuzzy_n == 6
		data.fpid.Ks = [ 1 1 1 1 1 1];
		data.fpid.Tis = [ 10 10 10 10 10 10];
		data.fpid.Tds = [ 0 0 0 0 0 0];
		data.fpid.mfpts{1}=[1 2 data.Ybox(1)];
		data.fpid.mfpts{end+1}=[ 1 2 data.Ybox(1)+abs(data.Ybox(2)-data.Ybox(1))/5];
		data.fpid.mfpts{end+1}=[ 1 2 data.Ybox(1)+2*abs(data.Ybox(2)-data.Ybox(1))/5];
		data.fpid.mfpts{end+1}=[ 1 2 data.Ybox(2)-2*abs(data.Ybox(2)-data.Ybox(1))/5];
		data.fpid.mfpts{end+1}=[ 1 2 data.Ybox(2)-abs(data.Ybox(2)-data.Ybox(1))/5];
		data.fpid.mfpts{end+1}=[ 1 2 data.Ybox(2)];	
	end
% 	data.fpid.Ks = [ 1 .5 .1];
% 	data.fpid.Tis = [ 10 10 10];
% 	data.fpid.Tds = [ 0 .5 1];
% 	data.fpid.mfpts{1}=[.5 1 data.Ybox(1)];
% 	data.fpid.mfpts{2}=[ 1 2 data.Ypp+.8];
% 	data.fpid.mfpts{3}=[ 4 3 data.Ybox(2)];
% 	data.fpid.mfpts{1} = [ 1 3 data.Ybox(1)];
% 	data.fpid.mfpts{2} = [ 3 3 (data.Ybox(2)+data.Ybox(1))/2];
% 	data.fpid.mfpts{3} = [ 4 3 data.Ybox(2)];
end
data.fpid.rs={};
data.fpid.R=length(data.fpid.mfpts);

% Init all local regulators
for r=1:data.fpid.R
	data.fpid.rs{r}(1) = data.fpid.Ks(r)...
					  * (1 + data.T/(2*data.fpid.Tis(r))...
					  + data.fpid.Tds(r)/data.T);
	data.fpid.rs{r}(2) = data.fpid.Ks(r)...
					  * (data.T/(2*data.fpid.Tis(r))...
					  - 2*(data.fpid.Tds(r)/data.T) - 1);
	data.fpid.rs{r}(3) = data.fpid.Ks(r) * data.fpid.Tds(r) / data.T;
end

data.E = zeros(1,data.sim_len);
data.fpid.dus = zeros(1,data.fpid.R);
data.fpid.ws = zeros(1,data.fpid.R);
data.fpid.WS = zeros(data.fpid.R,data.sim_len);