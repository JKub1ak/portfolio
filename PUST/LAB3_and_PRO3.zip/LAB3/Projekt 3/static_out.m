function y = static_out(u)
	global data;
	data.U = ones(1,data.sim_len)*u;
	data.Y = ones(1,data.sim_len)*data.Ypp;
	simulation;
	y=data.Y(end);
end