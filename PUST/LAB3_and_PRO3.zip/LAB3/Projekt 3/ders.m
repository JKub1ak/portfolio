range = linspace(-1,1,1001);
step = .00001;
der = zeros(1,length(range));
for i = 1:length(range)
	der(i) = DX(range(i));
end
figure;plot(range(2:end-1),der(2:end-1));

der2 = zeros(1,length(range));
for i = 1:length(range)
	der2(i) = DDX(range(i));
end
figure;plot(range(2:end-1),der2(2:end-1));

der3 = zeros(1,length(range));
for i = 1:length(range)
	der3(i) = DDDX(range(i));
end
figure;plot(range(2:end-1),der3(2:end-1));


function dx = DX(x)
global data;
step = .00001;
if x < data.Ubox(1)
	temp = [data.Ubox(1) data.Ubox(1)+step];
elseif x > data.Ubox(2)
	temp = [data.Ubox(2)-step data.Ubox(2)];
elseif x-step/2 < data.Ubox(1)
	temp = [x x+step];
elseif x+step/2 > data.Ubox(2)
	temp = [x-step x];
else
	temp = [x-step/2 x+step/2];
end
dx = (static_out(temp(2))-static_out(temp(1)))/step;
end

function ddx = DDX(x)
global data;
step = .0001;
if x < data.Ubox(1)
	temp = [data.Ubox(1) data.Ubox(1)+step];
elseif x > data.Ubox(2)
	temp = [data.Ubox(2)-step data.Ubox(2)];
elseif x-step/2 < data.Ubox(1)
	temp = [x x+step];
elseif x+step/2 > data.Ubox(2)
	temp = [x-step x];
else
	temp = [x-step/2 x+step/2];
end
ddx = (DX(temp(2))-DX(temp(1)))/step;
end

function dddx = DDDX(x)
global data;
step = .001;
if x < data.Ubox(1)
	temp = [data.Ubox(1) data.Ubox(1)+step];
elseif x > data.Ubox(2)
	temp = [data.Ubox(2)-step data.Ubox(2)];
elseif x-step/2 < data.Ubox(1)
	temp = [x x+step];
elseif x+step/2 > data.Ubox(2)
	temp = [x-step x];
else
	temp = [x-step/2 x+step/2];
end
dddx = (DDX(temp(2))-DDX(temp(1)))/step;
end