global data

if data.dont_set_params ~= 1
	data.fdmc = load('step_response_fuzzy.mat');
		
	data.fdmc.R = data.fuzzy_n;
	data.fdmc.S = data.fdmc.fuzzy_steps{data.fdmc.R-1};
	for r=1:data.fdmc.R
		data.fdmc.Ds(r) = length(data.fdmc.S{r});
	end
	
	% Individual fuzzy regulator settings
	if data.fdmc.R == 2
		data.fdmc.Ns = data.fdmc.Ds;
		data.fdmc.Nus = data.fdmc.Ns;
		data.fdmc.lambdas = [ 1 1];
		% ^ all vectors 2
		data.fdmc.mfpts{1}=[1 2 data.Ybox(1)];
		data.fdmc.mfpts{end+1}=[ 1 2 data.Ybox(2)];
	elseif data.fdmc.R == 3
		data.fdmc.Ns = data.fdmc.Ds;
		data.fdmc.Nus = data.fdmc.Ns;
		data.fdmc.lambdas = [ 1 1 1];
		% ^ all vectors 3
		data.fdmc.mfpts{1}=[1 2 data.Ybox(1)];
		data.fdmc.mfpts{end+1}=[ 1 2 data.Ybox(1)+abs(data.Ybox(2)-data.Ybox(1))/2];
		data.fdmc.mfpts{end+1}=[ 1 2 data.Ybox(2)];	
	elseif data.fdmc.R == 4
		data.fdmc.Ns = data.fdmc.Ds;
		data.fdmc.Nus = data.fdmc.Ns;
		data.fdmc.lambdas = [ 1 1 1 1];
		% ^ all vectors 4
		data.fdmc.mfpts{1}=[1 2 data.Ybox(1)];
		data.fdmc.mfpts{end+1}=[ 1 2 data.Ybox(1)+abs(data.Ybox(2)-data.Ybox(1))/3];
		data.fdmc.mfpts{end+1}=[ 1 2 data.Ybox(2)-abs(data.Ybox(2)-data.Ybox(1))/3];
		data.fdmc.mfpts{end+1}=[ 1 2 data.Ybox(2)];	
	elseif data.fdmc.R == 5
		data.fdmc.Ns = data.fdmc.Ds;
		data.fdmc.Nus = data.fdmc.Ns;
		data.fdmc.lambdas = [ 1 1 1 1 1];
		% ^ all vectors 5
		data.fdmc.mfpts{1}=[1 2 data.Ybox(1)];
		data.fdmc.mfpts{end+1}=[ 1 2 data.Ybox(1)+abs(data.Ybox(2)-data.Ybox(1))/4];
		data.fdmc.mfpts{end+1}=[ 1 2 data.Ybox(1)+abs(data.Ybox(2)-data.Ybox(1))/2];
		data.fdmc.mfpts{end+1}=[ 1 2 data.Ybox(2)-abs(data.Ybox(2)-data.Ybox(1))/4];
		data.fdmc.mfpts{end+1}=[ 1 2 data.Ybox(2)];	
	elseif data.fdmc.R == 6
		data.fdmc.Ns = data.fdmc.Ds;
		data.fdmc.Nus = data.fdmc.Ns;
		data.fdmc.lambdas = [ 1 1 1 1 1 1];
		% ^ all vectors 6
		data.fdmc.mfpts{1}=[1 2 data.Ybox(1)];
		data.fdmc.mfpts{end+1}=[ 1 2 data.Ybox(1)+abs(data.Ybox(2)-data.Ybox(1))/5];
		data.fdmc.mfpts{end+1}=[ 1 2 data.Ybox(1)+2*abs(data.Ybox(2)-data.Ybox(1))/5];
		data.fdmc.mfpts{end+1}=[ 1 2 data.Ybox(2)-2*abs(data.Ybox(2)-data.Ybox(1))/5];
		data.fdmc.mfpts{end+1}=[ 1 2 data.Ybox(2)-abs(data.Ybox(2)-data.Ybox(1))/5];
		data.fdmc.mfpts{end+1}=[ 1 2 data.Ybox(2)];	
	end
end

data.fdmc.Lambda={};
data.fdmc.M={};
data.fdmc.MP={};
data.fdmc.K={};
data.fdmc.Ku={};
data.fdmc.Ke={};

for r=1:data.fdmc.R

	data.fdmc.Lambda{r} = eye(data.fdmc.Nus(r))*data.fdmc.lambdas(r);
	data.fdmc.M{r} = zeros(data.fdmc.Ns(r),data.fdmc.Nus(r));
	for i=1:data.fdmc.Ns(r)
	   for j=1:data.fdmc.Nus(r)
		  if (i>=j)
			data.fdmc.M{r}(i,j)=data.fdmc.S{r}(i-j+1);
		  end
	   end
	end

	data.fdmc.K{r}(:,:) = (data.fdmc.M{r}(:,:)'*data.fdmc.M{r}(:,:)+data.fdmc.Lambda{r}(:,:))^(-1)*data.fdmc.M{r}(:,:)';

	data.fdmc.MP{r}(:,:)=zeros(data.fdmc.Ns(r),data.fdmc.Ds(r)-1);
	for i=1:data.fdmc.Ns(r)
	   for j=1:data.fdmc.Ds(r)-1
		  if i+j<=data.fdmc.Ds(r)
			 data.fdmc.MP{r}(i,j)=data.fdmc.S{r}(i+j)-data.fdmc.S{r}(j);
		  else
			data.fdmc.MP{r}(i,j)=data.fdmc.S{r}(data.fdmc.Ds(r))-data.fdmc.S{r}(j);
		  end
	   end
	end

	data.fdmc.Ke{r} = sum(data.fdmc.K{r}(1,:));
	data.fdmc.Ku{r} = data.fdmc.K{r}(1,:)*data.fdmc.MP{r};
end

data.fdmc.dUP = zeros(max(data.fdmc.Ds)-1,1);
data.fdmc.ws = zeros(1,data.fdmc.R);
data.fdmc.WS = zeros(data.fdmc.R,data.sim_len);