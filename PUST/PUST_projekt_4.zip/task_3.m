global data
%--------------------------------------------------------------------------
%--------------------------------- get S ----------------------------------
%--------------------------------------------------------------------------

D = 160;
S = zeros(D,length(data.Ypp),length(data.Upp));
for i=1:length(data.Upp)
	u = data.Upp;
	u(i) = 1;
	data.U = [ones(length(data.Upp),data.startup).*data.Upp ones(length(data.Upp),data.sim_len-data.startup).*u];
	data.Y = ones(length(data.Ypp),data.sim_len).*data.Ypp;
	simulation;
	S(:,:,i) = data.Y(:,(data.startup+1):data.startup+D)';
end

%--------------------------------------------------------------------------
%--------------------------------- Images ---------------------------------
%--------------------------------------------------------------------------

figure
for i=1:length(data.Ypp)
	for j=1:length(data.Upp)
		subplot(length(data.Ypp),length(data.Upp),j+(i-1)*length(data.Upp));
		title(sprintf("Y_%d(U_%d)",i,j));
		hold on;
		plot(S(:,i,j),'LineWidth',1);
		ylim([0 2.5]);
		hold off
		ylabel("y(k)");
		xlabel("k");
	end
end

margin=.99;
fprintf("%f,\t%f,\t%f\n",1.5*margin,.5*margin,1.9*margin);
fprintf("%f,\t%f,\t%f\n",S(end,1,1),S(end,2,1),S(end,3,1));
save('step_response.mat','S');clear S;
