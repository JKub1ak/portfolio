clear all;
global data;
data = struct();
data.dont_set_params = 0;

data.Upp = [0 0 0 0]';
data.Ypp = [0 0 0]';

data.T = 0.5;

data.startup = 5;
data.sim_len = 1000;

data.task = 4;
% 1-PID, 2-DMC, 3-predictive DMC
data.regulator = 3;

data.stpt = zeros(length(data.Ypp),data.sim_len);
for k=data.startup:data.sim_len
	
	% Y1
	if k < 300
		data.stpt(1,k) = 2;
	elseif k < 600
		data.stpt(1,k) = -1;
	else
		data.stpt(1,k) = 3;
	end
	
	% Y2
	if k < 200
	elseif k < 500
		data.stpt(2,k) = -1;
	elseif k < 800
		data.stpt(2,k) = 2;
	else
		data.stpt(2,k) = 0;
	end
	
	% Y3
	if k < 100
	elseif k < 400
		data.stpt(3,k) = 1;
	elseif k < 700
		data.stpt(3,k) = -2;
	else
		data.stpt(3,k) = -1;
	end
end

if data.regulator == 0
elseif data.regulator == 1
	init_PID
elseif data.regulator == 2 || data.regulator == 3
	init_DMC
end

data.dont_set_params = 0;
if data.task == 1
	task_1;
elseif data.task == 2
	task_2;
elseif data.task == 3
	task_3;
elseif data.task == 4
	task_4;
elseif data.task == 5
	task_5;
elseif data.task == 6
	task_6;
elseif data.task == 7
	task_7;
end

if data.task > 3
	E = sum(sum((data.stpt - data.Y).^2));
	fprintf("E: %f\n",E);
end