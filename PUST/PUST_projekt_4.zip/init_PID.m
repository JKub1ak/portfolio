global data

% data.pid.Ku = ones(length(data.Ypp),1);
% data.pid.Tu = ones(length(data.Ypp),1);

%				Y1  Y2  Y3
data.pid.mod = [2.5	2	3;		%K
				3	6	3;		%Ti
				0	0	0];		%Td
data.pid.out = [4	2	3];		%Which U regulator regulates
% data.pid.out = [4	2	1];
% data.pid.out = [1	2	3];

if data.dont_set_params ~= 1
	for i=1:length(data.Ypp)
		data.pid.K(i,1)  = data.pid.mod(1,i);
		data.pid.Ti(i,1) = data.pid.mod(2,i);
		data.pid.Td(i,1) = data.pid.mod(3,i);
	end
end

data.pid.r2 = data.pid.K .* data.pid.Td ./ data.T;
data.pid.r1 = data.pid.K .* (data.T./(2.*data.pid.Ti) - 2.*(data.pid.Td./data.T) - 1);
data.pid.r0 = data.pid.K .* (1 + data.T./(2.*data.pid.Ti) + data.pid.Td./data.T);

data.E = zeros(length(data.Ypp),data.sim_len);
data.du = zeros(length(data.Upp),1);