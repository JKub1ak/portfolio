global data
%--------------------------------------------------------------------------
%--------------------------------- Part 1 ---------------------------------
%--------------------------------------------------------------------------

data.U = ones(length(data.Upp),data.sim_len).*data.Upp;
data.Y = ones(length(data.Ypp),data.sim_len).*data.Ypp;

%--------------------------------------------------------------------------
%------------------------------- Simulation -------------------------------
%--------------------------------------------------------------------------

simulation;

%--------------------------------------------------------------------------
%--------------------------------- Images ---------------------------------
%--------------------------------------------------------------------------

if data.regulator == 0
	reg='--';
elseif data.regulator == 1
	reg='PID';
elseif data.regulator == 2
	reg='DMC';
elseif data.regulator == 3
	reg='full DMC';
end

figure
for i=1:length(data.Ypp)
	subplot(3,1,i);
	plot(data.Y(i,:),'LineWidth',1);
	hold on;
	plot(data.stpt(i,:),'LineWidth',1);
	title(sprintf("Y_%d",i));
	ylabel("y(k)");
	xlabel("k");
end

figure
for i=1:length(data.Upp)
	subplot(4,1,i);
	plot(data.U(i,:),'LineWidth',1);
	title(sprintf("U_%d",i));
	ylabel("u(k)");
	xlabel("k");
end

