global data
data.E(:,k) = data.stpt(:,k) - data.Y(:,k);
for i = 1:data.dmc.D-1
	if i+1 < k
		data.dmc.dUP(1+(i-1)*data.dmc.nu:data.dmc.nu+(i-1)*data.dmc.nu)...
					= (data.U(:,k-i) - data.U(:,k-(i+1)))';
	else
		data.dmc.dUP(1+(i-1)*data.dmc.nu:data.dmc.nu+(i-1)*data.dmc.nu)...
					= zeros(1,length(data.Upp));
	end
end

data.du = data.dmc.Ke*data.E(:,k) - data.dmc.Ku*data.dmc.dUP;
data.U(:,k) = data.U(:,k-1) + data.du;
