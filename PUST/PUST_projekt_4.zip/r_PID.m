global data
%obliczenie uchybów regulacji
data.E(:,k) = data.stpt(:,k) - data.Y(:,k);

%obliczenie zmian sygnałów sterujących
data.du = zeros(length(data.Upp),1);
for i=1:length(data.E(:,k))
	data.du(data.pid.out(i)) = data.pid.r2(i).*data.E(i,k-2) + data.pid.r1(i).*data.E(i,k-1) + data.pid.r0(i).*data.E(i,k);
end

%obliczenie sygnałów sterujących
data.U(:,k) = data.U(:,k-1) + data.du;