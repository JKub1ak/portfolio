global data
if data.dont_set_params ~= 1
	data.dmc = load('step_response.mat');
	%must be of size D x ny x nu
end

data.dmc.nu = length(data.Upp);
data.dmc.ny = length(data.Ypp);

data.dmc.D = length(data.dmc.S);
if data.dont_set_params ~= 1
% 	data.dmc.N = data.dmc.D;
	data.dmc.N = 25;
	data.dmc.Nu = data.dmc.N;
% 	data.dmc.Nu = 4;
	data.dmc.lambda = [.4 .4 .5 .4];
	data.dmc.psi = [1 1 .4];
% 	data.dmc.lambda = [1 1 1 1];
% 	data.dmc.psi = [1 1 1];
end

data.dmc.Lambda = zeros(data.dmc.Nu*data.dmc.nu);
for i=1:length(data.dmc.Lambda)
	data.dmc.Lambda(i,i) = data.dmc.lambda(1+mod(i-1,data.dmc.nu));
end
data.dmc.Psi = zeros(data.dmc.N*data.dmc.ny);
for i=1:length(data.dmc.Psi)
	data.dmc.Psi(i,i) = data.dmc.psi(1+mod(i-1,data.dmc.ny));
end
data.dmc.M = zeros(data.dmc.N*data.dmc.ny,data.dmc.Nu*data.dmc.nu);
for i=1:data.dmc.N
   for j=1:data.dmc.Nu
	  if (i>=j)
		data.dmc.M((1+(i-1)*data.dmc.ny):i*data.dmc.ny,(1+(j-1)*data.dmc.nu):j*data.dmc.nu)...
				  = data.dmc.S(i-j+1,:,:);
	  end
   end
end

data.dmc.K = (data.dmc.M'*data.dmc.Psi*data.dmc.M+data.dmc.Lambda)^(-1)*data.dmc.M';

data.dmc.MP=zeros(data.dmc.N*data.dmc.ny,(data.dmc.D-1)*data.dmc.nu);
for i=1:data.dmc.N
   for j=1:data.dmc.D-1
	  if i+j<=data.dmc.D
		 data.dmc.MP((1+(i-1)*data.dmc.ny):i*data.dmc.ny,(1+(j-1)*data.dmc.nu):j*data.dmc.nu)...
					=data.dmc.S(i+j,:,:)-data.dmc.S(j,:,:);
	  else
		data.dmc.MP((1+(i-1)*data.dmc.ny):i*data.dmc.ny,(1+(j-1)*data.dmc.nu):j*data.dmc.nu)...
					=data.dmc.S(data.dmc.D,:,:)-data.dmc.S(j,:,:);
	  end
   end
end
data.dmc.Ke = zeros(data.dmc.nu,data.dmc.ny);
for i=1:data.dmc.N
	data.dmc.Ke = data.dmc.Ke...
				+ data.dmc.K(1:data.dmc.nu,(1+(i-1)*data.dmc.ny):i*data.dmc.ny);
end
data.dmc.Ku = data.dmc.K(1:data.dmc.nu,:)*data.dmc.MP;

data.dmc.dUP = zeros((data.dmc.D-1)*data.dmc.nu,1);
if data.regulator == 2
	data.E = zeros(data.dmc.ny,data.sim_len);
elseif data.regulator == 3
	data.E = zeros(data.dmc.ny*data.dmc.N,data.sim_len);
end
