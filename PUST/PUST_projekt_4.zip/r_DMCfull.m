global data
for i = 1:data.dmc.N
	data.E((1+(i-1)*data.dmc.ny):i*data.dmc.ny,k) = data.stpt(:,k) - data.Y(:,k);
% 	DMC with future stpt prediction
% 	if k+i-1 <= length(data.stpt)
% 		data.E((1+(i-1)*data.dmc.ny):i*data.dmc.ny,k) = data.stpt(:,k+i-1) - data.Y(:,k);
% 	else
% 		data.E((1+(i-1)*data.dmc.ny):i*data.dmc.ny,k) = data.stpt(:,end) - data.Y(:,k);
% 	end
end

for i = 1:data.dmc.D-1
	if i+1 < k
		data.dmc.dUP(1+(i-1)*data.dmc.nu:data.dmc.nu+(i-1)*data.dmc.nu)...
					= (data.U(:,k-i) - data.U(:,k-(i+1)))';
	else
		data.dmc.dUP(1+(i-1)*data.dmc.nu:data.dmc.nu+(i-1)*data.dmc.nu)...
					= zeros(1,length(data.Upp));
	end
end

temp = (data.dmc.K*(data.E(:,k) - data.dmc.MP*data.dmc.dUP));
data.du = temp(1:data.dmc.nu);
data.U(:,k) = data.U(:,k-1) + data.du;
