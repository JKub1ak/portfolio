UWAGA!
	Między symulacjami regulacji konieczne jest wywołanie funkcji 'clear calc_control' w celu wyczyszczenia pamięci regulatora.